// GRNForm.tsx - Service/Customer + Supplier/Manual item entry + GST billing + Print + Success modal 
// Status is always set to "submitted" - removed from UI 
// UPDATED: Added VIEW MODE support via URL parameter ?mode=view
// FIXED: Purchase Order field now clears its filter on focus so the user
//        can easily switch to another PO after making a selection.
// FIXED: PO dropdown no longer filters by the auto-set supplier, so ALL POs
//        are always visible and selectable.

import { useState, useEffect, type FormEvent, useRef } from "react"; 
import { useNavigate, useParams, useLocation, useSearchParams } from "react-router-dom"; 
import toast from 'react-hot-toast'; 
import { getUserRole } from '../utils/storage'; 
import { 
  FaArrowLeft, 
  FaSave, 
  FaSpinner, 
  FaExclamationCircle, 
  FaExclamationTriangle, 
  FaInfoCircle, 
  FaTimesCircle, 
  FaCheckCircle, 
  FaPlus, 
  FaTrash, 
  FaWarehouse, 
  FaFileInvoice, 
  FaBox, 
  FaPhone, 
  FaEnvelope, 
  FaMapMarkerAlt, 
  FaUserCircle, 
  FaUsers, 
  FaPercentage, 
  FaReceipt, 
  FaSearch, 
  FaPrint, 
  FaMoneyBillWave, 
  FaGlobeAsia, 
  FaBuilding,
  FaStickyNote,
  FaBoxes
} from 'react-icons/fa'; 
import "./GRNForm.css"; 
import { PageLoader } from '../components/PageLoader';
import { useAdminTheme } from '../admin-theme/AdminThemeContext'; 
import api from '../services/api'; 
 
// ─── DigitInput Component ────────────────────────────────────────────── 
interface DigitInputProps { 
  label?: string; 
  value: number | string; 
  onChange: (value: number | string) => void; 
  placeholder?: string; 
  maxLength?: number; 
  disabled?: boolean; 
  className?: string; 
  required?: boolean; 
  allowDecimal?: boolean; 
  min?: number; 
  max?: number; 
} 
 
const DigitInput: React.FC<DigitInputProps> = ({ 
  label, 
  value, 
  onChange, 
  placeholder = "Enter number", 
  maxLength = 10, 
  disabled = false, 
  className = "", 
  required = false, 
  allowDecimal = false, 
  min, 
  max, 
}) => { 
  const [displayValue, setDisplayValue] = useState<string>(value !== undefined && value !== null ? String(value) : ''); 
 
  useEffect(() => { 
    setDisplayValue(value !== undefined && value !== null ? String(value) : ''); 
  }, [value]); 
 
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => { 
    let inputValue = e.target.value; 
     
    if (allowDecimal) { 
      const decimalRegex = /^[0-9]*\.?[0-9]*$/; 
      if (decimalRegex.test(inputValue) || inputValue === '') { 
        if (inputValue.replace('.', '').length <= maxLength) { 
          setDisplayValue(inputValue); 
          onChange(inputValue); 
        } 
      } 
    } else { 
      const digitsOnly = inputValue.replace(/\D/g, ''); 
      if (digitsOnly.length <= maxLength) { 
        setDisplayValue(digitsOnly); 
        onChange(digitsOnly); 
      } 
    } 
  }; 
 
  const handleBlur = () => { 
    if (displayValue !== '') { 
      const numValue = parseFloat(displayValue); 
      if (!isNaN(numValue)) { 
        if (min !== undefined && numValue < min) { 
          onChange(min); 
          setDisplayValue(String(min)); 
          return; 
        } 
        if (max !== undefined && numValue > max) { 
          onChange(max); 
          setDisplayValue(String(max)); 
          return; 
        } 
      } 
    } 
  }; 
 
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => { 
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { 
      e.preventDefault(); 
    } 
  }; 
 
  return ( 
    <div className={`digit-input-wrapper ${className}`}> 
      {label && ( 
        <label className="digit-input-label"> 
          {label} 
          {required && <span className="grnf-required">*</span>} 
        </label> 
      )} 
      <input 
        type="text" 
        inputMode={allowDecimal ? "decimal" : "numeric"} 
        pattern={allowDecimal ? "[0-9]*[.]?[0-9]*" : "[0-9]*"} 
        value={displayValue} 
        onChange={handleChange} 
        onBlur={handleBlur} 
        onKeyDown={handleKeyDown} 
        placeholder={placeholder} 
        disabled={disabled} 
        maxLength={maxLength + (allowDecimal ? 1 : 0)} 
        className={`digit-input ${disabled ? 'digit-input-disabled' : ''}`} 
      /> 
    </div> 
  ); 
}; 
 
// ─── Entry Mode ───────────────────────────────────────────────────────── 
type EntryMode = 'supplier' | 'manual'; 
 
interface GRNItem { 
  id: string; 
  itemCode: string; 
  itemName: string; 
  orderedQty: number; 
  receivedQty: number; 
  rejectedQty: number; 
  uom: string; 
  rate: number; 
  remarks: string; 
  poItemId?: number; 
  itemId?: number; 
  taxId?: number; 
  taxType?: string; 
  taxRate?: number; 
  hsn?: string; 
  isDraft?: boolean; 
} 
 
interface ValidationError { 
  field: string; 
  label: string; 
  message: string; 
} 
 
interface GRNData { 
  id?: string; 
  grn_number: string; 
  grnDate: string; 
  isService: boolean; 
  entryMode: EntryMode; 
  supplier: string; 
  supplierId?: number; 
  purchaseOrder: string; 
  purchaseOrderId?: number; 
  warehouse: string; 
  warehouseId?: number; 
  customer: string; 
  customerId?: number; 
  receivedBy: string; 
  receivedById?: number; 
  vehicleNo: string; 
  deliveryChallanNo: string; 
  invoiceNo: string; 
  freeDelivery: boolean; 
  deliveryCharge: number; 
  items: GRNItem[]; 
} 
 
interface PurchaseOrder { 
  id: number; 
  name: string; 
  supplier_name: string; 
  supplier: string; 
  company: string; 
  transaction_date: string; 
  schedule_date: string; 
  currency: string; 
  total_qty: number; 
  total: number; 
  net_total: number; 
  grand_total: number; 
  rounded_total: number; 
  status: string; 
  per_received: number; 
  per_billed: number; 
  title?: string; 
} 
 
interface PurchaseOrderDetail extends PurchaseOrder { 
  items: POItem[]; 
  terms?: string; 
  address_display?: string; 
  contact_display?: string; 
  contact_mobile?: string; 
  contact_email?: string; 
  cost_center?: string; 
  set_warehouse?: string; 
  tax_category?: string; 
  shipping_rule?: string; 
  incoterm?: string; 
  named_place?: string; 
  payment_terms_template?: string; 
  tc_name?: string; 
  conversion_rate?: number; 
  price_list_currency?: string; 
  plc_conversion_rate?: number; 
  supplier_id?: number; 
} 
 
interface POItem { 
  id: number; 
  item_code: string; 
  item_name: string; 
  qty: number; 
  uom: string; 
  rate: number; 
  amount: number; 
  received_qty: number; 
  returned_qty: number; 
  billed_amt: number; 
  warehouse?: string; 
  expense_account?: string; 
  weight_per_unit?: number; 
  weight_uom?: string; 
  item_tax_rate?: number; 
  item_tax_template?: string; 
  cost_center?: string; 
  hsn?: string; 
  tax_id?: number; 
  tax_type?: string; 
} 
 
interface POApiResponse { 
  success: number; 
  data: { 
    total: number; 
    page: number; 
    limit: number; 
    records: PurchaseOrder[]; 
  }; 
} 
 
interface PODetailApiResponse { 
  success: number; 
  data: PurchaseOrderDetail; 
} 
 
interface Warehouse { 
  id: number; 
  warehouse_name: string; 
  company: string; 
  parent_warehouse: string | null; 
  warehouse_type: string | null; 
  city: string | null; 
  state: string | null; 
  email_id: string | null; 
  phone_no: string | null; 
  disabled: number; 
} 
 
interface WarehouseApiResponse { 
  success: number; 
  data: { 
    total: number; 
    page: number; 
    limit: number; 
    records: Warehouse[]; 
  }; 
} 
 
interface Employee { 
  id: number; 
  employee_name: string; 
  first_name: string; 
  middle_name: string; 
  last_name: string; 
  designation: string; 
  department: string; 
  company_email: string; 
  cell_number: string; 
  status: string; 
  user_id: string | null; 
} 
 
interface EmployeeApiResponse { 
  success: number; 
  data: { 
    total: number; 
    page: number; 
    limit: number; 
    records: Employee[]; 
  }; 
} 
 
interface Customer { 
  id: number; 
  customer_name: string; 
  customer_type: string; 
  customer_group: string; 
  territory: string; 
  mobile_no: string; 
  email_id: string; 
  default_currency: string; 
  disabled: number; 
  is_frozen: number; 
  creation: string; 
} 
 
interface CustomerApiResponse { 
  success: number; 
  data: { 
    total: number; 
    page: number; 
    limit: number; 
    records: Customer[]; 
  }; 
} 
 
interface Supplier { 
  id: number; 
  supplier_name: string; 
  supplier_type: string; 
  supplier_group: string; 
  country: string; 
  mobile_no: string; 
  email_id: string; 
  disabled: number; 
} 
 
interface SupplierApiResponse { 
  success: number; 
  data: { 
    total: number; 
    page: number; 
    limit: number; 
    records: Supplier[]; 
  }; 
} 
 
interface ItemMaster { 
  id: number; 
  item_code: string; 
  item_name: string; 
  item_group: string; 
  stock_uom: string; 
  standard_rate: number; 
  valuation_rate?: number; 
  description?: string; 
  tax_id: number | null; 
  disabled: number; 
  HSN?: string; 
} 
 
interface TaxType { 
  tax_id: number; 
  tax_type: string; 
} 
 
interface TaxApiResponse { 
  success: number; 
  data: TaxType[]; 
} 
 
interface GRNApiResponse { 
  success: number; 
  data: { 
    id: number; 
    grn_number: string; 
    grn_date: string; 
    is_service?: number; 
    entry_mode?: EntryMode; 
    supplier_id: number | null; 
    supplier_name: string | null; 
    customer_id: number | null; 
    purchase_order_id: number | null; 
    warehouse_id: number; 
    warehouse_name: string; 
    customer_name?: string; 
    received_by: string; 
    received_by_id?: number; 
    vehicle_number: string | null; 
    delivery_challan_no: string; 
    invoice_number: string | null; 
    is_free_delivery?: number; 
    delivery_charge?: number; 
    status: 'draft' | 'submitted' | 'completed' | 'rejected'; 
    total_ordered_qty: number; 
    total_received_qty: number; 
    total_accepted_qty: number; 
    total_rejected_qty: number; 
    remarks: string | null; 
    total_items: number; 
    items?: GRNApiItem[]; 
  }; 
} 
 
interface GRNApiItem { 
  id: number; 
  item_code: string; 
  item_name: string; 
  ordered_qty: number; 
  received_qty: number; 
  rejected_qty: number; 
  uom: string; 
  rate: number; 
  remarks: string; 
  po_item_id?: number; 
  item_id?: number; 
  tax_id?: number; 
  tax_type?: string; 
  item_tax_template?: string; 
  hsn?: string; 
} 
 
// ─── Helpers ─────────────────────────────────────────────────────────── 
const parseGstPercent = (taxType?: string): number => { 
  if (!taxType) return 0; 
  const match = taxType.match(/(\d+(\.\d+)?)/); 
  return match ? parseFloat(match[1]) : 0; 
}; 
 
const extractTaxInfo = (taxType?: string, taxTemplate?: string): { rate: number; type: string; category: string } => { 
  let taxString = taxType || taxTemplate || ''; 
  if (!taxString) return { rate: 0, type: '', category: '' }; 
   
  const rateMatch = taxString.match(/(\d+(\.\d+)?)/); 
  const rate = rateMatch ? parseFloat(rateMatch[1]) : 0; 
   
  let type = ''; 
  if (taxString.includes('GST')) type = 'GST'; 
  else if (taxString.includes('VAT')) type = 'VAT'; 
  else if (taxString.includes('Tax')) type = 'Tax'; 
   
  return { rate, type, category: type || 'GST' }; 
}; 
 
const computeItemAmounts = (item: GRNItem) => { 
  const qty = item.receivedQty || 0; 
  const amount = qty * (item.rate || 0); 
  const gstPercent = item.taxRate || parseGstPercent(item.taxType) || 0; 
  const sgst = (amount * gstPercent) / 2 / 100; 
  const cgst = (amount * gstPercent) / 2 / 100; 
  const total = amount + sgst + cgst; 
  return { amount, sgst, cgst, total, gstPercent }; 
}; 
 
const escapeHtml = (value: string | number | undefined | null): string => { 
  const str = value === undefined || value === null ? '' : String(value); 
  return str 
    .replace(/&/g, '&amp;') 
    .replace(/</g, '&lt;') 
    .replace(/>/g, '&gt;') 
    .replace(/"/g, '&quot;'); 
}; 
 
// ─── MAIN COMPONENT ────────────────────────────────────────────────────── 
 
export default function GRNForm() { 
  const { id } = useParams<{ id: string }>(); 
  const navigate = useNavigate(); 
  const location = useLocation(); 
  const [searchParams] = useSearchParams();
  const mode = searchParams.get('mode');
  const isViewMode = mode === 'view';
  const { theme } = useAdminTheme(); 
  const isNew = id === "new"; 
  const isEditMode = !isNew && Boolean(id); 
 
  // ─── Form State ──────────────────────────────────────────────────────── 
  const [formData, setFormData] = useState<GRNData>({ 
    grn_number: '', 
    grnDate: new Date().toISOString().split('T')[0], 
    isService: false, 
    entryMode: 'supplier', 
    supplier: '', 
    supplierId: undefined, 
    purchaseOrder: '', 
    purchaseOrderId: undefined, 
    warehouse: '', 
    warehouseId: undefined, 
    customer: '', 
    customerId: undefined, 
    receivedBy: '', 
    receivedById: undefined, 
    vehicleNo: '', 
    deliveryChallanNo: '', 
    invoiceNo: '', 
    freeDelivery: true, 
    deliveryCharge: 0, 
    items: [], 
  }); 
 
  const [, setIsDirty] = useState(isNew); 
  const [submitting, setSubmitting] = useState(false); 
  const [errors, setErrors] = useState<{ [key: string]: string }>({}); 
  const [showValidationSummary, setShowValidationSummary] = useState(false); 
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]); 
  const [apiError, setApiError] = useState<string | null>(null); 
  const [loading, setLoading] = useState<boolean>(isEditMode); 
 
  // ─── Company ─────────────────────────────────────────────────────────── 
  const [company, setCompany] = useState<string>('SculptorTech Pvt Ltd'); 
 
  // ─── Success Modal ─────────────────────────────────────────────────── 
  const [showSuccessModal, setShowSuccessModal] = useState(false); 
  const [savedGrnNumber, setSavedGrnNumber] = useState<string>(''); 
  const [isUpdateMode, setIsUpdateMode] = useState<boolean>(false); 
 
  // ─── Service Toggle Confirmation ───────────────────────────────────── 
  const [showServiceToggleConfirm, setShowServiceToggleConfirm] = useState(false); 
  const [pendingServiceToggle, setPendingServiceToggle] = useState(false); 
 
  // ─── PO Dropdown States ────────────────────────────────────────────── 
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]); 
  const [loadingPOs, setLoadingPOs] = useState(false); 
  const [poSearchTerm, setPOSearchTerm] = useState(''); 
  const [showPODropdown, setShowPODropdown] = useState(false); 
  const [poCurrentPage, setPOCurrentPage] = useState(1); 
  const [poItemsPerPage] = useState(10); 
  const [, setTotalPOs] = useState(0); 
  const [, setPODetailLoading] = useState(false); 
  // 🆕 Track whether the PO input is focused so we can show the live search
  //    term (with all options) while focused, and the selected PO label
  //    otherwise. This lets the user easily switch to a different PO after
  //    having already selected one.
  const [isPOFocused, setIsPOFocused] = useState(false);
  const poInputRef = useRef<HTMLInputElement>(null); 
  const poDropdownRef = useRef<HTMLDivElement>(null); 
 
  // ─── Warehouse State ──────────────────────────────────────────────── 
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]); 
  const [loadingWarehouses, setLoadingWarehouses] = useState(false); 
  const [warehouseSearchTerm, setWarehouseSearchTerm] = useState(''); 
  const [showWarehouseDropdown, setShowWarehouseDropdown] = useState(false); 
  const warehouseInputRef = useRef<HTMLInputElement>(null); 
  const warehouseDropdownRef = useRef<HTMLDivElement>(null); 
 
  // ─── Employee State ────────────────────────────────────────────────── 
  const [employees, setEmployees] = useState<Employee[]>([]); 
  const [loadingEmployees, setLoadingEmployees] = useState(false); 
  const [employeeSearchTerm, setEmployeeSearchTerm] = useState(''); 
  const [showEmployeeDropdown, setShowEmployeeDropdown] = useState(false); 
  const employeeInputRef = useRef<HTMLInputElement>(null); 
  const employeeDropdownRef = useRef<HTMLDivElement>(null); 
 
  // ─── Customer State ─────────────────────────────────────────────────── 
  const [customers, setCustomers] = useState<Customer[]>([]); 
  const [loadingCustomers, setLoadingCustomers] = useState(false); 
  const [customerSearchTerm, setCustomerSearchTerm] = useState(''); 
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false); 
  const customerInputRef = useRef<HTMLInputElement>(null); 
  const customerDropdownRef = useRef<HTMLDivElement>(null); 
 
  // ─── Supplier State ────────────────────────────────────────────────── 
  const [suppliers, setSuppliers] = useState<Supplier[]>([]); 
  const [loadingSuppliers, setLoadingSuppliers] = useState(false); 
  const [supplierSearchTerm, setSupplierSearchTerm] = useState(''); 
  const [showSupplierDropdown, setShowSupplierDropdown] = useState(false); 
  const supplierInputRef = useRef<HTMLInputElement>(null); 
  const supplierDropdownRef = useRef<HTMLDivElement>(null); 
 
  // ─── Item Master & Portal States ─────────────────────────────────── 
  const [itemsMaster, setItemsMaster] = useState<ItemMaster[]>([]); 
  const [allItems, setAllItems] = useState<ItemMaster[]>([]); 
  const [filteredItems, setFilteredItems] = useState<{ [key: number]: ItemMaster[] }>({}); 
  const [searchTerms, setSearchTerms] = useState<{ [key: number]: string }>({}); 
  const [showSuggestions, setShowSuggestions] = useState<{ [key: number]: boolean }>({}); 
  const [dropdownPositions, setDropdownPositions] = useState<{ [key: number]: { top: number; left: number; width: number } }>({}); 
  const [digitValues, setDigitValues] = useState<{ [key: number]: { [field: string]: string } }>({}); 
  const inputRefs = useRef<{ [key: number]: HTMLInputElement | null }>({}); 
  const suggestionRefs = useRef<{ [key: number]: HTMLDivElement | null }>({}); 
 
  // ─── Item Group Filter ────────────────────────────────────────────── 
  const [itemGroupFilter, setItemGroupFilter] = useState<string>('all'); 
  const [itemGroups, setItemGroups] = useState<string[]>([]); 
 
  // ─── Add Item Popup Modal States ──────────────────────────────────── 
  const [showAddItemPopup, setShowAddItemPopup] = useState<boolean>(false); 
  const [activeRowIndex, setActiveRowIndex] = useState<number | null>(null); 
  const [, setPendingItemSearch] = useState<string>(''); 
  const [addingItem, setAddingItem] = useState<boolean>(false); 
  const [newItem, setNewItem] = useState({ 
    item_name: '', 
    item_code: '', 
    item_group: '', 
    stock_uom: 'NOS', 
    standard_rate: '', 
    valuation_rate: '', 
    description: '', 
    tax_id: '', 
    quantity: '1', 
  }); 
 
  const [loadingItemsMaster, setLoadingItemsMaster] = useState(false); 
  const [, setActiveItemSearchIndex] = useState<number | null>(null); 
  const itemSearchDropdownRef = useRef<HTMLDivElement>(null); 
 
  // ─── Tax Types State ─────────────────────────────────────────────── 
  const [taxTypes, setTaxTypes] = useState<TaxType[]>([]); 
  const [loadingTaxTypes, setLoadingTaxTypes] = useState(false); 
 
  // ─── PO Items Cache ───────────────────────────────────────────────── 
  const [poItemsCache, setPoItemsCache] = useState<{ [poId: number]: POItem[] }>({}); 
  const [loadingPOItems, setLoadingPOItems] = useState<{ [poId: number]: boolean }>({}); 
 
  // ─── PurchaseBillForm-style Item Search & Note Popover States ──────── 
  const [, setItemSearch] = useState<string>(''); 
  const [selectedItemRowIndex, setSelectedItemRowIndex] = useState<number | null>(null); 
  const [showItemDropdown, setShowItemDropdown] = useState<boolean>(false); 
  const [notePopoverIndex, setNotePopoverIndex] = useState<number | null>(null); 
  const [] = useState<ItemMaster[]>([]); 
  const [] = useState<boolean>(false); 
 
  // ─── View Mode Badge ────────────────────────────────────────────────── 
  const renderViewModeBadge = () => { 
    if (!isViewMode) return null; 
     
    return ( 
      <span className="grnf-view-mode-badge" style={{ 
        display: 'inline-flex', 
        alignItems: 'center', 
        gap: '6px', 
        background: '#6366f1', 
        color: '#ffffff', 
        padding: '4px 12px', 
        borderRadius: '20px', 
        fontSize: '12px', 
        fontWeight: 500, 
        marginLeft: '12px', 
      }}> 
        
      </span> 
    ); 
  }; 
 
  // 🆕 Computed display value for the "Purchase Order" input:
  //    - While focused → show the live search term (starts empty so all POs
  //      appear)
  //    - While not focused → show the selected PO's name, or fall back to
  //      the raw search term if nothing is selected
  const poDisplayValue = isPOFocused
    ? poSearchTerm
    : (formData.purchaseOrder || poSearchTerm);
 
  // ─── Fetch Warehouses ────────────────────────────────────────────── 
  const fetchWarehouses = async () => { 
    if (isViewMode) return;
    setLoadingWarehouses(true); 
    try { 
      const response = await api.get<WarehouseApiResponse>('/warehouse?limit=200'); 
      if (response.data.success === 1) { 
        const records = response.data.data.records || []; 
        setWarehouses(records); 
      } 
    } catch (err) { 
      console.error('Error fetching warehouses:', err); 
    } finally { 
      setLoadingWarehouses(false); 
    } 
  };
 
  // ─── Fetch Employees ──────────────────────────────────────────────── 
  const fetchEmployees = async () => { 
    if (isViewMode) return;
    setLoadingEmployees(true); 
    try { 
      const response = await api.get<EmployeeApiResponse>('/employee'); 
      if (response.data.success === 1) { 
        const records = response.data.data.records || []; 
        setEmployees(records); 
      } 
    } catch (err) { 
      console.error('Error fetching employees:', err); 
    } finally { 
      setLoadingEmployees(false); 
    } 
  }; 
 
  // ─── Fetch Customers ───────────────────────────────────────────────── 
  const fetchCustomers = async () => { 
    if (isViewMode) return;
    setLoadingCustomers(true); 
    try { 
      const response = await api.get<CustomerApiResponse>('/customer'); 
      if (response.data.success === 1) { 
        const records = response.data.data.records || []; 
        setCustomers(records); 
      } 
    } catch (err) { 
      console.error('Error fetching customers:', err); 
    } finally { 
      setLoadingCustomers(false); 
    } 
  }; 
 
  // ─── Fetch Suppliers ────────────────────────────────────────────────── 
  const fetchSuppliers = async () => { 
    if (isViewMode) return;
    setLoadingSuppliers(true); 
    try { 
      const response = await api.get<SupplierApiResponse>('/supplier'); 
      if (response.data.success === 1) { 
        const records = response.data.data.records || []; 
        setSuppliers(records); 
      } 
    } catch (err) { 
      console.error('Error fetching suppliers:', err); 
    } finally { 
      setLoadingSuppliers(false); 
    } 
  }; 
 
  // ─── Fetch Item Master ────────────────────────────────────────────── 
  const fetchItemsMaster = async (): Promise<ItemMaster[]> => { 
    if (isViewMode) return [];
    setLoadingItemsMaster(true); 
    try { 
      const response = await api.get('/item?limit=200'); 
      if (response.data && response.data.success === 1) { 
        const items = response.data.data || []; 
        const mappedItems: ItemMaster[] = items.map((item: any) => ({ 
          id: item.id, 
          item_code: item.item_code, 
          item_name: item.item_name, 
          stock_uom: item.stock_uom || 'NOS', 
          standard_rate: item.standard_rate || 0, 
          valuation_rate: item.valuation_rate || item.standard_rate || 0, 
          description: item.description, 
          brand: item.brand, 
          item_group: item.item_group || 'Uncategorized', 
          tax_id: item.tax_id, 
          HSN: item.HSN || item.hsn || '', 
          disabled: item.disabled, 
        })); 
 
        setItemsMaster(mappedItems); 
        setAllItems(mappedItems); 
 
        const groups = Array.from(new Set(mappedItems.map(i => i.item_group).filter(Boolean))) as string[]; 
        setItemGroups(groups); 
 
        setFilteredItems(prev => { 
          const newFiltered = { ...prev }; 
          formData.items.forEach((_, index) => { 
            newFiltered[index] = mappedItems; 
          }); 
          return newFiltered; 
        }); 
 
        return mappedItems; 
      } 
      return []; 
    } catch (err) { 
      console.error('Error fetching items:', err); 
      return []; 
    } finally { 
      setLoadingItemsMaster(false); 
    } 
  }; 
 
  // ─── Fetch Tax Types ──────────────────────────────────────────────── 
  const fetchTaxTypes = async (): Promise<TaxType[]> => { 
    if (isViewMode) return [];
    setLoadingTaxTypes(true); 
    try { 
      const response = await api.get<TaxApiResponse>('/item/get-tax'); 
      if (response.data.success === 1) { 
        const records = response.data.data || []; 
        setTaxTypes(records); 
        return records; 
      } 
      return []; 
    } catch (err) { 
      console.error('Error fetching tax types:', err); 
      return []; 
    } finally { 
      setLoadingTaxTypes(false); 
    } 
  }; 
 
  // ─── Fetch Purchase Orders ──────────────────────────────────────────
  // 🆕 Always fetch ALL POs (no supplier filter) so the user can freely
  //    switch to any PO from any supplier after having selected one.
  const fetchPurchaseOrders = async () => { 
    if (isViewMode) return;
    setLoadingPOs(true); 
    try { 
      const response = await api.get<POApiResponse>( 
        `/purchase-order?page=${poCurrentPage}&limit=${poItemsPerPage}` 
      ); 
 
      if (response.data.success === 1) { 
        const records = response.data.data.records || []; 
        setPurchaseOrders(records); 
        setTotalPOs(response.data.data.total || records.length); 
      } 
    } catch (err) { 
      console.error('Error fetching purchase orders:', err); 
    } finally { 
      setLoadingPOs(false); 
    } 
  }; 
 
  // ─── Fetch Purchase Order Details ────────────────────────────────── 
  const fetchPurchaseOrderDetail = async (poId: number) => { 
    if (isViewMode) return;
    setPODetailLoading(true); 
    try { 
      const response = await api.get<PODetailApiResponse>(`/purchase-order/${poId}`); 
       
      if (response.data.success === 1) { 
        const poDetail = response.data.data; 
        if (poDetail.items) { 
          setPoItemsCache(prev => ({ 
            ...prev, 
            [poId]: poDetail.items 
          })); 
        } 
        populateGRNFromPO(poDetail); 
        setShowPODropdown(false); 
      } 
    } catch (err) { 
      console.error('Error fetching purchase order details:', err); 
      setApiError('Failed to fetch PO details'); 
    } finally { 
      setPODetailLoading(false); 
    } 
  }; 
 
  // ─── Resolve tax info from various sources ────────────────────────── 
  const resolveTaxInfo = (item: any, taxTypesOverride?: TaxType[]): { taxId?: number; taxType?: string; taxRate?: number } => { 
    const taxList = taxTypesOverride ?? taxTypes; 
 
    if (item.tax_id) { 
      const tax = taxList.find(t => t.tax_id === item.tax_id); 
      if (tax) { 
        const { rate } = extractTaxInfo(tax.tax_type); 
        return { taxId: item.tax_id, taxType: tax.tax_type, taxRate: rate }; 
      } 
    } 
 
    if (item.item_tax_template) { 
      const { rate } = extractTaxInfo(undefined, item.item_tax_template); 
 
      let matchingTax: TaxType | undefined = undefined; 
 
      matchingTax = taxList.find(t => { 
        const { rate: tRate } = extractTaxInfo(t.tax_type); 
        return tRate === rate; 
      }); 
 
      if (!matchingTax) { 
        const templateClean = item.item_tax_template.replace(/\s/g, '').toLowerCase(); 
        matchingTax = taxList.find(t => { 
          const taxClean = t.tax_type.replace(/\s/g, '').toLowerCase(); 
          return taxClean.includes(templateClean) || templateClean.includes(taxClean); 
        }); 
      } 
 
      if (matchingTax) { 
        return { 
          taxId: matchingTax.tax_id, 
          taxType: matchingTax.tax_type, 
          taxRate: rate 
        }; 
      } 
      return { taxType: item.item_tax_template, taxRate: rate }; 
    } 
 
    if (item.tax_type) { 
      const { rate } = extractTaxInfo(item.tax_type); 
      const matchingTax = taxList.find(t => { 
        const { rate: tRate } = extractTaxInfo(t.tax_type); 
        return tRate === rate; 
      }); 
      if (matchingTax) { 
        return { taxId: matchingTax.tax_id, taxType: matchingTax.tax_type, taxRate: rate }; 
      } 
      return { taxType: item.tax_type, taxRate: rate }; 
    } 
 
    return {}; 
  }; 
 
  // ─── Resolve the actual Item Master id for a GRN item ──────────────── 
  const resolveItemMasterId = (item: GRNItem): number | undefined => { 
    if (item.itemCode) { 
      const matchByCode = itemsMaster.find( 
        im => (im.item_code || '').trim().toLowerCase() === item.itemCode.trim().toLowerCase() 
      ); 
      if (matchByCode) return matchByCode.id; 
    } 
    if (item.itemId) { 
      const matchById = itemsMaster.find(im => im.id === item.itemId); 
      if (matchById) return matchById.id; 
    } 
    return item.itemId; 
  }; 
 
  // ─── Populate GRN from PO ────────────────────────────────────────── 
  const populateGRNFromPO = (poDetail: PurchaseOrderDetail) => { 
    if (isViewMode) return;
    
    const items: GRNItem[] = (poDetail.items || []).map((item, index) => { 
      const taxInfo = resolveTaxInfo(item); 
 
      const masterMatch = itemsMaster.find( 
        im => (im.item_code || '').toLowerCase() === (item.item_code || '').toLowerCase() 
      ); 
 
      return { 
        id: `po-${poDetail.id}-${index}-${Date.now()}`, 
        itemCode: item.item_code || '', 
        itemName: item.item_name || '', 
        orderedQty: item.qty || 0, 
        receivedQty: 0, 
        rejectedQty: 0, 
        uom: item.uom || '', 
        rate: item.rate || 0, 
        remarks: '', 
        poItemId: item.id, 
        itemId: masterMatch?.id, 
        taxId: taxInfo.taxId, 
        taxType: taxInfo.taxType, 
        taxRate: taxInfo.taxRate || 0, 
        hsn: item.hsn || '', 
        isDraft: false, 
      }; 
    }); 
 
    // FIX: Robust warehouse resolution.
    // PO's `set_warehouse` is a NAME string, but we must resolve it to an ID.
    // Previously, if there was no exact name match, warehouseId stayed
    // undefined → validation failed with "Warehouse is required" even
    // though the UI displayed the name. Now we try:
    //   1. Exact case-insensitive match
    //   2. Partial (includes) match — handles "Raw Material Store" vs "Raw Material"
    //   3. Fall back to the default "Raw Material" warehouse
    let warehouseId: number | undefined;
    let resolvedWarehouseName = poDetail.set_warehouse || '';
    if (poDetail.set_warehouse) {
      const normalizedPoWarehouse = (poDetail.set_warehouse || '').trim().toLowerCase();
      const exactMatch = warehouses.find(
        w => (w.warehouse_name || '').trim().toLowerCase() === normalizedPoWarehouse
      );
      if (exactMatch) {
        warehouseId = exactMatch.id;
        resolvedWarehouseName = exactMatch.warehouse_name;
      } else {
        const partialMatch = warehouses.find(w =>
          (w.warehouse_name || '').trim().toLowerCase().includes(normalizedPoWarehouse) ||
          normalizedPoWarehouse.includes((w.warehouse_name || '').trim().toLowerCase())
        );
        if (partialMatch) {
          warehouseId = partialMatch.id;
          resolvedWarehouseName = partialMatch.warehouse_name;
        }
      }
    }
    // If still unresolved, fall back to the default "Raw Material" warehouse
    if (!warehouseId) {
      const defaultWh = warehouses.find(w =>
        (w.warehouse_name || '').trim().toLowerCase().includes('raw material')
      );
      if (defaultWh) {
        warehouseId = defaultWh.id;
        resolvedWarehouseName = defaultWh.warehouse_name;
      }
    }
 
    let supplierId: number | undefined = poDetail.supplier_id; 
    if (!supplierId && poDetail.supplier) { 
      const supplierNum = parseInt(poDetail.supplier); 
      if (!isNaN(supplierNum)) { 
        supplierId = supplierNum; 
      } 
    } 
 
    const poName = poDetail.name || `PO-${String(poDetail.id).padStart(5, '0')}`; 
 
    setFormData(prev => ({ 
      ...prev, 
      supplier: poDetail.supplier_name || '', 
      supplierId: supplierId, 
      purchaseOrder: poName, 
      purchaseOrderId: poDetail.id, 
      warehouse: resolvedWarehouseName,   // FIX: use resolved name (matches warehouse record)
      warehouseId: warehouseId,           // FIX: now correctly set when possible
      items: items, 
    })); 
 
    // 🆕 Keep the search term empty so the next focus shows the full PO list
    //    again. The input will display `formData.purchaseOrder` while
    //    unfocused thanks to the `poDisplayValue` computed above.
    setPOSearchTerm('');
    setIsPOFocused(false);
    if (poDetail.supplier_name) { 
      setSupplierSearchTerm(poDetail.supplier_name); 
    } 
    if (resolvedWarehouseName) { 
      setWarehouseSearchTerm(resolvedWarehouseName);   // FIX: use resolved name
    } 
    if (poDetail.company) { 
      setCompany(poDetail.company); 
    } 
     
    setIsDirty(true); 
  }; 
 
  // ─── Filtered lists ────────────────────────────────────────────────── 
  const filteredWarehouses = warehouses.filter(w => 
    (w.warehouse_name?.toLowerCase() || '').includes((warehouseSearchTerm || '').toLowerCase()) 
  ); 
 
  const filteredEmployees = employees.filter(e => { 
    const name = (e.employee_name || '').toLowerCase(); 
    const designation = (e.designation || '').toLowerCase(); 
    const department = (e.department || '').toLowerCase(); 
    const search = (employeeSearchTerm || '').toLowerCase(); 
    return name.includes(search) || designation.includes(search) || department.includes(search); 
  }); 
 
  const filteredCustomers = customers.filter(c => { 
    const name = (c.customer_name || '').toLowerCase(); 
    const email = (c.email_id || '').toLowerCase(); 
    const mobile = (c.mobile_no || ''); 
    const search = (customerSearchTerm || '').toLowerCase(); 
    return name.includes(search) || email.includes(search) || mobile.includes(search); 
  }); 
 
  const filteredSuppliers = suppliers.filter(s => { 
    const name = (s.supplier_name || '').toLowerCase(); 
    const email = (s.email_id || '').toLowerCase(); 
    const mobile = (s.mobile_no || ''); 
    const search = (supplierSearchTerm || '').toLowerCase(); 
    return name.includes(search) || email.includes(search) || mobile.includes(search); 
  }); 
 
  const selectedSupplier = formData.supplierId 
    ? suppliers.find(s => s.id === formData.supplierId) 
    : undefined; 
 
  const selectedCustomer = formData.customerId 
    ? customers.find(c => c.id === formData.customerId) 
    : undefined; 
 
  // ─── Fetch PO items on hover ────────────────────────────────────────── 
  const fetchPOItems = async (poId: number) => { 
    if (isViewMode) return;
    if (poItemsCache[poId]) return; 
    setLoadingPOItems(prev => ({ ...prev, [poId]: true })); 
    try { 
      const response = await api.get<PODetailApiResponse>(`/purchase-order/${poId}`); 
      if (response.data.success === 1) { 
        setPoItemsCache(prev => ({ 
          ...prev, 
          [poId]: response.data.data.items || [] 
        })); 
      } 
    } catch (err) { 
      console.error('Error fetching PO items:', err); 
    } finally { 
      setLoadingPOItems(prev => ({ ...prev, [poId]: false })); 
    } 
  }; 
 
  // ─── Get display name for PO ────────────────────────────────────────── 
  const getPODisplayName = (po: PurchaseOrder): string => { 
    if (po.name && po.name !== 'N/A' && po.name !== 'Draft') { 
      return po.name; 
    } 
    return `PO-${String(po.id).padStart(5, '0')}`; 
  }; 
 
  // 🆕 Filter POs only by the typed search term — supplier filter has been
  //    removed so all POs (from any supplier) are always visible and
  //    selectable in the dropdown.
  const filteredPOs = purchaseOrders.filter(po => { 
    const searchLower = (poSearchTerm || '').toLowerCase(); 
    const poDisplayName = getPODisplayName(po).toLowerCase(); 
    const supplierName = (po.supplier_name || '').toLowerCase(); 
    const poIdString = (po.id?.toString() || ''); 
     
    return poDisplayName.includes(searchLower) ||  
           supplierName.includes(searchLower) ||  
           poIdString.includes(searchLower); 
  }); 
 
  // ─── Update Dropdown Position for Portal ─────────────────────────── 
  const updateDropdownPosition = (index: number) => { 
    const inputEl = inputRefs.current[index]; 
    if (inputEl) { 
      const rect = inputEl.getBoundingClientRect(); 
      setDropdownPositions(prev => ({ 
        ...prev, 
        [index]: { 
          top: rect.bottom + 4, 
          left: rect.left, 
          width: Math.max(rect.width, 320) 
        } 
      })); 
    } 
  }; 
 
  // ─── Click outside handlers ────────────────────────────────────────── 
  useEffect(() => { 
    const handleClickOutside = (event: MouseEvent) => { 
      if ( 
        warehouseDropdownRef.current &&  
        !warehouseDropdownRef.current.contains(event.target as Node) && 
        warehouseInputRef.current && 
        !warehouseInputRef.current.contains(event.target as Node) 
      ) { 
        setShowWarehouseDropdown(false); 
      } 
      if ( 
        employeeDropdownRef.current &&  
        !employeeDropdownRef.current.contains(event.target as Node) && 
        employeeInputRef.current && 
        !employeeInputRef.current.contains(event.target as Node) 
      ) { 
        setShowEmployeeDropdown(false); 
      } 
      if ( 
        poDropdownRef.current &&  
        !poDropdownRef.current.contains(event.target as Node) && 
        poInputRef.current && 
        !poInputRef.current.contains(event.target as Node) 
      ) { 
        setShowPODropdown(false); 
      } 
      if ( 
        customerDropdownRef.current && 
        !customerDropdownRef.current.contains(event.target as Node) && 
        customerInputRef.current && 
        !customerInputRef.current.contains(event.target as Node) 
      ) { 
        setShowCustomerDropdown(false); 
      } 
      if ( 
        supplierDropdownRef.current && 
        !supplierDropdownRef.current.contains(event.target as Node) && 
        supplierInputRef.current && 
        !supplierInputRef.current.contains(event.target as Node) 
      ) { 
        setShowSupplierDropdown(false); 
      } 
      if ( 
        itemSearchDropdownRef.current && 
        !itemSearchDropdownRef.current.contains(event.target as Node) 
      ) { 
        setActiveItemSearchIndex(null); 
      } 
 
      formData.items.forEach((_, idx) => { 
        const inputEl = inputRefs.current[idx]; 
        const suggestionEl = suggestionRefs.current[idx]; 
        const target = event.target as Node; 
        if ( 
          inputEl && !inputEl.contains(target) && 
          (!suggestionEl || !suggestionEl.contains(target)) 
        ) { 
          setShowSuggestions(prev => ({ ...prev, [idx]: false })); 
        } 
      }); 
    }; 
 
    const handleScrollOrResize = () => { 
      formData.items.forEach((_, idx) => { 
        if (showSuggestions[idx]) { 
          updateDropdownPosition(idx); 
        } 
      }); 
    }; 
 
    document.addEventListener('mousedown', handleClickOutside); 
    window.addEventListener('scroll', handleScrollOrResize, true); 
    window.addEventListener('resize', handleScrollOrResize); 
    return () => { 
      document.removeEventListener('mousedown', handleClickOutside); 
      window.removeEventListener('scroll', handleScrollOrResize, true); 
      window.removeEventListener('resize', handleScrollOrResize); 
    }; 
  }, [formData.items, showSuggestions]); 
 
  // ─── Fetch data on mount ──────────────────────────────────────────── 
  useEffect(() => { 
    const loadData = async () => { 
      const [, , , , fetchedItemsMaster, fetchedTaxTypes] = await Promise.all([ 
        fetchWarehouses(), 
        fetchEmployees(), 
        fetchCustomers(), 
        fetchSuppliers(), 
        fetchItemsMaster(), 
        fetchTaxTypes(), 
      ]); 
 

      if (isEditMode && id) { 
        await fetchGRNData(id, fetchedTaxTypes, fetchedItemsMaster); 
      } 
 
      if (location.state?.poData) { 
        const poData = location.state.poData as PurchaseOrderDetail; 
        populateGRNFromPO(poData); 
      } 
 
      if (showPODropdown) { 
        await fetchPurchaseOrders(); 
      } 
    }; 
 
    loadData(); 
  }, [id, isEditMode, location.state]); 
 
  // ─── Default warehouse on new GRN ─────────────────────────────────── 
  // FIX: Also skip if a warehouse NAME is already set (e.g. from a PO
  // or a user pick that hasn't yet resolved to an ID). Previously this
  // effect would overwrite a PO-set warehouse with "Raw Material Store"
  // because it only checked warehouseId.
  useEffect(() => { 
    if (isEditMode) return; 
    if (formData.warehouseId) return; 
    if (formData.warehouse && formData.warehouse.trim() !== '') return;  // FIX
    if (warehouses.length === 0) return; 

    const rawMaterialWarehouse = warehouses.find(w => 
      (w.warehouse_name || '').trim().toLowerCase().includes('raw material') 
    ); 

    if (rawMaterialWarehouse) { 
      setFormData(prev => ({ 
        ...prev, 
        warehouse: rawMaterialWarehouse.warehouse_name, 
        warehouseId: rawMaterialWarehouse.id, 
      })); 
      setWarehouseSearchTerm(rawMaterialWarehouse.warehouse_name); 
    } 
  }, [warehouses, isEditMode, formData.warehouse, formData.warehouseId]); 
 
  useEffect(() => { 
    if (showPODropdown) { 
      fetchPurchaseOrders(); 
    } 
  }, [showPODropdown, poCurrentPage]); 
 
  // ─── Backfill itemId when Item Master loads ────────────────────────── 
  useEffect(() => { 
    if (itemsMaster.length === 0) return; 
    setFormData(prev => { 
      let changed = false; 
      const items = prev.items.map(it => { 
        const codeMatch = itemsMaster.find( 
          im => (im.item_code || '').trim().toLowerCase() === (it.itemCode || '').trim().toLowerCase() 
        ); 
        if (codeMatch) { 
          if (codeMatch.id !== it.itemId) { 
            changed = true; 
            return { ...it, itemId: codeMatch.id }; 
          } 
          return it; 
        } 
        return it; 
      }); 
      return changed ? { ...prev, items } : prev; 
    }); 
  }, [itemsMaster]); 
 
  // ─── FIX: Backfill warehouseId when warehouses list loads ───────────
  // Same pattern as the itemId backfill above. Handles the race where a
  // PO (or edit-mode GRN) sets `warehouse` (name string) BEFORE the
  // warehouses array has finished loading. Once warehouses arrive, we
  // resolve the name → id so validation passes.
  useEffect(() => {
    if (warehouses.length === 0) return;
    if (formData.warehouseId) return;
    if (!formData.warehouse) return;

    const normalized = formData.warehouse.trim().toLowerCase();
    const match = warehouses.find(
      w => (w.warehouse_name || '').trim().toLowerCase() === normalized
    );
    if (match) {
      setFormData(prev => ({ ...prev, warehouseId: match.id }));
      return;
    }
    // Fallback: partial match
    const partial = warehouses.find(w =>
      (w.warehouse_name || '').trim().toLowerCase().includes(normalized) ||
      normalized.includes((w.warehouse_name || '').trim().toLowerCase())
    );
    if (partial) {
      setFormData(prev => ({
        ...prev,
        warehouse: partial.warehouse_name,
        warehouseId: partial.id,
      }));
    }
  }, [warehouses, formData.warehouse, formData.warehouseId]);
 
  // ─── Fetch GRN Data for Edit ────────────────────────────────────── 
  const fetchGRNData = async ( 
    grnId: string, 
    taxTypesOverride?: TaxType[], 
    itemsMasterOverride?: ItemMaster[] 
  ) => { 
    setLoading(true); 
    const taxList = taxTypesOverride ?? taxTypes; 
    const itemMasterList = itemsMasterOverride ?? itemsMaster; 
 
    try { 
      const response = await api.get<GRNApiResponse>(`/grn/${grnId}`); 
      if (response.data.success === 1) { 
        const data = response.data.data; 
         
        const isService = data.customer_id !== null && data.customer_id !== undefined && data.supplier_id === null; 
         
        let entryMode: EntryMode = 'manual'; 
        if (data.purchase_order_id !== null && data.purchase_order_id !== undefined && data.purchase_order_id > 0) { 
          entryMode = 'supplier'; 
        } else if (data.supplier_id !== null && data.supplier_id !== undefined) { 
          entryMode = 'manual'; 
        } else { 
          entryMode = 'manual'; 
        } 
         
        const items: GRNItem[] = (data.items || []).map((item, index) => { 
          let taxId: number | undefined = item.tax_id || undefined; 
          let taxType: string | undefined = item.tax_type || undefined; 
          let taxRate: number = 0; 
           
          if (item.item_tax_template) { 
            const rateMatch = item.item_tax_template.match(/(\d+(\.\d+)?)/); 
            const rate = rateMatch ? parseFloat(rateMatch[1]) : 0; 
            taxRate = rate; 
             
            let matchingTax: TaxType | undefined = undefined; 
             
            matchingTax = taxList.find(t => { 
              const tRateMatch = t.tax_type.match(/(\d+(\.\d+)?)/); 
              const tRate = tRateMatch ? parseFloat(tRateMatch[1]) : 0; 
              return tRate === rate; 
            }); 
             
            if (!matchingTax) { 
              const templateClean = item.item_tax_template.replace(/\s/g, '').toLowerCase(); 
              matchingTax = taxList.find(t => { 
                const taxClean = t.tax_type.replace(/\s/g, '').toLowerCase(); 
                return taxClean.includes(templateClean) || templateClean.includes(taxClean); 
              }); 
            } 
             
            if (!matchingTax && rate > 0) { 
              matchingTax = taxList.find(t => { 
                const taxLower = t.tax_type.toLowerCase(); 
                return taxLower.includes(rate.toString()) && taxLower.includes('gst'); 
              }); 
            } 
             
            if (!matchingTax && rate > 0) { 
              matchingTax = taxList.find(t => { 
                const tRateMatch = t.tax_type.match(/(\d+(\.\d+)?)/); 
                const tRate = tRateMatch ? parseFloat(tRateMatch[1]) : 0; 
                return tRate === rate; 
              }); 
            } 
             
            if (matchingTax) { 
              taxId = matchingTax.tax_id; 
              taxType = matchingTax.tax_type; 
            } else { 
              taxType = item.item_tax_template; 
              const taxByRate = taxList.find(t => { 
                const tRateMatch = t.tax_type.match(/(\d+(\.\d+)?)/); 
                const tRate = tRateMatch ? parseFloat(tRateMatch[1]) : 0; 
                return tRate === rate; 
              }); 
              if (taxByRate) { 
                taxId = taxByRate.tax_id; 
                taxType = taxByRate.tax_type; 
              } 
            } 
          } 
           
          if (!taxId && !taxType) { 
            const resolved = resolveTaxInfo(item, taxList); 
            taxId = resolved.taxId; 
            taxType = resolved.taxType; 
            taxRate = resolved.taxRate || 0; 
          } 
 
          const masterMatch = itemMasterList.find( 
            im => (im.item_code || '').toLowerCase() === (item.item_code || '').toLowerCase() 
          ); 
 
          return { 
            id: item.id?.toString() || `item-${index}-${Date.now()}`, 
            itemCode: item.item_code || '', 
            itemName: item.item_name || '', 
            orderedQty: item.ordered_qty || 0, 
            receivedQty: item.received_qty || 0, 
            rejectedQty: item.rejected_qty || 0, 
            uom: item.uom || '', 
            rate: item.rate || 0, 
            remarks: item.remarks || '', 
            poItemId: item.po_item_id || item.id, 
            itemId: masterMatch?.id || item.item_id, 
            taxId: taxId, 
            taxType: taxType, 
            taxRate: taxRate, 
            hsn: item.hsn || '', 
            isDraft: false, 
          }; 
        }) || []; 
 
        let customerName = data.customer_name || ''; 
        let customerId = data.customer_id || undefined; 
         
        if (customerId && !customerName) { 
          const foundCustomer = customers.find(c => c.id === customerId); 
          if (foundCustomer) { 
            customerName = foundCustomer.customer_name; 
          } 
        } 
 
        let supplierName = data.supplier_name || ''; 
        let supplierId = data.supplier_id || undefined; 
 
        setFormData({ 
          id: data.id?.toString(), 
          grn_number: data.grn_number || '', 
          grnDate: data.grn_date ? new Date(data.grn_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0], 
          isService: isService, 
          entryMode: entryMode, 
          supplier: isService ? '' : (supplierName || ''), 
          supplierId: isService ? undefined : (supplierId || undefined), 
          purchaseOrder: data.purchase_order_id ? `PO-${String(data.purchase_order_id).padStart(5, '0')}` : '', 
          purchaseOrderId: data.purchase_order_id || undefined, 
          warehouse: data.warehouse_name || '', 
          warehouseId: data.warehouse_id || undefined, 
          customer: isService ? customerName : '', 
          customerId: isService ? customerId : undefined, 
          receivedBy: data.received_by || '', 
          receivedById: data.received_by_id, 
          vehicleNo: data.vehicle_number || '', 
          deliveryChallanNo: data.delivery_challan_no || '', 
          invoiceNo: data.invoice_number || '', 
          freeDelivery: data.is_free_delivery === undefined ? true : data.is_free_delivery === 1, 
          deliveryCharge: data.delivery_charge || 0, 
          items: items, 
        }); 
 
        setWarehouseSearchTerm(data.warehouse_name || ''); 
        setEmployeeSearchTerm(data.received_by || ''); 
         
        if (data.purchase_order_id) { 
          setPOSearchTerm(`PO-${String(data.purchase_order_id).padStart(5, '0')}`); 
        } else { 
          setPOSearchTerm(''); 
        } 
         
        if (isService && customerName) { 
          setCustomerSearchTerm(customerName); 
        } else { 
          setCustomerSearchTerm(''); 
        } 
         
        if (!isService && supplierName) { 
          setSupplierSearchTerm(supplierName); 
        } else { 
          setSupplierSearchTerm(''); 
        } 
      } 
    } catch (err) { 
      console.error('Error fetching GRN:', err); 
      setApiError('Failed to load GRN data'); 
    } finally { 
      setLoading(false); 
    } 
  }; 
 
  // ─── Validation ────────────────────────────────────────────────────── 
  const getAllValidationErrors = (): ValidationError[] => { 
    if (isViewMode) return [];
    
    const allErrors: ValidationError[] = []; 
 
    if (formData.isService) { 
      if (!(formData.customer || '').trim()) { 
        allErrors.push({ field: 'customer', label: 'Customer', message: 'Customer is required' }); 
      } 
    } else { 
      if (!(formData.supplier || '').trim()) { 
        allErrors.push({ field: 'supplier', label: 'Supplier', message: 'Supplier is required' }); 
      } 
      if (formData.entryMode === 'supplier' && !(formData.purchaseOrder || '').trim()) { 
        allErrors.push({ field: 'purchaseOrder', label: 'Purchase Order', message: 'Purchase Order is required' }); 
      } 
    } 
 
    // FIX: Accept warehouse if EITHER the ID is set OR a non-empty name is set.
    // The backfill effect will resolve the ID, but validation shouldn't fail
    // during the brief window between setting the name and resolving the ID.
    if (!formData.warehouseId && !(formData.warehouse || '').trim()) { 
      allErrors.push({ field: 'warehouse', label: 'Warehouse', message: 'Warehouse is required' }); 
    } 
 
    if (!(formData.receivedBy || '').trim()) { 
      allErrors.push({ field: 'receivedBy', label: 'Received By', message: 'Received By is required' }); 
    } 
 
    if (!formData.freeDelivery && (!formData.deliveryCharge || formData.deliveryCharge <= 0)) { 
      allErrors.push({ field: 'deliveryCharge', label: 'Delivery Charge', message: 'Enter the amount paid for delivery, or mark delivery as free' }); 
    } 
 
    if (formData.items.length === 0) { 
      allErrors.push({ field: 'items', label: 'Items', message: 'At least one item is required' }); 
    } 
 
    formData.items.forEach((item, index) => { 
      if (!(item.itemCode || '').trim()) { 
        allErrors.push({ field: `items[${index}].itemCode`, label: `Item ${index + 1} Code`, message: 'Item code is required' }); 
      } 
      if (!(item.itemName || '').trim()) { 
        allErrors.push({ field: `items[${index}].itemName`, label: `Item ${index + 1} Name`, message: 'Item name is required' }); 
      } 
      if (!Number.isFinite(item.receivedQty) || item.receivedQty <= 0) { 
        allErrors.push({ 
          field: `items[${index}].receivedQty`, 
          label: `Item ${index + 1} Received Qty`, 
          message: 'Received quantity must be greater than 0' 
        }); 
      } 
      if (item.rejectedQty < 0) { 
        allErrors.push({ field: `items[${index}].rejectedQty`, label: `Item ${index + 1} Rejected Qty`, message: 'Rejected quantity cannot be negative' }); 
      } 
      if (item.rejectedQty > item.receivedQty) { 
        allErrors.push({ field: `items[${index}].rejectedQty`, label: `Item ${index + 1} Quantities`, message: 'Rejected cannot exceed Received quantity' }); 
      } 
      if (!item.taxId) { 
        allErrors.push({ field: `items[${index}].taxId`, label: `Item ${index + 1} GST`, message: 'GST/Tax type is required' }); 
      } 
    }); 
 
    return allErrors; 
  }; 
 
  // ─── Handlers ──────────────────────────────────────────────────────── 
  const handleFieldChange = (field: keyof GRNData, value: any) => { 
    if (isViewMode) return;
    setFormData(prev => ({ ...prev, [field]: value })); 
    setIsDirty(true); 
    if (errors[field]) { 
      setErrors(prev => { 
        const newErrors = { ...prev }; 
        delete newErrors[field]; 
        return newErrors; 
      }); 
    } 
  }; 
 
  const handleServiceToggle = (checked: boolean) => { 
    if (isViewMode) return;
    if (formData.items.length > 0 || formData.supplier || formData.customer || formData.purchaseOrder) { 
      setPendingServiceToggle(checked); 
      setShowServiceToggleConfirm(true); 
    } else { 
      applyServiceToggle(checked); 
    } 
  }; 
 
  const applyServiceToggle = (checked: boolean) => { 
    if (isViewMode) return;
    setFormData(prev => ({ 
      ...prev, 
      isService: checked, 
      entryMode: checked ? 'manual' : 'supplier', 
      supplier: '', 
      supplierId: undefined, 
      purchaseOrder: '', 
      purchaseOrderId: undefined, 
      customer: '', 
      customerId: undefined, 
      items: [], 
    })); 
    if (checked) { 
      setPOSearchTerm(''); 
      setSupplierSearchTerm(''); 
    } else { 
      setCustomerSearchTerm(''); 
    } 
    setIsDirty(true); 
    setShowServiceToggleConfirm(false); 
  }; 
 
  const handleEntryModeChange = (mode: EntryMode) => { 
    if (isViewMode) return;
    setFormData(prev => ({ 
      ...prev, 
      entryMode: mode, 
      items: [], 
      purchaseOrder: mode === 'supplier' ? prev.purchaseOrder : '', 
      purchaseOrderId: mode === 'supplier' ? prev.purchaseOrderId : undefined, 
    })); 
    if (mode !== 'supplier') { 
      setPOSearchTerm(''); 
    } 
    setIsDirty(true); 
  }; 
 
  const handleWarehouseSelect = (warehouse: Warehouse) => { 
    if (isViewMode) return;
    setFormData(prev => ({  
      ...prev,  
      warehouse: warehouse.warehouse_name, 
      warehouseId: warehouse.id 
    })); 
    setWarehouseSearchTerm(warehouse.warehouse_name); 
    setShowWarehouseDropdown(false); 
    setIsDirty(true); 
  }; 
 
  const handleEmployeeSelect = (employee: Employee) => { 
    if (isViewMode) return;
    setFormData(prev => ({  
      ...prev,  
      receivedBy: employee.employee_name, 
      receivedById: employee.id 
    })); 
    setEmployeeSearchTerm(employee.employee_name); 
    setShowEmployeeDropdown(false); 
    setIsDirty(true); 
  }; 
 
  const handleCustomerSelect = (customer: Customer) => { 
    if (isViewMode) return;
    setFormData(prev => ({ 
      ...prev, 
      customer: customer.customer_name, 
      customerId: customer.id, 
    })); 
    setCustomerSearchTerm(customer.customer_name); 
    setShowCustomerDropdown(false); 
    setIsDirty(true); 
  }; 
 
  const handleSupplierSelect = (supplier: Supplier) => { 
    if (isViewMode) return;
    setFormData(prev => ({ 
      ...prev, 
      supplier: supplier.supplier_name, 
      supplierId: supplier.id, 
      purchaseOrder: '', 
      purchaseOrderId: undefined, 
    })); 
    setSupplierSearchTerm(supplier.supplier_name); 
    setShowSupplierDropdown(false); 
    setPOSearchTerm(''); 
    setPOCurrentPage(1); 
    setIsDirty(true); 
    if (formData.entryMode === 'supplier') { 
      // 🆕 We still refetch POs, but fetchPurchaseOrders no longer filters
      //    by supplier, so all POs remain available for selection.
      fetchPurchaseOrders(); 
    } 
  }; 
 
  const handlePOSelect = (po: PurchaseOrder) => { 
    if (isViewMode) return;
    const poName = getPODisplayName(po); 
    // 🆕 Don't store the full label in the search term — the input renders
    //    `formData.purchaseOrder` while unfocused, so leaving the search
    //    term empty lets the next focus show the full PO list again.
    setPOSearchTerm(''); 
    setIsPOFocused(false);
    setFormData(prev => ({ 
      ...prev, 
      purchaseOrder: poName, 
      purchaseOrderId: po.id, 
      supplier: po.supplier_name || '', 
      supplierId: po.supplier ? parseInt(po.supplier) || prev.supplierId : prev.supplierId, 
    })); 
    setSupplierSearchTerm(po.supplier_name || ''); 
    setShowPODropdown(false); 
    fetchPurchaseOrderDetail(po.id); 
  }; 
 
  const handleItemChange = (index: number, field: keyof GRNItem, value: any) => { 
    if (isViewMode) return;
    const updatedItems = [...formData.items]; 
    updatedItems[index] = { ...updatedItems[index], [field]: value }; 
    setFormData(prev => ({ ...prev, items: updatedItems })); 
    setIsDirty(true); 
  }; 
 
  // ─── Filter items based on search term and group filter ────────── 
  const filterItems = (index: number, searchTerm: string) => { 
    if (isViewMode) return;
    let filtered = allItems.length > 0 ? allItems : itemsMaster; 
     
    if (itemGroupFilter !== 'all') { 
      filtered = filtered.filter(item => item.item_group === itemGroupFilter); 
    } 
     
    if (searchTerm && searchTerm.length >= 1) { 
      const term = searchTerm.toLowerCase().trim(); 
      filtered = filtered.filter(item =>  
        (item.item_code || '').toLowerCase().includes(term) || 
        (item.item_name || '').toLowerCase().includes(term) || 
        (item.item_group && item.item_group.toLowerCase().includes(term)) || 
        (item.description && item.description.toLowerCase().includes(term)) 
      ); 
    } 
     
    setFilteredItems(prev => ({ ...prev, [index]: filtered })); 
    setShowSuggestions(prev => ({ ...prev, [index]: filtered.length > 0 || searchTerm.trim().length > 0 })); 
     
    if (inputRefs.current[index]) { 
      updateDropdownPosition(index); 
    } 
  }; 
 
  // ─── Open the item dropdown ──────────────────────────────────────── 
  const openItemDropdown = (index: number) => { 
    if (isViewMode) return;
    updateDropdownPosition(index); 
    const currentItem = formData.items[index]; 
 
    if (currentItem?.itemId) { 
      filterItems(index, ''); 
    } else { 
      const searchVal = searchTerms[index] || currentItem?.itemCode || ''; 
      filterItems(index, searchVal); 
    } 
  }; 
 
  // ─── Handle item search ───────────────────────────────────────────── 
  const handleItemSearch = (index: number, value: string) => { 
    if (isViewMode) return;
    setSearchTerms(prev => ({ ...prev, [index]: value })); 
 
    const updatedItems = [...formData.items]; 
    updatedItems[index] = {  
      ...updatedItems[index],  
      itemCode: value  
    }; 
    setFormData(prev => ({ ...prev, items: updatedItems })); 
    setIsDirty(true); 
 
    if (!value.trim()) { 
      updatedItems[index] = { 
        ...updatedItems[index], 
        itemId: undefined, 
        itemCode: '', 
        itemName: '', 
        uom: 'NOS', 
        rate: 0, 
        remarks: '', 
        hsn: '', 
        taxId: undefined, 
        taxType: undefined, 
        taxRate: 0, 
        isDraft: true, 
      }; 
      setFormData(prev => ({ ...prev, items: updatedItems })); 
      setDigitValues(prev => ({ 
        ...prev, 
        [index]: { ...prev[index], receivedQty: '0', rate: '0', rejectedQty: '0' } 
      })); 
      setShowSuggestions(prev => ({ ...prev, [index]: false })); 
 
      let filtered = allItems.length > 0 ? allItems : itemsMaster; 
      if (itemGroupFilter !== 'all') { 
        filtered = filtered.filter(item => item.item_group === itemGroupFilter); 
      } 
      setFilteredItems(prev => ({ 
        ...prev, 
        [index]: filtered, 
      })); 
      return; 
    } 
     
    filterItems(index, value); 
  }; 
 
  // ─── Handle item selection from suggestions ────────────────────── 
  const handleSelectItem = (index: number, item: ItemMaster) => { 
    if (isViewMode) return;
    const updatedItems = [...formData.items]; 
    const rate = item.standard_rate || item.valuation_rate || 0; 
    const taxInfo = resolveTaxInfo(item); 
 
    updatedItems[index] = { 
      ...updatedItems[index], 
      itemId: item.id, 
      itemCode: item.item_code, 
      itemName: item.item_name, 
      uom: item.stock_uom || 'NOS', 
      rate: rate, 
      receivedQty: updatedItems[index]?.receivedQty !== undefined && updatedItems[index]?.receivedQty !== 0 ? updatedItems[index]?.receivedQty : 1, 
      taxId: taxInfo.taxId || item.tax_id || undefined, 
      taxType: taxInfo.taxType, 
      taxRate: taxInfo.taxRate || 0, 
      hsn: item.HSN || '', 
      isDraft: true, 
    }; 
    setFormData(prev => ({ ...prev, items: updatedItems })); 
    setDigitValues(prev => ({ 
      ...prev, 
      [index]: { 
        ...prev[index], 
        rate: String(rate), 
      } 
    })); 
    setSearchTerms(prev => ({ ...prev, [index]: item.item_code })); 
    setShowSuggestions(prev => ({ ...prev, [index]: false })); 
    setShowItemDropdown(false); 
    setItemSearch(''); 
    setSelectedItemRowIndex(null); 
    setIsDirty(true); 
  }; 
 
  const handleClearItem = (index: number) => { 
    if (isViewMode) return;
    handleItemSearch(index, ''); 
  }; 
 
  const handleDigitReceivedQtyChange = (index: number, val: number | string) => { 
    if (isViewMode) return;
    const valStr = String(val); 
    const num = parseFloat(valStr) || 0; 
    setDigitValues(prev => ({ 
      ...prev, 
      [index]: { ...prev[index], receivedQty: valStr } 
    })); 
    handleItemChange(index, 'receivedQty', num); 
  }; 
 
  const handleDigitRejectedQtyChange = (index: number, val: number | string) => { 
    if (isViewMode) return;
    const valStr = String(val); 
    const num = parseFloat(valStr) || 0; 
    setDigitValues(prev => ({ 
      ...prev, 
      [index]: { ...prev[index], rejectedQty: valStr } 
    })); 
    handleItemChange(index, 'rejectedQty', num); 
  }; 
 
  const handleDigitRateChange = (index: number, val: number | string) => { 
    if (isViewMode) return;
    const valStr = String(val); 
    const num = parseFloat(valStr) || 0; 
    setDigitValues(prev => ({ 
      ...prev, 
      [index]: { ...prev[index], rate: valStr } 
    })); 
    handleItemChange(index, 'rate', num); 
  }; 
 
  const resetNewItemForm = () => { 
    setNewItem({ 
      item_name: '', 
      item_code: '', 
      item_group: '', 
      stock_uom: 'NOS', 
      standard_rate: '', 
      valuation_rate: '', 
      description: '', 
      tax_id: '', 
      quantity: '1', 
    }); 
  }; 
 
  const handleCreateNewItem = async (e?: React.FormEvent) => { 
    if (isViewMode) return;
    if (e) e.preventDefault(); 
    if (!newItem.item_name.trim()) { 
      toast.error('Item name is required'); 
      return; 
    } 
    setAddingItem(true); 
    try { 
      const generatedCode = newItem.item_code.trim() || `ITEM-${Date.now().toString().slice(-6)}`; 
      const payload = { 
        item_name: newItem.item_name.trim(), 
        item_code: generatedCode, 
        item_group: newItem.item_group.trim() || 'Raw Material', 
        stock_uom: newItem.stock_uom.trim() || 'NOS', 
        standard_rate: parseFloat(newItem.standard_rate) || 0, 
        valuation_rate: parseFloat(newItem.valuation_rate) || parseFloat(newItem.standard_rate) || 0, 
        description: newItem.description.trim() || '', 
        tax_id: newItem.tax_id ? parseInt(newItem.tax_id) : undefined, 
        is_purchase_item: 1, 
      }; 
 
      const response = await api.post('/item', payload); 
      if (response.data && response.data.success === 1) { 
        toast.success('Item created successfully'); 
        const newItemId = response.data.data?.id || response.data.data?.insertId; 
         
        const updatedList = await fetchItemsMaster(); 
         
        if (activeRowIndex !== null) { 
          const createdItem = updatedList.find(i => i.id === newItemId || i.item_code === generatedCode); 
          if (createdItem) { 
            handleSelectItem(activeRowIndex, createdItem); 
            const qtyNum = parseFloat(newItem.quantity) || 1; 
            handleDigitReceivedQtyChange(activeRowIndex, qtyNum); 
          } 
        } 
        setShowAddItemPopup(false); 
        resetNewItemForm(); 
        setPendingItemSearch(''); 
        setActiveRowIndex(null); 
      } else { 
        toast.error(response.data?.message || 'Failed to create item'); 
      } 
    } catch (err: any) { 
      console.error('Error creating item:', err); 
      if (err.response?.status === 409) { 
        toast.error('An item with this code already exists'); 
      } else { 
        toast.error(err.response?.data?.message || 'Failed to create item'); 
      } 
    } finally { 
      setAddingItem(false); 
    } 
  }; 
 
  const handleItemTaxChange = (index: number, taxId: number) => { 
    if (isViewMode) return;
    const tax = taxTypes.find(t => t.tax_id === taxId); 
    const { rate } = extractTaxInfo(tax?.tax_type); 
    const updatedItems = [...formData.items]; 
    updatedItems[index] = { 
      ...updatedItems[index], 
      taxId: taxId, 
      taxType: tax?.tax_type, 
      taxRate: rate, 
    }; 
    setFormData(prev => ({ ...prev, items: updatedItems })); 
    setIsDirty(true); 
  }; 
 
  const addItem = () => { 
    if (isViewMode) return;
    const newIdx = formData.items.length; 
    const newItem: GRNItem = { 
      id: Date.now().toString(), 
      itemCode: '', 
      itemName: '', 
      orderedQty: 0, 
      receivedQty: 0, 
      rejectedQty: 0, 
      uom: 'NOS', 
      rate: 0, 
      remarks: '', 
      taxRate: 0, 
      hsn: '', 
      isDraft: true, 
    }; 
    setFormData(prev => ({ ...prev, items: [...prev.items, newItem] })); 
    setFilteredItems(prev => ({ ...prev, [newIdx]: allItems.length > 0 ? allItems : itemsMaster })); 
    setIsDirty(true); 
  }; 
 
  const removeItem = (index: number) => { 
    if (isViewMode) return;
    setFormData(prev => ({ 
      ...prev, 
      items: prev.items.filter((_, i) => i !== index) 
    })); 
    setShowSuggestions(prev => { 
      const next = { ...prev }; 
      delete next[index]; 
      return next; 
    }); 
    setIsDirty(true); 
  }; 
 
  // ─── Bill Totals ────────────────────────────────────────────────────── 
  const billTotals = formData.items.reduce( 
    (acc, item) => { 
      const { amount, sgst, cgst, total } = computeItemAmounts(item); 
      acc.subtotal += amount; 
      acc.sgst += sgst; 
      acc.cgst += cgst; 
      acc.itemsTotal += total; 
      return acc; 
    }, 
    { subtotal: 0, sgst: 0, cgst: 0, itemsTotal: 0 } 
  ); 
  const deliveryChargeAmount = formData.freeDelivery ? 0 : (formData.deliveryCharge || 0); 
  const grandTotal = billTotals.itemsTotal + deliveryChargeAmount; 
 
  // ─── Get draft items ────────────────────────────────────────────────── 
  const draftItems = formData.items.filter(item => item.isDraft === true); 
 
  // ─── Inventory Sync ─────────────────────────────────────────────────── 
  const postInventoryForItems = async (items: GRNItem[]) => { 
    if (isViewMode) return;
    const inventoryType = formData.isService ? 'External' : 'Internal'; 
    const role = getUserRole(); 
 
    const grnId = isEditMode && id ? parseInt(id) : undefined; 
    const grnNumber = isEditMode ? formData.grn_number : undefined; 
 
    const results = await Promise.allSettled( 
      items.map((item) => { 
        const resolvedItemId = resolveItemMasterId(item); 
 
        const payload = { 
          item_Id: resolvedItemId, 
          item_code: item.itemCode, 
          warehouse_Id: formData.warehouseId, 
          actual_qty: item.receivedQty || 0, 
          ordered_qty: item.orderedQty || item.receivedQty || 0, 
          stock_uom: item.uom, 
          company: company, 
          valuation_rate: item.rate || 0, 
          modified_by: role?.name, 
          type: inventoryType, 
          grn_id: grnId, 
          grn_number: grnNumber, 
        }; 
 
        if (!resolvedItemId) { 
          console.warn( 
            `Could not resolve Item Master id for item_code "${item.itemCode}" — sending inventory entry without item_Id.` 
          ); 
        } 
 
        return api.post('/inventory', payload); 
      }) 
    ); 
 
    const failed = results.filter(r => r.status === 'rejected'); 
    if (failed.length > 0) { 
      console.error(`Failed to post ${failed.length} of ${items.length} inventory entries`, failed); 
    } 
  }; 
 
  // ─── Print ──────────────────────────────────────────────────────────── 
  const handlePrint = () => { 
    const printWindow = window.open('', '_blank', 'width=900,height=1000'); 
    if (!printWindow) { 
      setApiError('Please allow pop-ups to print this document.'); 
      return; 
    } 
 
    const partyRows = formData.isService 
      ? ` 
        <tr><td class="label">Customer</td><td>${escapeHtml(formData.customer || '-')}</td></tr> 
        <tr><td class="label">Mobile</td><td>${escapeHtml(selectedCustomer?.mobile_no || '-')}</td></tr> 
        <tr><td class="label">Email</td><td>${escapeHtml(selectedCustomer?.email_id || '-')}</td></tr> 
        <tr><td class="label">Warehouse</td><td>${escapeHtml(formData.warehouse || '-')}</td></tr> 
      ` 
      : ` 
        <tr><td class="label">Supplier</td><td>${escapeHtml(formData.supplier || '-')}</td></tr> 
        <tr><td class="label">Mobile</td><td>${escapeHtml(selectedSupplier?.mobile_no || '-')}</td></tr> 
        <tr><td class="label">Email</td><td>${escapeHtml(selectedSupplier?.email_id || '-')}</td></tr> 
        <tr><td class="label">Country</td><td>${escapeHtml(selectedSupplier?.country || '-')}</td></tr> 
        <tr><td class="label">Purchase Order</td><td>${escapeHtml(formData.entryMode === 'supplier' ? (formData.purchaseOrder || '-') : 'Manual Entry')}</td></tr> 
        <tr><td class="label">Warehouse</td><td>${escapeHtml(formData.warehouse || '-')}</td></tr> 
      `; 
 
    const itemRows = formData.items.map((item, idx) => { 
      const { sgst, cgst, total, gstPercent } = computeItemAmounts(item); 
      return ` 
        <tr> 
          <td>${idx + 1}</td> 
          <td>${escapeHtml(item.itemCode)}</td> 
          <td>${escapeHtml(item.itemName)}</td> 
          <td>${escapeHtml(item.hsn || '-')}</td> 
          <td class="num">${item.receivedQty}</td> 
          <td>${escapeHtml(item.uom)}</td> 
          <td class="num">${item.rate.toFixed(2)}</td> 
          <td class="num">${gstPercent}%</td> 
          <td class="num">${sgst.toFixed(2)}</td> 
          <td class="num">${cgst.toFixed(2)}</td> 
          <td class="num">${total.toFixed(2)}</td> 
        </tr> 
      `; 
    }).join(''); 
 
    const html = ` 
      <!DOCTYPE html> 
      <html> 
      <head> 
        <meta charset="utf-8" /> 
        <title>${escapeHtml(formData.grn_number || 'GRN')}</title> 
        <style> 
          * { box-sizing: border-box; } 
          body { font-family: Arial, Helvetica, sans-serif; color: #111827; padding: 32px; } 
          h1 { font-size: 20px; margin: 0 0 4px; } 
          .subtitle { color: #6b7280; font-size: 12px; margin-bottom: 20px; } 
          table { width: 100%; border-collapse: collapse; margin-bottom: 18px; } 
          .meta-table td { padding: 4px 8px; font-size: 12.5px; border: none; } 
          .meta-table td.label { color: #6b7280; width: 140px; } 
          .items-table th, .items-table td { border: 1px solid #d1d5db; padding: 6px 8px; font-size: 12px; } 
          .items-table th { background: #f3f4f6; text-align: left; } 
          .items-table td.num, .items-table th.num { text-align: right; } 
          .totals { width: 320px; margin-left: auto; } 
          .totals td { padding: 4px 8px; font-size: 12.5px; } 
          .totals td:last-child { text-align: right; } 
          .totals .grand td { font-weight: 700; font-size: 14px; border-top: 1px solid #111827; padding-top: 8px; } 
          .note { margin-top: 20px; font-size: 11.5px; color: #6b7280; } 
          @media print { 
            .no-print { display: none; } 
          } 
        </style> 
      </head> 
      <body> 
        <h1>${formData.isService ? 'Service Bill' : 'Goods Receipt Note'}</h1> 
        <div class="subtitle">GRN Number: ${escapeHtml(formData.grn_number || '(will be generated on save)')} &nbsp;|&nbsp; Date: ${escapeHtml(formData.grnDate)} &nbsp;|&nbsp; Received By: ${escapeHtml(formData.receivedBy || '-')}</div> 
 
        <table class="meta-table">${partyRows}</table> 
 
        <table class="items-table"> 
          <thead> 
            <tr> 
              <th>#</th> 
              <th>Code</th> 
              <th>Item</th> 
              <th>HSN</th> 
              <th class="num">Qty</th> 
              <th>UOM</th> 
              <th class="num">Rate</th> 
              <th class="num">GST</th> 
              <th class="num">SGST</th> 
              <th class="num">CGST</th> 
              <th class="num">Amount</th> 
            </tr> 
          </thead> 
          <tbody>${itemRows || '<tr><td colspan="11">No items</td></tr>'}</tbody> 
        </table> 
 
        <table class="totals"> 
          <tr><td>Subtotal</td><td>${billTotals.subtotal.toFixed(2)}</td></tr> 
          <tr><td>Total SGST</td><td>${billTotals.sgst.toFixed(2)}</td></tr> 
          <tr><td>Total CGST</td><td>${billTotals.cgst.toFixed(2)}</td></tr> 
          <tr><td>Delivery Charges${formData.freeDelivery ? ' (Free)' : ''}</td><td>${deliveryChargeAmount.toFixed(2)}</td></tr> 
          <tr class="grand"><td>Grand Total</td><td>${grandTotal.toFixed(2)}</td></tr> 
        </table> 
      </body> 
      </html> 
    `; 
 
    printWindow.document.open(); 
    printWindow.document.write(html); 
    printWindow.document.close(); 
    printWindow.focus(); 
    setTimeout(() => { 
      printWindow.print(); 
    }, 300); 
  }; 
 
  // ─── Save Handler ────────────────────────────────────────────────── 
  const handleSave = async (e: FormEvent<HTMLFormElement>) => { 
    if (isViewMode) {
      navigate('/grn');
      return;
    }
    
    e.preventDefault(); 
    setApiError(null); 
 
    const validationErrorsList = getAllValidationErrors(); 
    if (validationErrorsList.length > 0) { 
      setValidationErrors(validationErrorsList); 
      setShowValidationSummary(true); 
      return; 
    } 
 
    setSubmitting(true); 
    try { 
      let grnType = 'Internal'; 
      if (formData.isService) { 
        grnType = 'External'; 
      } else if (formData.entryMode === 'supplier') { 
        grnType = 'Internal'; 
      } else { 
        grnType = 'Internal'; 
      } 
 
      const payload: any = { 
        grn_number: formData.grn_number || `GRN-${Date.now()}`, 
        grn_date: formData.grnDate, 
        is_service: formData.isService ? 1 : 0, 
        entry_mode: formData.entryMode, 
        type: grnType, 
        status: 'submitted', 
        received_by: formData.receivedBy, 
        received_by_id: formData.receivedById, 
        warehouse_id: formData.warehouseId, 
        warehouse_name: formData.warehouse, 
        vehicle_number: formData.vehicleNo || null, 
        delivery_challan_no: formData.deliveryChallanNo || '', 
        invoice_number: formData.invoiceNo || null, 
        is_free_delivery: formData.freeDelivery ? 1 : 0, 
        delivery_charge: deliveryChargeAmount, 
        items: formData.items.map(item => { 
          const { amount, sgst, cgst, total } = computeItemAmounts(item); 
          return { 
            item_code: item.itemCode, 
            item_name: item.itemName, 
            ordered_qty: item.orderedQty || 0, 
            received_qty: item.receivedQty || 0, 
            rejected_qty: item.rejectedQty || 0, 
            uom: item.uom || '', 
            rate: item.rate || 0, 
            purchase_rate: item.rate, 
            remarks: item.remarks || null, 
            item_id: resolveItemMasterId(item), 
            tax_id: item.taxId, 
            tax_type: item.taxType, 
            item_tax_template: item.taxType || item.taxRate ? `${item.taxType || 'GST'} ${item.taxRate || 0}%` : '', 
            hsn: item.hsn || '', 
            amount: amount, 
            sgst_amount: sgst, 
            cgst_amount: cgst, 
            item_total: total, 
          }; 
        }), 
        subtotal: billTotals.subtotal, 
        total_sgst: billTotals.sgst, 
        total_cgst: billTotals.cgst, 
        grand_total: grandTotal, 
      }; 
 
      if (formData.isService) { 
        payload.customer_id = formData.customerId; 
        payload.customer_name = formData.customer; 
      } else { 
        payload.supplier_id = formData.supplierId; 
        payload.supplier_name = formData.supplier; 
        payload.purchase_order_id = formData.entryMode === 'supplier' ? formData.purchaseOrderId : undefined; 
      } 
 
      let response; 
      let isUpdate = false; 
       
      const editId = id && id !== 'new' && id !== 'view' ? parseInt(id) : null; 
 
      if (editId && !isNaN(editId) && isEditMode) { 
        payload.id = editId; 
        console.log('🔄 Updating GRN with ID:', editId); 
        response = await api.put(`/grn`, payload); 
        isUpdate = true; 
      } else { 
        console.log('✨ Creating new GRN'); 
        response = await api.post('/grn', payload); 
        isUpdate = false; 
      } 
 
      if (response.data && response.data.success === 1) { 
        console.log('GRN saved successfully:', response.data); 
        setIsDirty(false); 
        const generatedNumber = response.data?.data?.grn_number || payload.grn_number; 
        setSavedGrnNumber(generatedNumber); 
        setIsUpdateMode(isUpdate); 
 
        await postInventoryForItems(formData.items); 
 
        setShowSuccessModal(true); 
      } else { 
        setApiError(response.data?.message || 'Failed to save GRN'); 
      } 
    } catch (err: any) { 
      console.error('Error saving GRN:', err); 
 
      if (err.response) { 
        if (err.response.status === 409) { 
          setApiError('A GRN with this number already exists'); 
        } else if (err.response.status === 400) { 
          setApiError(err.response.data?.message || 'Invalid data provided'); 
        } else { 
          setApiError(err.response.data?.message || 'Failed to save GRN'); 
        } 
      } else if (err.request) { 
        setApiError('Network error. Please check your connection.'); 
      } else { 
        setApiError('An unexpected error occurred. Please try again.'); 
      } 
    } finally { 
      setSubmitting(false); 
    } 
  }; 
 
  const handleSuccessModalOk = () => { 
    setShowSuccessModal(false); 
    navigate('/grn'); 
  }; 
 
  const hasErrors = !isViewMode && getAllValidationErrors().length > 0; 
 
  const getPOStatusBadgeClass = (status: string) => { 
    const safeStatus = (status || '').toLowerCase(); 
    switch (safeStatus) { 
      case 'draft': return 'grn-status-draft'; 
      case 'submitted': return 'grn-status-submitted'; 
      case 'partially received': return 'grn-status-partial'; 
      case 'fully received': return 'grn-status-completed'; 
      case 'cancelled': return 'grn-status-rejected'; 
      case 'closed': return 'grn-status-closed'; 
      default: return 'grn-status-draft'; 
    } 
  }; 
 
  // ─── Render Add Item Popup ───────────────────────────────────────── 
  const renderAddItemPopup = () => { 
    if (!showAddItemPopup) return null; 
 
    return ( 
      <div  
        className="pof-modal-overlay"  
        onClick={() => { 
          setShowAddItemPopup(false); 
          resetNewItemForm(); 
          setPendingItemSearch(''); 
          setActiveRowIndex(null); 
        }} 
        style={{ 
          position: 'fixed', 
          top: 0, 
          left: 0, 
          right: 0, 
          bottom: 0, 
          background: 'rgba(0, 0, 0, 0.5)', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center', 
          zIndex: 10000, 
          padding: '20px', 
        }} 
      > 
        <div  
          className="pof-modal-content"  
          onClick={(e) => e.stopPropagation()} 
          style={{ 
            background: theme === 'dark-theme' ? '#1e1e2f' : '#ffffff', 
            borderRadius: '12px', 
            width: '100%', 
            maxWidth: '650px', 
            maxHeight: '90vh', 
            display: 'flex', 
            flexDirection: 'column', 
            boxShadow: '0 20px 60px rgba(0,0,0,0.3)', 
            overflow: 'hidden', 
          }} 
        > 
          <div className="pof-modal-header" style={{ 
            padding: '16px 20px', 
            borderBottom: `1px solid ${theme === 'dark-theme' ? '#2a2a3a' : '#e5e7eb'}`, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between', 
          }}> 
            <h3 style={{ margin: 0, fontSize: '18px', fontWeight: 600, color: theme === 'dark-theme' ? '#e5e7eb' : '#111827' }}> 
              Add New Item 
            </h3> 
            <button  
              className="pof-modal-close-btn" 
              onClick={() => { 
                setShowAddItemPopup(false); 
                resetNewItemForm(); 
                setPendingItemSearch(''); 
                setActiveRowIndex(null); 
              }} 
              style={{ 
                background: 'transparent', 
                border: 'none', 
                fontSize: '20px', 
                cursor: 'pointer', 
                color: theme === 'dark-theme' ? '#9ca3af' : '#6b7280', 
              }} 
            > 
              × 
            </button> 
          </div> 
          <div className="pof-modal-body" style={{   
            padding: '24px 20px', 
            overflowY: 'auto', 
            maxHeight: 'calc(90vh - 140px)', 
          }}> 
            <p className="pof-modal-subtitle" style={{ color: '#6b7280', fontSize: '13px', marginBottom: '16px' }}> 
              Fill in the item details below. Fields marked with <span style={{ color: '#ef4444' }}>*</span> are required. 
            </p> 
 
            <div style={{   
              display: 'grid',   
              gridTemplateColumns: '1fr 1fr', 
              gap: '16px 20px', 
            }}> 
              {/* Item Name - Required */} 
              <div className="pof-popup-field" style={{ marginBottom: '0', gridColumn: '1 / -1' }}> 
                <label style={{   
                  display: 'block',   
                  fontSize: '13px',   
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Item Name <span style={{ color: '#ef4444' }}>*</span> 
                </label> 
                <input 
                  type="text" 
                  value={newItem.item_name} 
                  onChange={(e) => setNewItem(prev => ({ ...prev, item_name: e.target.value }))} 
                  placeholder="e.g. Cotton Yarn 40s" 
                  className="pof-form-field" 
                  autoFocus 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${String(theme) === 'dark' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>Alphabets, digits, and spaces are allowed</span> 
              </div> 
 
              {/* Item Code - Optional */} 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block',   
                  fontSize: '13px',   
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Item Code 
                </label> 
                <input 
                  type="text" 
                  value={newItem.item_code} 
                  onChange={(e) => setNewItem(prev => ({ ...prev, item_code: e.target.value.toUpperCase().replace(/[^a-zA-Z0-9\-]/g, "") }))} 
                  placeholder="Auto-generated if left empty" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>Alphabets, digits, and hyphens are allowed. Auto-generated from name if empty.</span> 
              </div> 
 
              {/* Item Group - Required */} 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Item Group <span style={{ color: '#ef4444' }}>*</span> 
                </label> 
                <input 
                  type="text" 
                  value={newItem.item_group} 
                  onChange={(e) => setNewItem(prev => ({ ...prev, item_group: e.target.value }))} 
                  placeholder="e.g. Raw Material, Finished Goods" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>Only alphabets and spaces are allowed</span> 
              </div> 
 
              {/* Default UOM - Required */} 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Default UOM <span style={{ color: '#ef4444' }}>*</span> 
                </label> 
                <input 
                  type="text" 
                  value={newItem.stock_uom} 
                  onChange={(e) => setNewItem(prev => ({ ...prev, stock_uom: e.target.value }))} 
                  placeholder="e.g. NOS, Kg, Meter" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>Alphabets, digits, and spaces are allowed</span> 
              </div> 
 
              {/* Tax - Optional */} 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Tax 
                </label> 
                <select 
                  value={newItem.tax_id} 
                  onChange={(e) => setNewItem(prev => ({ ...prev, tax_id: e.target.value }))} 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                > 
                  <option value="">Default Tax</option> 
                  {taxTypes.map(tax => { 
                    const { rate, category } = extractTaxInfo(tax.tax_type); 
                    return ( 
                      <option key={tax.tax_id} value={String(tax.tax_id)}> 
                        {category} {rate}% 
                      </option> 
                    ); 
                  })} 
                </select> 
              </div> 
 
              {/* Quantity */} 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Quantity <span style={{ color: '#ef4444' }}>*</span> 
                </label> 
                <input 
                  type="text" 
                  inputMode="decimal" 
                  pattern="[0-9]*[.]?[0-9]*" 
                  value={newItem.quantity} 
                  onChange={(e) => { 
                    const val = e.target.value.replace(/[^0-9.]/g, ""); 
                    setNewItem(prev => ({ ...prev, quantity: val })); 
                  }} 
                  placeholder="1" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>Quantity for this GRN line item</span> 
              </div> 
 
              {/* Pricing - Two columns */} 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Purchase Rate (base price) 
                </label> 
                <input 
                  type="text" 
                  inputMode="decimal" 
                  pattern="[0-9]*[.]?[0-9]*" 
                  value={newItem.standard_rate} 
                  onChange={(e) => { 
                    const val = e.target.value.replace(/[^0-9.]/g, ""); 
                    setNewItem(prev => ({ ...prev, standard_rate: val })); 
                  }} 
                  placeholder="0.00" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>The cost at which you purchase this item.</span> 
              </div> 
 
              <div className="pof-popup-field" style={{ marginBottom: '0' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Valuation Rate 
                </label> 
                <input 
                  type="text" 
                  inputMode="decimal" 
                  pattern="[0-9]*[.]?[0-9]*" 
                  value={newItem.valuation_rate} 
                  onChange={(e) => { 
                    const val = e.target.value.replace(/[^0-9.]/g, ""); 
                    setNewItem(prev => ({ ...prev, valuation_rate: val })); 
                  }} 
                  placeholder="0.00" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
                <span style={{ fontSize: '11px', color: '#6b7280' }}>The rate at which this item is valued. Used as Price Before Tax.</span> 
              </div> 
 
              {/* Description - Optional */} 
              <div className="pof-popup-field" style={{ marginBottom: '0', gridColumn: '1 / -1' }}> 
                <label style={{   
                  display: 'block', 
                  fontSize: '13px', 
                  fontWeight: 500, 
                  marginBottom: '4px', 
                  color: theme === 'dark-theme' ? '#e5e7eb' : '#374151' 
                }}> 
                  Description 
                </label> 
                <input 
                  type="text" 
                  value={newItem.description} 
                  onChange={(e) => setNewItem(prev => ({ ...prev, description: e.target.value }))} 
                  placeholder="Item description" 
                  className="pof-form-field" 
                  style={{ 
                    width: '100%', 
                    padding: '8px 12px', 
                    border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                    borderRadius: '6px', 
                    fontSize: '14px', 
                    background: theme === 'dark-theme' ? '#2a2a3a' : '#ffffff', 
                    color: theme === 'dark-theme' ? '#e5e7eb' : '#111827', 
                  }} 
                /> 
              </div> 
            </div> 
          </div> 
          <div className="pof-modal-footer" style={{ 
            padding: '16px 20px', 
            borderTop: `1px solid ${theme === 'dark-theme' ? '#2a2a3a' : '#e5e7eb'}`, 
            display: 'flex', 
            justifyContent: 'flex-end', 
            gap: '12px', 
          }}> 
            <button 
              type="button" 
              className="pof-btn-cancel" 
              onClick={() => { 
                setShowAddItemPopup(false); 
                resetNewItemForm(); 
                setPendingItemSearch(''); 
                setActiveRowIndex(null); 
              }} 
              style={{ 
                padding: '8px 16px', 
                borderRadius: '6px', 
                border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#d1d5db'}`, 
                background: 'transparent', 
                color: theme === 'dark-theme' ? '#e5e7eb' : '#374151', 
                cursor: 'pointer', 
                fontWeight: 500, 
              }} 
            > 
              Cancel 
            </button> 
            <button 
              type="button" 
              className="pof-btn-submit" 
              onClick={() => handleCreateNewItem()} 
              disabled={addingItem} 
              style={{ 
                padding: '8px 20px', 
                borderRadius: '6px', 
                border: 'none', 
                background: '#6366f1', 
                color: '#ffffff', 
                cursor: 'pointer', 
                fontWeight: 500, 
                display: 'flex', 
                alignItems: 'center', 
                gap: '6px', 
              }} 
            > 
              {addingItem && <FaSpinner className="pof-spinning" size={12} />} 
              Create Item 
            </button> 
          </div> 
        </div> 
      </div> 
    ); 
  }; 
 
 
 
  if (loading) {
    return (
      <div className={`grnf-page ${theme}`}>
        <div className="grnf-inner">
          <PageLoader 
            message="Loading GRN From..." 
          />
        </div>
      </div>
    );
  }
 
  return ( 
    <div className={`grnf-page ${theme}`}> 
      <div className="grnf-inner"> 
 
        {renderAddItemPopup()} 
 
        {showSuccessModal && ( 
          <div className="grnf-modal-overlay" onClick={() => setShowSuccessModal(false)}> 
            <div className="grnf-success-modal" onClick={(e) => e.stopPropagation()}> 
              <div className="grnf-success-icon-circle"> 
                <FaCheckCircle size={48} /> 
              </div> 
              <h2>{isUpdateMode ? 'GRN Updated Successfully!' : 'GRN Created Successfully!'}</h2> 
              <p className="grnf-success-message"> 
                {isUpdateMode  
                  ? 'Your Goods Receipt Note has been updated successfully.' 
                  : 'Your Goods Receipt Note has been saved successfully.'} 
              </p> 
              <div className="grnf-success-grn-box"> 
                <span className="grnf-success-label">GRN Number</span> 
                <span className="grnf-success-number">{savedGrnNumber}</span> 
              </div> 
              <div className="grnf-success-actions"> 
                <button  
                  className="grnf-success-btn grnf-success-btn-primary"  
                  onClick={handleSuccessModalOk} 
                > 
                  View All GRNs 
                </button> 
                <button  
                  className="grnf-success-btn grnf-success-btn-secondary"  
                  onClick={() => setShowSuccessModal(false)} 
                > 
                  Continue Editing 
                </button> 
              </div> 
            </div> 
          </div> 
        )} 
 
        {showServiceToggleConfirm && ( 
          <div className="grnf-modal-overlay" onClick={() => setShowServiceToggleConfirm(false)}> 
            <div className="grnf-confirm-modal" onClick={(e) => e.stopPropagation()}> 
              <div className="grnf-confirm-icon"> 
                <FaExclamationTriangle size={32} /> 
              </div> 
              <h3>Confirm Mode Change</h3> 
              <p className="grnf-confirm-message"> 
                Switching to <strong>{pendingServiceToggle ? 'Service' : 'Supplier'}</strong> mode will clear all current items and selections.  
                This action cannot be undone. 
              </p> 
              <p className="grnf-confirm-warning">Are you sure you want to continue?</p> 
              <div className="grnf-confirm-actions"> 
                <button  
                  className="grnf-confirm-btn grnf-confirm-btn-cancel"  
                  onClick={() => setShowServiceToggleConfirm(false)} 
                > 
                  No, Keep Current 
                </button> 
                <button  
                  className="grnf-confirm-btn grnf-confirm-btn-proceed"  
                  onClick={() => applyServiceToggle(pendingServiceToggle)} 
                > 
                  Yes, Switch Mode 
                </button> 
              </div> 
            </div> 
          </div> 
        )} 
 
        {showValidationSummary && validationErrors.length > 0 && ( 
          <div className="grnf-modal-overlay" onClick={() => setShowValidationSummary(false)}> 
            <div className="grnf-validation-modal" onClick={(e) => e.stopPropagation()}> 
              <div className="grnf-modal-header"> 
                <h2> 
                  <FaExclamationTriangle /> Missing Required Fields 
                </h2> 
                <button className="grnf-modal-close" onClick={() => setShowValidationSummary(false)}>×</button> 
              </div> 
              <div className="grnf-modal-body"> 
                <p className="grnf-modal-description"> 
                  Please fill in the following required fields before submitting: 
                </p> 
                <div className="grnf-validation-errors-list"> 
                  {validationErrors.map((error, idx) => ( 
                    <div key={idx} className="grnf-validation-error-item"> 
                      <div className="grnf-error-header"> 
                        <FaTimesCircle className="grnf-error-icon" /> 
                        <strong>{error.label}</strong> 
                      </div> 
                      <div className="grnf-error-message">{error.message}</div> 
                    </div> 
                  ))} 
                </div> 
                <div className="grnf-validation-tip"> 
                  <FaInfoCircle className="grnf-tip-icon" /> 
                  Please fix the errors above before submitting 
                </div> 
              </div> 
              <div className="grnf-modal-footer"> 
                <button className="grnf-btn-cancel" onClick={() => setShowValidationSummary(false)}> 
                  Close 
                </button> 
              </div> 
            </div> 
          </div> 
        )} 
 
        {apiError && ( 
          <div className="grnf-api-error"> 
            <FaExclamationCircle className="grnf-error-icon" /> 
            <span>{apiError}</span> 
            <button className="grnf-error-close" onClick={() => setApiError(null)}>×</button> 
          </div> 
        )} 
 
        <div className="grnf-header"> 
          <button onClick={() => navigate('/grn')} className="grnf-back-btn"> 
            <FaArrowLeft size={9} /> Back 
          </button> 
          <div className="grnf-header-title"> 
            <h1>
              {isViewMode ? 'View Goods Receipt Note' : isNew ? 'New Goods Receipt Note' : `${formData.grn_number}`}
            </h1>
            {renderViewModeBadge()}
          </div> 
          <button type="button" onClick={handlePrint} className="grnf-print-btn"> 
            <FaPrint size={12} /> Print 
          </button> 
          {!isViewMode && hasErrors && ( 
            <div className="grnf-error-badge"> 
              <FaExclamationTriangle size={12} /> 
              {getAllValidationErrors().length} missing field{getAllValidationErrors().length !== 1 ? 's' : ''} 
            </div> 
          )} 
        </div> 
 
        <form onSubmit={handleSave}> 
 
          <div className="grnf-card"> 
 
            <div className="grnf-service-toggle-row"> 
              <label className="grnf-checkbox-label"> 
                <input 
                  type="checkbox" 
                  checked={formData.isService} 
                  onChange={(e) => handleServiceToggle(e.target.checked)} 
                  disabled={isViewMode || submitting} 
                  className="grnf-checkbox" 
                /> 
                <span>Is Service Bill</span> 
              </label> 
            </div> 
 
            {!formData.isService && ( 
              <div className="grnf-entry-mode-section"> 
                <div className="grnf-entry-mode-toggle"> 
                  <button 
                    type="button" 
                    className={`grnf-mode-btn${formData.entryMode === 'supplier' ? ' grnf-mode-btn-active' : ''}`} 
                    onClick={() => handleEntryModeChange('supplier')} 
                    disabled={isViewMode || submitting} 
                  > 
                    <FaFileInvoice size={12} /> By Purchase Order 
                  </button> 
                  <button 
                    type="button" 
                    className={`grnf-mode-btn${formData.entryMode === 'manual' ? ' grnf-mode-btn-active' : ''}`} 
                    onClick={() => handleEntryModeChange('manual')} 
                    disabled={isViewMode || submitting} 
                  > 
                    <FaSearch size={12} /> Direct Entry 
                  </button> 
                </div> 
              </div> 
            )} 
 
            <div className="grnf-compact-layout"> 
               
              <div className="grnf-left-column"> 
                <div className="grnf-info-section"> 
                  <div className="grnf-section-label"> 
                    {formData.isService ? 'Customer Details' : 'Supplier & Order Details'} 
                  </div> 
                  {formData.isService ? ( 
                    <div className="grnf-info-row"> 
                      <div className="grnf-info-field"> 
                        <label>Customer <span className="grnf-required">*</span></label> 
                        <div className="grnf-warehouse-wrapper"> 
                          <input 
                            ref={customerInputRef} 
                            type="text" 
                            value={customerSearchTerm} 
                            onChange={(e) => { 
                              if (isViewMode) return;
                              setCustomerSearchTerm(e.target.value); 
                              setShowCustomerDropdown(true); 
                              setFormData(prev => ({ ...prev, customer: e.target.value, customerId: undefined })); 
                              setIsDirty(true); 
                            }} 
                            onFocus={() => { if (!isViewMode) setShowCustomerDropdown(true); }} 
                            className={`grnf-form-field${errors.customer ? ' grnf-field-error' : ''} ${isViewMode ? 'grnf-field-disabled' : ''}`} 
                            placeholder="Search customer..." 
                            disabled={isViewMode || submitting} 
                            autoComplete="off" 
                          /> 
                          {loadingCustomers && <FaSpinner className="grnf-warehouse-spinner grnf-spinning" size={14} />} 
                          {!isViewMode && showCustomerDropdown && filteredCustomers.length > 0 && ( 
                            <div ref={customerDropdownRef} className="grnf-warehouse-dropdown grnf-dropdown-large"> 
                              {filteredCustomers.map((customer) => ( 
                                <div 
                                  key={customer.id} 
                                  className="grnf-warehouse-item" 
                                  onClick={() => handleCustomerSelect(customer)} 
                                > 
                                  <div className="grnf-warehouse-item-name"> 
                                    <FaUsers className="grnf-warehouse-item-icon" size={12} /> 
                                    {customer.customer_name} 
                                  </div> 
                                  <div className="grnf-warehouse-item-details"> 
                                    {customer.customer_group && <span>{customer.customer_group}</span>} 
                                    {customer.mobile_no && <span><FaPhone size={10} /> {customer.mobile_no}</span>} 
                                  </div> 
                                </div> 
                              ))} 
                            </div> 
                          )} 
                        </div> 
                      </div> 
                      <div className="grnf-info-field"> 
                        <label>Warehouse <span className="grnf-required">*</span></label> 
                        <div className="grnf-warehouse-wrapper"> 
                          <input 
                            ref={warehouseInputRef} 
                            type="text" 
                            value={warehouseSearchTerm} 
                            onChange={(e) => { 
                              if (isViewMode) return;
                              setWarehouseSearchTerm(e.target.value); 
                              setShowWarehouseDropdown(true); 
                              setFormData(prev => ({ ...prev, warehouse: e.target.value, warehouseId: undefined })); 
                              setIsDirty(true); 
                            }} 
                            onFocus={() => { if (!isViewMode) setShowWarehouseDropdown(true); }} 
                            className={`grnf-form-field${errors.warehouse ? ' grnf-field-error' : ''} ${isViewMode ? 'grnf-field-disabled' : ''}`} 
                            placeholder="Search warehouse..." 
                            disabled={isViewMode || submitting} 
                            autoComplete="off" 
                          /> 
                          {loadingWarehouses && <FaSpinner className="grnf-warehouse-spinner grnf-spinning" size={14} />} 
                          {!isViewMode && showWarehouseDropdown && filteredWarehouses.length > 0 && ( 
                            <div ref={warehouseDropdownRef} className="grnf-warehouse-dropdown"> 
                              {filteredWarehouses.map((warehouse) => ( 
                                <div 
                                  key={warehouse.id} 
                                  className="grnf-warehouse-item" 
                                  onMouseDown={(e) => { 
                                    e.preventDefault(); 
                                    handleWarehouseSelect(warehouse); 
                                  }} 
                                >
                                  <div className="grnf-warehouse-item-name">
                                    <FaWarehouse className="grnf-warehouse-item-icon" size={12} />
                                    {warehouse.warehouse_name}
                                  </div>
                                  <div className="grnf-warehouse-item-details">
                                    {warehouse.city && <span><FaMapMarkerAlt size={10} /> {warehouse.city}</span>}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="grnf-info-row">
                        <div className="grnf-info-field">
                          <label>Supplier <span className="grnf-required">*</span></label>
                          <div className="grnf-warehouse-wrapper">
                            <input
                              ref={supplierInputRef}
                              type="text"
                              value={supplierSearchTerm}
                              onChange={(e) => {
                                setSupplierSearchTerm(e.target.value);
                                setShowSupplierDropdown(true);
                                setFormData(prev => ({ ...prev, supplier: e.target.value, supplierId: undefined }));
                                setIsDirty(true);
                              }}
                              onFocus={() => setShowSupplierDropdown(true)}
                              className={`grnf-form-field${errors.supplier ? ' grnf-field-error' : ''}`}
                              placeholder="Search supplier..."
                              disabled={submitting}
                              autoComplete="off"
                            />
                            {loadingSuppliers && <FaSpinner className="grnf-warehouse-spinner grnf-spinning" size={14} />}
                            {showSupplierDropdown && filteredSuppliers.length > 0 && (
                              <div ref={supplierDropdownRef} className="grnf-warehouse-dropdown grnf-dropdown-large">
                                {filteredSuppliers.map((supplier) => (
                                  <div
                                    key={supplier.id}
                                    className="grnf-warehouse-item"
                                    onClick={() => handleSupplierSelect(supplier)}
                                  >
                                    <div className="grnf-warehouse-item-name">
                                      <FaBuilding className="grnf-warehouse-item-icon" size={12} />
                                      {supplier.supplier_name}
                                    </div>
                                    <div className="grnf-warehouse-item-details">
                                      {supplier.supplier_type && <span>{supplier.supplier_type}</span>}
                                      {supplier.mobile_no && <span><FaPhone size={10} /> {supplier.mobile_no}</span>}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="grnf-info-field">
                          <label>Warehouse <span className="grnf-required">*</span></label>
                          <div className="grnf-warehouse-wrapper">
                            <input
                              ref={warehouseInputRef}
                              type="text"
                              value={warehouseSearchTerm}
                              onChange={(e) => {
                                setWarehouseSearchTerm(e.target.value);
                                setShowWarehouseDropdown(true);
                                setFormData(prev => ({ ...prev, warehouse: e.target.value, warehouseId: undefined }));
                                setIsDirty(true);
                              }}
                              onFocus={() => setShowWarehouseDropdown(true)}
                              className={`grnf-form-field${errors.warehouse ? ' grnf-field-error' : ''}`}
                              placeholder="Search warehouse..."
                              disabled={submitting}
                              autoComplete="off"
                            />
                            {loadingWarehouses && <FaSpinner className="grnf-warehouse-spinner grnf-spinning" size={14} />}
                            {showWarehouseDropdown && filteredWarehouses.length > 0 && (
                              <div ref={warehouseDropdownRef} className="grnf-warehouse-dropdown">
                                {filteredWarehouses.map((warehouse) => (
                                  <div
                                    key={warehouse.id}
                                    className="grnf-warehouse-item"
                                    onClick={() => handleWarehouseSelect(warehouse)}
                                  >
                                    <div className="grnf-warehouse-item-name">
                                      <FaWarehouse className="grnf-warehouse-item-icon" size={12} />
                                      {warehouse.warehouse_name}
                                    </div>
                                    <div className="grnf-warehouse-item-details">
                                      {warehouse.city && <span><FaMapMarkerAlt size={10} /> {warehouse.city}</span>}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      {formData.entryMode === 'supplier' && (
                        <div className="grnf-info-row">
                          <div className="grnf-info-field">
                            <label>Purchase Order <span className="grnf-required">*</span></label>
                            <div className="grnf-warehouse-wrapper">
                              <input
                                ref={poInputRef}
                                type="text"
                                value={poDisplayValue}
                                onChange={(e) => {
                                  setIsPOFocused(true);
                                  setPOSearchTerm(e.target.value);
                                  setShowPODropdown(true);
                                  if (e.target.value !== formData.purchaseOrder) {
                                    setFormData(prev => ({ ...prev, purchaseOrder: '', purchaseOrderId: undefined }));
                                  }
                                  setIsDirty(true);
                                }}
                                onFocus={() => {
                                  // 🆕 Clear the search term on focus so ALL POs are
                                  //    shown again — lets the user easily switch to a
                                  //    different PO after already having selected one.
                                  setIsPOFocused(true);
                                  setPOSearchTerm('');
                                  setShowPODropdown(true);
                                  fetchPurchaseOrders();
                                }}
                                onBlur={() => {
                                  // 🆕 Revert to showing the selected PO's name
                                  //    once the user leaves the field.
                                  setIsPOFocused(false);
                                }}
                                className={`grnf-form-field${errors.purchaseOrder ? ' grnf-field-error' : ''}`}
                                placeholder="Search PO..."
                                disabled={submitting}
                                autoComplete="off"
                              />
                              {loadingPOs && <FaSpinner className="grnf-warehouse-spinner grnf-spinning" size={14} />}
                              {showPODropdown && (
                                <div ref={poDropdownRef} className="grnf-warehouse-dropdown grnf-po-dropdown">
                                  {filteredPOs.length > 0 ? (
                                    filteredPOs.map(po => {
                                      const poItems = poItemsCache[po.id] || [];
                                      const isLoadingItems = loadingPOItems[po.id];
                                      const poDisplayName = getPODisplayName(po);
                                      
                                      const uniqueItems = poItems.reduce((acc, current) => {
                                        const exists = acc.find(item => item.item_code === current.item_code);
                                        if (!exists) {
                                          acc.push(current);
                                        }
                                        return acc;
                                      }, [] as POItem[]);
                                      
                                      return (
                                        <div
                                          key={po.id}
                                          className={`grnf-warehouse-item ${formData.purchaseOrderId === po.id ? 'grnf-warehouse-item-selected' : ''}`}
                                          onClick={() => handlePOSelect(po)}
                                          onMouseEnter={() => {
                                            if (!poItemsCache[po.id] && !loadingPOItems[po.id]) {
                                              fetchPOItems(po.id);
                                            }
                                          }}
                                        >
                                          <div className="grnf-warehouse-item-name" style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '4px' }}>
                                            <FaFileInvoice className="grnf-warehouse-item-icon" size={12} />
                                            <span className="grnf-po-display-name">{poDisplayName}</span>
                                            <span className={`grnf-po-status-badge ${getPOStatusBadgeClass(po.status || '')}`}>
                                              {po.status || 'Unknown'}
                                            </span>
                                            {uniqueItems.length > 0 && (
                                              <>
                                                <span className="grnf-po-item-count" style={{ marginLeft: '4px' }}>
                                                  <FaBox size={10} /> {uniqueItems.length} item{uniqueItems.length !== 1 ? 's' : ''}
                                                </span>
                                                <div className="grnf-po-items-preview" style={{ display: 'inline-flex', flexWrap: 'wrap', gap: '4px', marginTop: '2px', alignItems: 'center' }}>
                                                  {uniqueItems.map((item, idx) => (
                                                    <div key={idx} className="grnf-po-item-chip" style={{ display: 'inline-flex', alignItems: 'center', gap: '3px', fontSize: '10px', background: '#f9fafb', padding: '1px 6px', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
                                                      <span className="grnf-po-item-name" style={{ color: '#6b7280' }}>{item.item_name}</span>
                                                      <span className="grnf-po-item-qty" style={{ color: '#3b82f6', fontWeight: 500 }}>×{item.qty}</span>
                                                    </div>
                                                  ))}
                                                </div>
                                              </>
                                            )}
                                          </div>
                                          <div className="grnf-warehouse-item-details">
                                            <span>{po.supplier_name || 'N/A'}</span>
                                            <span>• {po.currency || 'INR'} {(po.grand_total || 0).toFixed(2)}</span>
                                            <span>• Received: {(po.per_received || 0)}%</span>
                                          </div>
                                          
                                          {isLoadingItems && (
                                            <div className="grnf-po-items-loading">
                                              <FaSpinner className="grnf-spinning" size={10} /> Loading items...
                                            </div>
                                          )}
                                          {!isLoadingItems && uniqueItems.length === 0 && (
                                            <div className="grnf-po-items-empty">
                                              <FaInfoCircle size={10} /> No items in this PO
                                            </div>
                                          )}
                                        </div>
                                      );
                                    })
                                  ) : (
                                    <div className="grnf-warehouse-no-results">No POs found</div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="grnf-info-field"></div>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Receipt Information Section */}
                <div className="grnf-info-section">
                  <div className="grnf-section-label">Receipt Information</div>
                  <div className="grnf-info-row">
                    <div className="grnf-info-field">
                      <label>GRN Date <span className="grnf-required">*</span></label>
                      <input
                        type="date"
                        value={formData.grnDate}
                        onChange={(e) => handleFieldChange('grnDate', e.target.value)}
                        className={`grnf-form-field${errors.grnDate ? ' grnf-field-error' : ''}`}
                        disabled={submitting}
                      />
                    </div>
                    <div className="grnf-info-field">
                      <label>Received By <span className="grnf-required">*</span></label>
                      <div className="grnf-warehouse-wrapper">
                        <input
                          ref={employeeInputRef}
                          type="text"
                          value={employeeSearchTerm}
                          onChange={(e) => {
                            setEmployeeSearchTerm(e.target.value);
                            setShowEmployeeDropdown(true);
                            setFormData(prev => ({ ...prev, receivedBy: e.target.value, receivedById: undefined }));
                            setIsDirty(true);
                          }}
                          onFocus={() => setShowEmployeeDropdown(true)}
                          className={`grnf-form-field${errors.receivedBy ? ' grnf-field-error' : ''}`}
                          placeholder="Search employee..."
                          disabled={submitting}
                          autoComplete="off"
                        />
                        {loadingEmployees && <FaSpinner className="grnf-warehouse-spinner grnf-spinning" size={14} />}
                        {showEmployeeDropdown && filteredEmployees.length > 0 && (
                          <div ref={employeeDropdownRef} className="grnf-warehouse-dropdown">
                            {filteredEmployees.map((employee) => (
                              <div
                                key={employee.id}
                                className="grnf-warehouse-item"
                                onClick={() => handleEmployeeSelect(employee)}
                              >
                                <div className="grnf-warehouse-item-name">
                                  <FaUserCircle className="grnf-warehouse-item-icon" size={12} />
                                  {employee.employee_name}
                                </div>
                                <div className="grnf-warehouse-item-details">
                                  {employee.designation && <span>{employee.designation}</span>}
                                  {employee.department && <span>• {employee.department}</span>}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Delivery Details Section */}
                <div className="grnf-info-section">
                  <div className="grnf-section-label">Delivery Details</div>
                  <div className="grnf-info-row">
                    <div className="grnf-info-field">
                      <label>Vehicle Number</label>
                      <input
                        type="text"
                        value={formData.vehicleNo}
                        onChange={(e) => handleFieldChange('vehicleNo', e.target.value)}
                        className="grnf-form-field"
                        placeholder="Enter vehicle number"
                        disabled={submitting}
                      />
                    </div>
                    <div className="grnf-info-field">
                      <label>Delivery Challan No.</label>
                      <input
                        type="text"
                        value={formData.deliveryChallanNo}
                        onChange={(e) => handleFieldChange('deliveryChallanNo', e.target.value)}
                        className="grnf-form-field"
                        placeholder="Enter challan number"
                        disabled={submitting}
                      />
                    </div>
                  </div>
                  <div className="grnf-info-row">
                    <div className="grnf-info-field">
                      <label>Invoice Number</label>
                      <input
                        type="text"
                        value={formData.invoiceNo}
                        onChange={(e) => handleFieldChange('invoiceNo', e.target.value)}
                        className="grnf-form-field"
                        placeholder="Enter invoice number"
                        disabled={submitting}
                      />
                    </div>
                    <div className="grnf-info-field"></div>
                  </div>
                </div>
              </div>

              {/* Right Column - Customer/Supplier Details Card */}
              <div className="grnf-right-column">
                {formData.isService && selectedCustomer ? (
                  <div className="grnf-party-detail-card">
                    <div className="grnf-party-card-header">
                      <FaUsers size={16} />
                      <span>Customer Details</span>
                    </div>
                    <div className="grnf-party-card-content">
                      <h3>{selectedCustomer.customer_name}</h3>
                      <div className="grnf-party-card-info">
                        {selectedCustomer.customer_type && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Type</span>
                            <span className="grnf-party-info-value">{selectedCustomer.customer_type}</span>
                          </div>
                        )}
                        {selectedCustomer.customer_group && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Group</span>
                            <span className="grnf-party-info-value">{selectedCustomer.customer_group}</span>
                          </div>
                        )}
                        {selectedCustomer.territory && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Territory</span>
                            <span className="grnf-party-info-value">{selectedCustomer.territory}</span>
                          </div>
                        )}
                        {selectedCustomer.mobile_no && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Mobile</span>
                            <span className="grnf-party-info-value">
                              <FaPhone size={10} /> {selectedCustomer.mobile_no}
                            </span>
                          </div>
                        )}
                        {selectedCustomer.email_id && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Email</span>
                            <span className="grnf-party-info-value">
                              <FaEnvelope size={10} /> {selectedCustomer.email_id}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ) : !formData.isService && selectedSupplier ? (
                  <div className="grnf-party-detail-card">
                    <div className="grnf-party-card-header">
                      <FaBuilding size={16} />
                      <span>Supplier Details</span>
                    </div>
                    <div className="grnf-party-card-content">
                      <h3>{selectedSupplier.supplier_name}</h3>
                      <div className="grnf-party-card-info">
                        {selectedSupplier.supplier_type && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Type</span>
                            <span className="grnf-party-info-value">{selectedSupplier.supplier_type}</span>
                          </div>
                        )}
                        {selectedSupplier.supplier_group && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Group</span>
                            <span className="grnf-party-info-value">{selectedSupplier.supplier_group}</span>
                          </div>
                        )}
                        {selectedSupplier.country && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Country</span>
                            <span className="grnf-party-info-value">
                              <FaGlobeAsia size={10} /> {selectedSupplier.country}
                            </span>
                          </div>
                        )}
                        {selectedSupplier.mobile_no && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Mobile</span>
                            <span className="grnf-party-info-value">
                              <FaPhone size={10} /> {selectedSupplier.mobile_no}
                            </span>
                          </div>
                        )}
                        {selectedSupplier.email_id && (
                          <div className="grnf-party-info-item">
                            <span className="grnf-party-info-label">Email</span>
                            <span className="grnf-party-info-value">
                              <FaEnvelope size={10} /> {selectedSupplier.email_id}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="grnf-party-detail-card grnf-party-empty-card">
                    <div className="grnf-party-card-header">
                      {formData.isService ? (
                        <><FaUsers size={16} /><span>Customer Details</span></>
                      ) : (
                        <><FaBuilding size={16} /><span>Supplier Details</span></>
                      )}
                    </div>
                    <div className="grnf-party-card-content">
                      <div className="grnf-party-empty-state">
                        <FaInfoCircle size={24} />
                        <p>Select a {formData.isService ? 'customer' : 'supplier'} to view details</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Delivery Charge Section */}
                <div className="grnf-party-detail-card">
                  <div className="grnf-party-card-header">
                    <FaMoneyBillWave size={16} />
                    <span>Delivery Charges</span>
                  </div>
                  <div className="grnf-party-card-content">
                    <div className="grnf-delivery-toggle">
                      <button
                        type="button"
                        className={`grnf-mode-btn${formData.freeDelivery ? ' grnf-mode-btn-active' : ''}`}
                        onClick={() => handleFieldChange('freeDelivery', true)}
                        disabled={submitting}
                      >
                        Free
                      </button>
                      <button
                        type="button"
                        className={`grnf-mode-btn${!formData.freeDelivery ? ' grnf-mode-btn-active' : ''}`}
                        onClick={() => handleFieldChange('freeDelivery', false)}
                        disabled={submitting}
                      >
                        Paid
                      </button>
                    </div>
                    {!formData.freeDelivery && (
                      <div className="grnf-delivery-amount">
                        <label>Amount <span className="grnf-required">*</span></label>
                        <DigitInput
                          value={formData.deliveryCharge}
                          onChange={(val) => handleFieldChange('deliveryCharge', val)}
                          placeholder="0"
                          maxLength={10}
                          disabled={submitting}
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* ─── STATUS SECTION REMOVED ─────────────────────────── */}
                {/* The status dropdown has been removed from the UI */}

              </div>
            </div>

            {/* ─── Items Section ────────────────────────────────────────── */}
            <div className="grnf-items-section pof-items-section">
              <div className="pif-table-header-row">
                <span className="pif-section-title" style={{ margin: 0, border: 'none', paddingBottom: 0 }}>
                  <FaBoxes className="pif-section-icon" /> Items
                </span>

                {itemGroups.length > 0 && (
                  <div className="pof-item-group-filter">
                    <button
                      type="button"
                      className={`pof-filter-btn ${itemGroupFilter === 'all' ? 'active' : ''}`}
                      onClick={() => {
                        setItemGroupFilter('all');
                        formData.items.forEach((_, idx) => {
                          const term = searchTerms[idx] || '';
                          let filtered = allItems.length > 0 ? allItems : itemsMaster;
                          if (term.length >= 1) {
                            const t = term.toLowerCase().trim();
                            filtered = filtered.filter(item => 
                              (item.item_code || '').toLowerCase().includes(t) ||
                              (item.item_name || '').toLowerCase().includes(t)
                            );
                          }
                          setFilteredItems(prev => ({ ...prev, [idx]: filtered }));
                        });
                      }}
                    >
                      {/*All Items*/}
                    </button>
                    {itemGroups.map(group => (
                      <button
                        key={group}
                        type="button"
                        className={`pof-filter-btn ${itemGroupFilter === group ? 'active' : ''}`}
                        onClick={() => {
                          setItemGroupFilter(group);
                          formData.items.forEach((_, idx) => {
                            const term = searchTerms[idx] || '';
                            let filtered = (allItems.length > 0 ? allItems : itemsMaster).filter(item => item.item_group === group);
                            if (term.length >= 1) {
                              const t = term.toLowerCase().trim();
                              filtered = filtered.filter(item => 
                                (item.item_code || '').toLowerCase().includes(t) ||
                                (item.item_name || '').toLowerCase().includes(t)
                              );
                            }
                            setFilteredItems(prev => ({ ...prev, [idx]: filtered }));
                          });
                        }}
                      >
                        {/*group*/}
                      </button>
                    ))}
                  </div>
                )}

                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <button type="button" className="pif-add-item-btn" onClick={addItem} disabled={submitting}>
                    <FaPlus size={12} /> Add Item
                  </button>
                </div>
              </div>

              {formData.items.length === 0 ? (
                <div className="pif-empty-items">
                  <FaBoxes size={32} />
                  <p>No items added</p>
                  <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>
                    {formData.isService || formData.entryMode !== 'supplier'
                      ? 'Click "Add Item" and search the item master to add items.'
                      : 'Select a Supplier and Purchase Order above to fetch items'}
                  </span>
                </div>
              ) : (
                <>
                  <div className="pif-table-block pof-table-block grnf-table-block">
                    <table className="pif-inline-table grnf-items-table pof-inline-table">
                      <thead>
                        <tr>
                          <th className="grnf-ith">#</th>
                          <th className="grnf-ith ">Item Code <span className="grnf-required">*</span></th>
                          <th className="grnf-ith">Item Name <span className="grnf-required">*</span></th>
                          <th className=" grnf-ith">HSN</th>
                          <th className="grnf-ith">Ordered Qty</th>
                          <th className="grnf-ith">Received Qty <span className="grnf-required">*</span></th>
                          <th className="grnf-ith">Rejected Qty</th>
                          <th className="pif-ith">UOM</th>
                          <th className="grnf-ith">Ordered Rate <span className="grnf-required">*</span></th>
                          
                          <th className="grnf-ith">Tax% <span className="grnf-required">*</span></th>
                          <th className="grnf-ith ">Amount</th>
                          <th className="grnf-ith">Note</th>
                          {/*<th className="pif-ith pif-ith-action">Action</th>*/}
                        </tr>
                      </thead>
                      <tbody>
                        {formData.items.map((item, index) => {
                          const { total } = computeItemAmounts(item);
                          const isDropdownOpen = (showItemDropdown && selectedItemRowIndex === index) || showSuggestions[index];
                          const suggestionsList = filteredItems[index] || (allItems.length > 0 ? allItems : itemsMaster);
                          const currentSearch = searchTerms[index] || item.itemCode || '';
                          const position = dropdownPositions[index] || {
                            top: 0,
                            left: 0,
                            width: 320,
                          };
                          const filtered = suggestionsList;
                          function selectItem(item: ItemMaster) {
                            handleSelectItem(index, item);
                          }

                          return (
                            <tr key={item.id} className="pif-itr pof-itr">
                              <td className="pif-itd pof-itd pif-itd-no pof-itd-no" data-label="#">
                                <span className="pof-mobile-row-badge">Item #{index + 1}</span>
                                <span className="pof-desktop-row-num">{index + 1}</span>
                              </td>
                              <td className="pif-itd pof-itd pof-itd-code pif-itd-code" data-label="Item Code *" style={{ position: 'relative', overflow: 'visible' }}>
                                <div style={{ position: 'relative', width: '100%' }}>
                                  <input
                                    ref={(el) => { inputRefs.current[index] = el; }}
                                    className="pif-cell-input pof-cell-input"
                                    type="text"
                                    value={item.itemCode || ''}
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      setItemSearch(value);
                                      setSelectedItemRowIndex(index);
                                      setShowItemDropdown(true);
                                      handleItemSearch(index, value);
                                    }}
                                    placeholder="Search item..."
                                    onFocus={() => {
                                      setSelectedItemRowIndex(index);
                                      setShowItemDropdown(true);
                                      setItemSearch(item.itemCode || '');
                                      openItemDropdown(index);
                                    }}
                                    onClick={() => {
                                      setSelectedItemRowIndex(index);
                                      setShowItemDropdown(true);
                                      openItemDropdown(index);
                                    }}
                                    onBlur={() => {
                                      setTimeout(() => {
                                        setShowItemDropdown(false);
                                        setShowSuggestions(prev => ({ ...prev, [index]: false }));
                                      }, 200);
                                    }}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Escape') {
                                        setShowItemDropdown(false);
                                        setShowSuggestions(prev => ({ ...prev, [index]: false }));
                                      }
                                      if (e.key === 'Backspace' && !e.currentTarget.value) {
                                        handleClearItem(index);
                                      }
                                    }}
                                    disabled={submitting}
                                    autoComplete="off"
                                  />
                                  {isDropdownOpen && (
                                    <div
        ref={(el) => { suggestionRefs.current[index] = el; }}
        className="pof-suggestions-dropdown-portal"
        style={{
          position: 'fixed',
          top: position.top,
          left: position.left,
          width: position.width,
          maxHeight: '280px',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          zIndex: 9999,
          background: theme === 'dark-theme' ? '#1e1e2f' : '#ffffff',
          borderRadius: '8px',
          boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
          border: `1px solid ${theme === 'dark-theme' ? '#3a3a4a' : '#e5e7eb'}`,
        }}
      >
        <div
          style={{
            overflowY: 'auto',
            flex: '1 1 auto',
            maxHeight: '220px',
          }}
        >
          {loadingItemsMaster ? (
            <div
              className="pof-suggestions-loading"
              style={{
                padding: '12px',
                textAlign: 'center',
                color: '#6b7280',
              }}
            >
              <FaSpinner className="pof-spinning" size={14} /> Loading items...
            </div>
          ) : filtered.length > 0 ? (
            <ul
              className="pof-dropdown-list"
              style={{ margin: 0, padding: 0, listStyle: 'none' }}
            >
              {filtered.map(item => (
                <li
                  key={item.id}
                  className="pof-suggestion-item"
                  onMouseDown={(e) => {
                    // Same important behavior as PurchaseBillForm:
                    // selection happens before the input blur.
                    e.preventDefault();
                    selectItem(item);
                  }}
                  style={{
                    padding: '8px 12px',
                    cursor: 'pointer',
                    borderBottom: `1px solid ${theme === 'dark-theme' ? '#2a2a3a' : '#f3f4f6'}`,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    transition: 'background 0.15s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background =
                      theme === 'dark-theme' ? '#2a2a3a' : '#f3f4f6';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <div>
                    <div
                      className="pof-suggestion-code"
                      style={{
                        fontWeight: 500,
                        fontSize: '13px',
                        color: theme === 'dark-theme' ? '#e5e7eb' : '#111827',
                      }}
                    >
                      {item.item_code || ''}
                    </div>

                    <div
                      className="pof-suggestion-name"
                      style={{
                        fontSize: '12px',
                        color: '#6b7280',
                      }}
                    >
                      {item.item_name || ''}
                    </div>

                    {item.HSN && (
                      <div
                        className="pof-suggestion-hsn"
                        style={{
                          fontSize: '10px',
                          color: '#9ca3af',
                        }}
                      >
                        HSN: {item.HSN}
                      </div>
                    )}
                  </div>

                  <div style={{ textAlign: 'right' }}>
                    <div
                      className="pof-suggestion-rate"
                      style={{
                        fontSize: '13px',
                        fontWeight: 500,
                        color: '#6366f1',
                      }}
                    >
                      INR {(item.standard_rate || item.valuation_rate || 0).toFixed(2)}
                    </div>

                    <div
                      className="pof-suggestion-uom"
                      style={{
                        fontSize: '10px',
                        color: '#9ca3af',
                      }}
                    >
                      UOM: {item.stock_uom || 'NOS'}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div
              className="pof-dropdown-empty"
              style={{
                padding: '12px',
                textAlign: 'center',
                color: '#6b7280',
                fontSize: '13px',
              }}
            >
              {currentSearch ? 'No items found' : 'Type to search items...'}
            </div>
          )}
        </div>
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="pif-itd pof-itd pof-itd-name pif-itd-name" data-label="Item Name *">
                                <input
                                  className="pif-cell-input pof-cell-input"
                                  type="text"
                                  value={item.itemName || ''}
                                  onChange={(e) => handleItemChange(index, 'itemName', e.target.value)}
                                  placeholder="Item name"
                                  disabled={submitting}
                                />
                              </td>
                              <td className="pif-itd pof-itd" data-label="HSN">
                                <input
                                  className="pif-cell-input pof-cell-input"
                                  type="text"
                                  value={item.hsn || ''}
                                  onChange={(e) => handleItemChange(index, 'hsn', e.target.value)}
                                  placeholder="HSN"
                                  disabled={submitting}
                                />
                              </td>
                              <td className="pif-itd pof-itd pif-itd-num" data-label="Ordered Qty">
                                <span className="pif-cell-readonly pof-uom-display">{item.orderedQty || 0}</span>
                              </td>
                              <td className="pif-itd pof-itd pif-itd-num" data-label="Received Qty *">
                                <input
                                  type="number"
                                  className="pif-cell-input pof-cell-input pif-cell-number"
                                  value={digitValues[index]?.receivedQty !== undefined ? digitValues[index].receivedQty : item.receivedQty}
                                  onChange={(e) => handleDigitReceivedQtyChange(index, e.target.value)}
                                  placeholder="0"
                                  min="0"
                                  step="any"
                                  disabled={submitting}
                                  required
                                />
                              </td>
                              <td className="pif-itd pof-itd pif-itd-num" data-label="Rejected Qty">
                                <input
                                  type="number"
                                  className="pif-cell-input pof-cell-input pif-cell-number"
                                  value={digitValues[index]?.rejectedQty !== undefined ? digitValues[index].rejectedQty : item.rejectedQty}
                                  onChange={(e) => handleDigitRejectedQtyChange(index, e.target.value)}
                                  placeholder="0"
                                  min="0"
                                  step="any"
                                  disabled={submitting}
                                />
                              </td>
                              <td className="pif-itd pof-itd" data-label="UOM">
                                <input
                                  className="pif-cell-input pof-cell-input"
                                  value={item.uom || ''}
                                  onChange={(e) => handleItemChange(index, 'uom', e.target.value)}
                                  placeholder="UOM"
                                  disabled={submitting}
                                />
                              </td>
                              <td className="pif-itd pof-itd pif-itd-num" data-label="Ordered Rate">
                                <input
                                  type="number"
                                  className="pif-cell-input pof-cell-input pif-cell-number"
                                  value={digitValues[index]?.rate !== undefined ? digitValues[index].rate : item.rate}
                                  onChange={(e) => handleDigitRateChange(index, e.target.value)}
                                  placeholder="0"
                                  min="0"
                                  step="0.01"
                                  disabled={submitting}
                                />
                              </td>
                              
                              <td className="pif-itd pof-itd pif-itd-num" data-label="Tax% *">
                                <select
                                  className="pif-cell-input pof-cell-select pof-tax-select"
                                  value={item.taxId ?? ''}
                                  onChange={(e) => handleItemTaxChange(index, parseInt(e.target.value))}
                                  disabled={submitting || loadingTaxTypes}
                                >
                                  <option value="" disabled>
                                    {loadingTaxTypes ? 'Loading...' : 'Select GST'}
                                  </option>
                                  {taxTypes.map((tax) => {
                                    const { rate, category } = extractTaxInfo(tax.tax_type);
                                    return (
                                      <option key={tax.tax_id} value={tax.tax_id}>
                                        {category} {rate}%
                                      </option>
                                    );
                                  })}
                                </select>
                              </td>
<td className="pif-itd pof-itd pif-itd-num " data-label="Amount">
                              <td className="pif-amount pof-itd-amount pif-itd-amount" >
                                ₹ {total.toFixed(2)}
                              </td>
                              </td>

                              <td className="pif-itd pof-itd pif-itd-note pof-itd-note" data-label="Note" style={{ position: 'relative' }}>
                                <button
                                  type="button"
                                  className={`pif-note-btn ${item.remarks ? 'pif-note-btn--filled' : ''}`}
                                  onClick={() => setNotePopoverIndex(notePopoverIndex === index ? null : index)}
                                  title={item.remarks || 'Add note'}
                                >
                                  <FaStickyNote size={12} />
                                </button>
                                {notePopoverIndex === index && (
                                  <div className="pif-note-popover">
                                    <textarea
                                      className="pif-note-textarea"
                                      value={item.remarks || ''}
                                      onChange={(e) => handleItemChange(index, 'remarks', e.target.value)}
                                      onBlur={() => setTimeout(() => setNotePopoverIndex(null), 150)}
                                      placeholder="Remarks / Note"
                                      rows={3}
                                      autoFocus
                                    />
                                  </div>
                                )}
                              </td>
                              {/*<td className="pif-itd pof-itd pif-itd-action pof-itd-action">
                                {formData.items.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => removeItem(index)}
                                    className="pif-remove-item-btn pof-remove-row"
                                    title="Remove item"
                                    disabled={submitting}
                                  >
                                    <FaTrash size={12} />
                                    <span className="pof-remove-row-text">Remove</span>
                                  </button>
                                )}
                              </td>*/}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* ─── Draft Items Section ───────────────────────────── */}
                  {draftItems.length > 0 && (
                    <div className="grnf-draft-items-section">
                      <div className="grnf-draft-items-header">
                        <h3>Draft Items</h3>
                        <span className="grnf-draft-badge">
                          <FaBox size={10} /> {draftItems.length} item{draftItems.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                      <div className="grnf-draft-items-list">
                        {draftItems.map((item, index) => (
                          <div key={item.id} className="grnf-draft-item">
                            <div className="grnf-draft-item-left">
                              <span className="grnf-draft-item-index">#{index + 1}</span>
                              <span className="grnf-draft-item-name">{item.itemName || 'Unnamed Item'}</span>
                              <div className="grnf-draft-item-details">
                                <span>Code: {item.itemCode || 'N/A'}</span>
                                <span>Qty: <span className="grnf-draft-item-qty">{item.receivedQty}</span></span>
                                <span>UOM: {item.uom || 'N/A'}</span>
                                <span>Rate: {item.rate || 0}</span>
                              </div>
                            </div>
                            <div className="grnf-draft-item-right">
                              <span className="grnf-draft-item-status">Draft</span>
                              <button
                                className="grnf-draft-item-remove"
                                onClick={() => removeItem(formData.items.indexOf(item))}
                                type="button"
                                disabled={submitting}
                              >
                                <FaTrash size={12} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ─── Bill Summary ─────────────────────────────────── */}
                  <div className="grnf-bill-summary">
                    <div className="grnf-bill-summary-title">
                      <FaReceipt size={14} /> Bill Summary
                    </div>
                    <div className="grnf-bill-summary-row">
                      <span>Subtotal</span>
                      <span>{billTotals.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="grnf-bill-summary-row">
                      <span><FaPercentage size={10} /> Total SGST</span>
                      <span>{billTotals.sgst.toFixed(2)}</span>
                    </div>
                    <div className="grnf-bill-summary-row">
                      <span><FaPercentage size={10} /> Total CGST</span>
                      <span>{billTotals.cgst.toFixed(2)}</span>
                    </div>
                    <div className="grnf-bill-summary-row">
                      <span><FaMoneyBillWave size={10} /> Delivery Charges{formData.freeDelivery ? ' (Free)' : ''}</span>
                      <span>{deliveryChargeAmount.toFixed(2)}</span>
                    </div>
                    <div className="grnf-bill-summary-row grnf-bill-summary-total">
                      <span>Grand Total</span>
                      <span>{grandTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </>
              )}
            </div>

          </div>

          {/* ─── Footer ────────────────────────────────────────────────── */}
          <div className="grnf-footer">
            <button
              type="button"
              onClick={() => navigate('/grn')}
              className="grnf-cancel-btn"
              disabled={submitting}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="grnf-print-footer-btn"
              disabled={submitting}
            >
              <FaPrint size={12} /> Print
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="grnf-submit-btn"
            >
              {submitting && <FaSpinner className="grnf-spinning" />}
              <FaSave size={12} />
              {isEditMode ? 'Update' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}