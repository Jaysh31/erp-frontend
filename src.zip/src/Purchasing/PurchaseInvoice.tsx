import { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  FaSearch, FaPlus, FaEdit, FaTrash, FaFilter, 
  FaTimes, FaSpinner, FaEye,
  FaFileAlt, FaCheckCircle,
  FaTimesCircle, FaClock, FaExclamationTriangle,
  FaPaperPlane, FaReceipt,
  FaAngleDoubleLeft,
  FaAngleDoubleRight,
  FaChevronLeft,
  FaChevronRight,
  FaCalendarAlt,
  FaChevronDown,
} from 'react-icons/fa';
import { useAdminTheme } from '../admin-theme/AdminThemeContext';
import toast from 'react-hot-toast';
import api from '../services/api';
import './PurchaseInvoice.css';
import { PageLoader } from '../components/PageLoader';

// ─── Date helpers ─────────────────────────────────────────────────

const toISODate = (d: Date): string => {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const formatDisplayDate = (iso: string): string => {
  if (!iso) return '';
  const [y, m, d] = iso.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

const WEEKDAY_LABELS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

// ─── 🆕 Status option shape ────────────────────────────────────
interface StatusOption {
  value: string;
  label: string;
}

// 🆕 Default statuses for Purchase Invoice dropdown.
//    These are ALWAYS shown; any extra statuses returned by the API are merged in.
const DEFAULT_STATUS_OPTIONS: StatusOption[] = [
  { value: 'All', label: 'All Status' },
  { value: 'Draft', label: 'Draft' },
  { value: 'Submitted', label: 'Submitted' },
  { value: 'Partially Paid', label: 'Partially Paid' },
  { value: 'Fully Paid', label: 'Fully Paid' },
  { value: 'Overdue', label: 'Overdue' },
  { value: 'Cancelled', label: 'Cancelled' },
];

/**
 * 🆕 Robustly extracts an array of records from any of the
 * many shapes the backend might return.
 */
function extractRecords(res: any): any[] {
  if (!res) return [];
  const d = res?.data?.data?.data ?? res?.data?.data ?? res?.data;
  if (Array.isArray(d)) return d;
  if (Array.isArray(d?.data)) return d.data;
  if (Array.isArray(d?.records)) return d.records;
  if (Array.isArray(d?.items)) return d.items;
  if (Array.isArray(res?.data)) return res.data;
  if (Array.isArray(res)) return res;
  return [];
}

// ─── 🆕 STATUS NORMALIZATION ─────────────────────────────────────
// Maps chatbot status strings → dropdown values for Purchase Invoice
function normalizeStatusForPIDropdown(raw: string | null): string | null {
  if (!raw) return null;
  const s = raw.toLowerCase().trim();
  switch (s) {
    case 'draft': return 'Draft';
    case 'submitted':
    case 'submit':
      return 'Submitted';
    case 'partially paid':
    case 'partially-paid':
    case 'partial paid':
    case 'partial':
    case 'part payment':
      return 'Partially Paid';
    case 'fully paid':
    case 'paid':
    case 'complete':
    case 'completed':
    case 'done':
      return 'Fully Paid';
    case 'overdue':
    case 'over due':
      return 'Overdue';
    case 'cancelled':
    case 'canceled':
    case 'cancel':
    case 'rejected':
      return 'Cancelled';
    default:
      return null;
  }
}

// ─── Range Calendar Component ────────────────────────────────────

interface RangeCalendarProps {
  month: Date;
  onMonthChange: (d: Date) => void;
  fromDate: string;
  toDate: string;
  onSelect: (from: string, to: string) => void;
}

function RangeCalendar({ month, onMonthChange, fromDate, toDate, onSelect }: RangeCalendarProps) {
  const year = month.getFullYear();
  const monthIndex = month.getMonth();
  const firstDayOfMonth = new Date(year, monthIndex, 1);
  const startWeekday = firstDayOfMonth.getDay();
  const totalDaysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const monthLabel = month.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const handleDayClick = (day: number) => {
    const clickedStr = toISODate(new Date(year, monthIndex, day));
    if (!fromDate || (fromDate && toDate)) {
      onSelect(clickedStr, '');
    } else if (clickedStr < fromDate) {
      onSelect(clickedStr, fromDate);
    } else {
      onSelect(fromDate, clickedStr);
    }
  };

  const cells: (number | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= totalDaysInMonth; d++) cells.push(d);

  return (
    <div style={{ userSelect: 'none' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
        <button
          type="button"
          onClick={() => onMonthChange(new Date(year, monthIndex - 1, 1))}
          style={{
            background: 'none', border: 'none', cursor: 'pointer', padding: '4px 8px',
            borderRadius: '4px', color: '#4a5568', display: 'flex', alignItems: 'center'
          }}
        >
          <FaChevronLeft size={11} />
        </button>
        <span style={{ fontWeight: 600, fontSize: '13px', color: '#1a202c' }}>{monthLabel}</span>
        <button
          type="button"
          onClick={() => onMonthChange(new Date(year, monthIndex + 1, 1))}
          style={{
            background: 'none', border: 'none', cursor: 'pointer', padding: '4px 8px',
            borderRadius: '4px', color: '#4a5568', display: 'flex', alignItems: 'center'
          }}
        >
          <FaChevronRight size={11} />
        </button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', marginBottom: '4px' }}>
        {WEEKDAY_LABELS.map((wd) => (
          <span key={wd} style={{ fontSize: '10px', fontWeight: 600, color: '#a0aec0', textAlign: 'center', padding: '4px 0' }}>
            {wd}
          </span>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', rowGap: '2px' }}>
        {cells.map((day, idx) => {
          if (day === null) return <span key={`empty-${idx}`} />;
          const dateStr = toISODate(new Date(year, monthIndex, day));
          const isFrom = dateStr === fromDate;
          const isTo = dateStr === toDate;
          const isEndpoint = isFrom || isTo;
          const inRange = !!fromDate && !!toDate && dateStr > fromDate && dateStr < toDate;
          const isToday = dateStr === toISODate(new Date());

          let borderRadius = '6px';
          if (isFrom && toDate) borderRadius = '6px 0 0 6px';
          else if (isTo && fromDate) borderRadius = '0 6px 6px 0';

          return (
            <button
              type="button"
              key={dateStr}
              onClick={() => handleDayClick(day)}
              style={{
                width: '100%',
                aspectRatio: '1',
                border: isToday && !isEndpoint ? '1px solid #3182ce' : 'none',
                borderRadius,
                background: isEndpoint ? '#3182ce' : inRange ? '#ebf8ff' : 'transparent',
                color: isEndpoint ? 'white' : '#2d3748',
                fontSize: '12px',
                fontWeight: isEndpoint ? 600 : 400,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {day}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Types ─────────────────────────────────────────────────────────

interface PurchaseInvoice {
  id: string;
  invoiceNumber: string;
  supplier: string;
  supplierCode: string;
  purchaseOrder: string;
  status: 'Draft' | 'Submitted' | 'Partially Paid' | 'Fully Paid' | 'Overdue' | 'Cancelled';
  date: string;
  dueDate: string;
  currency: string;
  totalAmount: number;
  paidAmount: number;
  balanceAmount: number;
  itemsCount: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

// API Response interface
interface ApiPurchaseInvoice {
  id: number;
  name: string;
  supplier: string;
  supplier_name: string;
  purchase_order: string;
  status: string;
  posting_date: string;
  due_date: string;
  currency: string;
  total: number;
  paid_amount: number;
  outstanding_amount: number;
  items_count: number;
  created_by: string;
  creation: string;
  modified: string;
  is_paid: number;
}

interface ApiResponse {
  success: number;
  data: {
    total: number;
    page: number;
    limit: number;
    records: ApiPurchaseInvoice[];
  };
}

// ─── Main Component ──────────────────────────────────────────────

export default function PurchaseInvoice() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  
  let theme = 'light';
  try {
    const context = useAdminTheme();
    theme = context.theme;
  } catch (error) {
    console.log('Using default light theme');
  }

  const [filterText, setFilterText] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedSupplier, setSelectedSupplier] = useState('All');
  
  // Date filters
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showDateFilterDropdown, setShowDateFilterDropdown] = useState(false);
  const [calMonth, setCalMonth] = useState<Date>(new Date());
  const dateFilterRef = useRef<HTMLDivElement>(null);
  
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<PurchaseInvoice | null>(null);
  const [loading, setLoading] = useState(false);
  const [, setFetching] = useState(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [totalRecords, setTotalRecords] = useState(0);

  const [invoices, setInvoices] = useState<PurchaseInvoice[]>([]);
  const [, setSuppliersList] = useState<string[]>([]);

  // 🆕 Status dropdown state — seeded with full default list
  const [statusOptions, setStatusOptions] = useState<StatusOption[]>(DEFAULT_STATUS_OPTIONS);
  const [statusOptionsLoading, setStatusOptionsLoading] = useState(true);

  // Mobile list row expansion state
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  const handleCreateJournalEntry = () => {
    navigate('/accounts/entry');
  };
  const toggleRowExpand = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // ====================================================================
  // 🆕 FETCH STATUS OPTIONS FROM /purchase-invoice API
  //    - Always keeps the full default list visible
  //    - Merges in any extra statuses returned by the API
  // ====================================================================
  useEffect(() => {
    let cancelled = false;

    const fetchStatusOptions = async () => {
      setStatusOptionsLoading(true);

      const endpoint = '/purchase-invoice?page=1&limit=100';
      console.log('🔵 [PI-STATUS-API] ▶️ Calling:', endpoint);

      try {
        const response = await api.get(endpoint);

        console.log('🟢 [PI-STATUS-API] ✅ Response received');
        if (cancelled) return;

        const records = extractRecords(response);
        console.log('🟢 [PI-STATUS-API] Extracted records count:', records.length);

        // Collect distinct, non-empty status strings from API
        const distinct = new Set<string>();
        records.forEach((pi: any) => {
          const st = (pi?.status ?? '').toString().trim();
          if (st) distinct.add(st);
        });

        console.log('🟢 [PI-STATUS-API] Distinct statuses found:', Array.from(distinct));

        // Skip statuses already present in the default list (case-insensitive)
        const existing = new Set(
          DEFAULT_STATUS_OPTIONS.map((o) => o.value.toLowerCase())
        );

        const apiOptions: StatusOption[] = Array.from(distinct)
          .map((s) => ({
            value: s
              .split(' ')
              .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
              .join(' '),
            label: s
              .split(' ')
              .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
              .join(' '),
          }))
          .filter((opt) => !existing.has(opt.value.toLowerCase()));

        const finalOptions: StatusOption[] = [
          ...DEFAULT_STATUS_OPTIONS,
          ...apiOptions,
        ];

        setStatusOptions(finalOptions);
        console.log('🟢 [PI-STATUS-API] Final dropdown options:', finalOptions);
      } catch (err: any) {
        console.error('🔴 [PI-STATUS-API] ❌ API call failed:', err);
        if (cancelled) return;
        setStatusOptions(DEFAULT_STATUS_OPTIONS);
      } finally {
        if (!cancelled) {
          setStatusOptionsLoading(false);
        }
      }
    };

    fetchStatusOptions();

    return () => {
      cancelled = true;
    };
  }, []);

  // ====================================================================
  // 🆕 READ FILTERS FROM URL QUERY PARAMS (chatbot navigation support)
  // ====================================================================
  useEffect(() => {
    const urlStatus = searchParams.get('status');
    const urlSupplier = searchParams.get('supplier');
    const urlSearch = searchParams.get('search');
    const urlDateFrom = searchParams.get('date_from');
    const urlDateTo = searchParams.get('date_to');
    const autoFilter = searchParams.get('autoFilter');

    let hasUrlFilters = false;

    if (urlStatus) {
      const normalized = normalizeStatusForPIDropdown(urlStatus);
      if (normalized) {
        setSelectedStatus(normalized);
        hasUrlFilters = true;
      }
    }

    if (urlSupplier) {
      setSelectedSupplier(urlSupplier);
      hasUrlFilters = true;
    }

    if (urlSearch) {
      setFilterText(urlSearch);
      hasUrlFilters = true;
    }

    if (urlDateFrom) {
      setDateFrom(urlDateFrom);
      hasUrlFilters = true;
    }
    if (urlDateTo) {
      setDateTo(urlDateTo);
      hasUrlFilters = true;
    }

    if (hasUrlFilters) {
      console.log('🔗 URL filters detected on PurchaseInvoice:', {
        status: urlStatus,
        supplier: urlSupplier,
        search: urlSearch,
        dateFrom: urlDateFrom,
        dateTo: urlDateTo,
        autoFilter,
      });
      setCurrentPage(1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // run once on mount

  // Also react to URL changes after mount (chatbot navigates while already on this page)
  useEffect(() => {
    const urlStatus = searchParams.get('status');
    const urlSupplier = searchParams.get('supplier');
    const urlSearch = searchParams.get('search');
    const urlDateFrom = searchParams.get('date_from');
    const urlDateTo = searchParams.get('date_to');

    if (urlStatus) {
      const normalized = normalizeStatusForPIDropdown(urlStatus);
      if (normalized && selectedStatus !== normalized) {
        setSelectedStatus(normalized);
      }
    }
    if (urlSupplier && selectedSupplier !== urlSupplier) {
      setSelectedSupplier(urlSupplier);
    }
    if (urlSearch && filterText !== urlSearch) {
      setFilterText(urlSearch);
    }
    if (urlDateFrom && dateFrom !== urlDateFrom) {
      setDateFrom(urlDateFrom);
    }
    if (urlDateTo && dateTo !== urlDateTo) {
      setDateTo(urlDateTo);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);
  
  // ─── Click outside handler ──────────────────────────────────────

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dateFilterRef.current && !dateFilterRef.current.contains(event.target as Node)) {
        setShowDateFilterDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // ─── Quick presets for the calendar ──────────────────────────

  const applyPreset = (preset: 'today' | 'last7' | 'last30' | 'thisMonth') => {
    const today = new Date();
    let from = today;
    let to = today;

    if (preset === 'last7') {
      from = new Date(today);
      from.setDate(today.getDate() - 6);
    } else if (preset === 'last30') {
      from = new Date(today);
      from.setDate(today.getDate() - 29);
    } else if (preset === 'thisMonth') {
      from = new Date(today.getFullYear(), today.getMonth(), 1);
    }

    const fromStr = toISODate(from);
    const toStr = toISODate(to);

    setDateFrom(fromStr);
    setDateTo(toStr);
    setCalMonth(from);
  };

  const clearDateRange = () => {
    setDateFrom('');
    setDateTo('');
  };

  const dateButtonLabel = () => {
    if (dateFrom) {
      return `${formatDisplayDate(dateFrom)}${dateTo ? ' – ' + formatDisplayDate(dateTo) : ''}`;
    }
    return 'From - To';
  };

  // Map API status to component status
  const mapStatus = (apiStatus: string): PurchaseInvoice['status'] => {
    switch (apiStatus?.toLowerCase()) {
      case 'draft': return 'Draft';
      case 'submitted': return 'Submitted';
      case 'partially paid':
      case 'partial': return 'Partially Paid';
      case 'fully paid':
      case 'paid': return 'Fully Paid';
      case 'overdue': return 'Overdue';
      case 'cancelled': return 'Cancelled';
      default: return 'Draft';
    }
  };

  // Fetch purchase invoices from API with SERVER-SIDE PAGINATION
  const fetchPurchaseInvoices = async () => {
    setFetching(true);
    setApiError(null);
    try {
      const params = new URLSearchParams();
      
      params.append('page', String(currentPage));
      params.append('limit', String(itemsPerPage));

      if (filterText.trim()) {
        params.append('search', filterText.trim());
      }

      // ✅ Send selected status to the API so filtering happens server-side
      if (selectedStatus && selectedStatus !== 'All') {
        params.append('status', selectedStatus);
      }

      if (dateFrom) {
        params.append('date_from', dateFrom);
      }
      if (dateTo) {
        params.append('date_to', dateTo);
      }

      console.log('API URL:', `/purchase-invoice?${params.toString()}`);

      const response = await api.get<ApiResponse>(`/purchase-invoice?${params.toString()}`);
      
      if (response.data.success === 1) {
        const records = response.data.data.records || [];
        setTotalRecords(response.data.data.total || 0);
        
        const transformedInvoices: PurchaseInvoice[] = records.map((item: ApiPurchaseInvoice) => ({
          id: String(item.id),
          invoiceNumber: `PI-${String(item.id).padStart(5, '0')}`,
          supplier: item.supplier_name || item.supplier || 'N/A',
          supplierCode: item.supplier || 'N/A',
          purchaseOrder: item.purchase_order || 'N/A',
          status: mapStatus(item.status),
          date: item.posting_date ? new Date(item.posting_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
          dueDate: item.due_date ? new Date(item.due_date).toISOString().split('T')[0] : '',
          currency: item.currency || 'INR',
          totalAmount: item.total || 0,
          paidAmount: item.paid_amount || 0,
          balanceAmount: item.outstanding_amount || item.total || 0,
          itemsCount: item.items_count || 0,
          createdBy: item.created_by || 'System',
          createdAt: item.creation || new Date().toISOString(),
          updatedAt: item.modified || new Date().toISOString()
        }));
        
        setInvoices(transformedInvoices);
        
        const uniqueSuppliers = [...new Set(transformedInvoices.map(inv => inv.supplier))];
        setSuppliersList(uniqueSuppliers);
      } else {
        setApiError('Failed to fetch purchase invoices');
      }
    } catch (err: any) {
      console.error('Error fetching purchase invoices:', err);
      setApiError('An error occurred while fetching purchase invoices');
    } finally {
      setFetching(false);
    }
  };

  // ✅ Refetch invoices whenever any filter (including status) changes
  useEffect(() => {
    fetchPurchaseInvoices();
  }, [currentPage, itemsPerPage, dateFrom, dateTo, filterText, selectedStatus]);

  useEffect(() => {
    setCurrentPage(1);
  }, [filterText, selectedSupplier, dateFrom, dateTo, selectedStatus]);

  const filteredInvoices = invoices.filter(inv => {
    const matchesSupplier = selectedSupplier === 'All' || inv.supplier === selectedSupplier;
    return matchesSupplier;
  });

  const totalFilteredItems = totalRecords;
  const totalPages = Math.ceil(totalFilteredItems / itemsPerPage) || 1;
  const validCurrentPage = Math.min(currentPage, totalPages || 1);
  
  if (validCurrentPage !== currentPage && currentPage > 0) {
    setCurrentPage(validCurrentPage);
  }

  const getStartIndex = () => {
    if (totalRecords === 0) return 0;
    return (validCurrentPage - 1) * itemsPerPage + 1;
  };
  
  const getEndIndex = () => {
    if (totalRecords === 0) return 0;
    return Math.min(validCurrentPage * itemsPerPage, totalRecords);
  };

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const goToFirstPage = () => goToPage(1);
  const goToLastPage = () => goToPage(totalPages);
  const goToNextPage = () => goToPage(currentPage + 1);
  const goToPrevPage = () => goToPage(currentPage - 1);

  const handlePageSizeChange = (newSize: number) => {
    setItemsPerPage(newSize);
    setCurrentPage(1);
  };

  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(totalPages, startPage + maxVisible - 1);
    if (endPage - startPage + 1 < maxVisible) startPage = Math.max(1, endPage - maxVisible + 1);
    for (let i = startPage; i <= endPage; i++) pages.push(i);
    return pages;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Draft': return 'inv-status-draft';
      case 'Submitted': return 'inv-status-submitted';
      case 'Partially Paid': return 'inv-status-partial';
      case 'Fully Paid': return 'inv-status-paid';
      case 'Overdue': return 'inv-status-overdue';
      case 'Cancelled': return 'inv-status-cancelled';
      default: return '';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Draft': return <FaFileAlt size={10} />;
      case 'Submitted': return <FaPaperPlane size={10} />;
      case 'Partially Paid': return <FaClock size={10} />;
      case 'Fully Paid': return <FaCheckCircle size={10} />;
      case 'Overdue': return <FaExclamationTriangle size={10} />;
      case 'Cancelled': return <FaTimesCircle size={10} />;
      default: return null;
    }
  };

  const handleCreate = () => {
    navigate('/purchase-invoice/new');
  };

  // ✅ UPDATED: Edit button - opens in EDIT mode (editable)
  const handleEdit = (invoice: PurchaseInvoice) => {
    navigate(`/purchase-invoice/edit/${invoice.id}?mode=edit`);
  };

  // ✅ UPDATED: Row click - opens in VIEW mode (read-only)
  const handleRowClick = (invoice: PurchaseInvoice) => {
    navigate(`/purchase-invoice/edit/${invoice.id}?mode=view`);
  };

  // ✅ UPDATED: View button - opens in VIEW mode (read-only)
  const handleView = (invoice: PurchaseInvoice, e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/purchase-invoice/edit/${invoice.id}?mode=view`);
  };

  const handleDelete = (invoice: PurchaseInvoice, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedInvoice(invoice);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = async () => {
    if (!selectedInvoice) return;
    setLoading(true);
    
    try {
      const response = await api.delete(`/purchase-invoice/${selectedInvoice.id}`);
      if (response.data.success === 1) {
        setShowDeleteModal(false);
        toast.success('Purchase Invoice deleted successfully!');
        fetchPurchaseInvoices();
      } else {
        toast.error('Failed to delete purchase invoice');
      }
    } catch (err: any) {
      console.error('Error deleting purchase invoice:', err);
      toast.error(err.response?.data?.message || 'An error occurred while deleting');
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setFilterText('');
    setSelectedStatus('All');
    setSelectedSupplier('All');
    setDateFrom('');
    setDateTo('');
    setCurrentPage(1);
    setShowDateFilterDropdown(false);

    // 🆕 Clear URL query params too
    setSearchParams({});
  };


  {/*if (fetching) {
    return (
      <div className={`inv-page ${theme}-theme`}>
        <div className="inv-loading">
          <FaSpinner className="inv-spinning" size={32} />
          <p>Loading purchase invoices...</p>
        </div>
      </div>
    );
  }*/}
    if (loading) {
    return (
      <div className={`grnf-page ${theme}`}>
        <div className="grnf-inner">
          <PageLoader 
            message="Loading Purchase Invoice..." 
            subtitle="Synchronizing warehouse receipt entries, line item counts, and supplier records"
          />
        </div>
      </div>
    );
  }

  return (
    <div className={`inv-page ${theme}-theme`}>
      {/* Search and Filter Bar */}
      <div className="inv-filter-bar">
        <div className="inv-filter-left">
          <div className="inv-search-wrapper">
            <FaSearch className="inv-search-icon" />
            <input
              type="text"
              placeholder="Search by invoice #, supplier or PO..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="inv-search-input"
            />
            {filterText && (
              <button className="inv-search-clear" onClick={() => setFilterText('')}>
                <FaTimes size={12} />
              </button>
            )}
          </div>
        </div>
        <div className="bom-filter-right">
          {/* 🆕 Status filter populated dynamically from /purchase-invoice API */}
          <select 
            value={selectedStatus} 
            onChange={(e) => {
              setSelectedStatus(e.target.value);
              setCurrentPage(1);
            }}
            className="bom-filter-select"
            disabled={statusOptionsLoading}
            title={statusOptionsLoading ? 'Loading statuses…' : 'Filter by status'}
          >
            {statusOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
          
          {/* Date Range Button with Calendar Dropdown */}
          <div ref={dateFilterRef} style={{ position: 'relative', display: 'inline-block' }}>
            <button
              className="inv-filter-btn"
              onClick={() => setShowDateFilterDropdown(!showDateFilterDropdown)}
              style={dateFrom ? { borderColor: '#3182ce', color: '#3182ce' } : undefined}
            >
              <FaCalendarAlt size={13} />
              <span style={{ maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {dateButtonLabel()}
              </span>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>

            {/* Calendar Date Filter Dropdown */}
            {showDateFilterDropdown && (
              <div className="inv-date-filter-dropdown" style={{
                position: 'absolute',
                top: '100%',
                right: '0',
                marginTop: '4px',
                backgroundColor: 'white',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
                padding: '16px',
                minWidth: '300px',
                zIndex: 1000,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <span style={{ fontWeight: 600, fontSize: '14px', color: '#1a202c' }}>Filter by Date</span>
                  <button onClick={() => setShowDateFilterDropdown(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#718096' }}>
                    <FaTimes size={14} />
                  </button>
                </div>

                {/* Selected range readout */}
                <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
                  <div style={{
                    flex: 1, padding: '6px 8px', border: '1px solid #e2e8f0', borderRadius: '4px',
                    fontSize: '12px', color: dateFrom ? '#1a202c' : '#a0aec0'
                  }}>
                    {dateFrom ? formatDisplayDate(dateFrom) : 'From'}
                  </div>
                  <div style={{
                    flex: 1, padding: '6px 8px', border: '1px solid #e2e8f0', borderRadius: '4px',
                    fontSize: '12px', color: dateTo ? '#1a202c' : '#a0aec0'
                  }}>
                    {dateTo ? formatDisplayDate(dateTo) : 'To'}
                  </div>
                </div>

                {/* Quick presets */}
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '12px' }}>
                  {([
                    { key: 'today', label: 'Today' },
                    { key: 'last7', label: 'Last 7 Days' },
                    { key: 'last30', label: 'Last 30 Days' },
                    { key: 'thisMonth', label: 'This Month' },
                  ] as const).map((p) => (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() => applyPreset(p.key)}
                      style={{
                        padding: '4px 10px',
                        border: '1px solid #e2e8f0',
                        borderRadius: '999px',
                        backgroundColor: '#f7fafc',
                        fontSize: '11px',
                        color: '#4a5568',
                        cursor: 'pointer',
                      }}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                

                {/* Calendar */}
                <RangeCalendar
                  month={calMonth}
                  onMonthChange={setCalMonth}
                  fromDate={dateFrom}
                  toDate={dateTo}
                  onSelect={(from, to) => { setDateFrom(from); setDateTo(to); }}
                />

                <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '14px' }}>
                  <button
                    onClick={clearDateRange}
                    style={{
                      padding: '6px 16px',
                      border: '1px solid #e2e8f0',
                      borderRadius: '4px',
                      backgroundColor: 'white',
                      cursor: 'pointer',
                      fontSize: '12px',
                      color: '#4a5568'
                    }}
                  >
                    Clear
                  </button>
                  <button
                    onClick={() => {
                      setShowDateFilterDropdown(false);
                      fetchPurchaseInvoices();
                    }}
                    style={{
                      padding: '6px 16px',
                      border: 'none',
                      borderRadius: '4px',
                      backgroundColor: '#3182ce',
                      color: 'white',
                      cursor: 'pointer',
                      fontSize: '12px',
                      fontWeight: 500
                    }}
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            )}
          </div>

          <button className="inv-btn-secondary" onClick={handleCreateJournalEntry}>
            <FaFileAlt size={12} /> New Journal Entry
          </button>
        </div>
       
        <div className="inv-header-actions">
          <button className="inv-btn-primary" onClick={handleCreate}>
            <FaPlus size={12} /> New Purchase Bill
          </button>
        </div>
      </div>

      {/* API Error */}
      {apiError && (
        <div className="inv-api-error">
          <FaExclamationTriangle size={16} />
          <span>{apiError}</span>
          <button onClick={fetchPurchaseInvoices} className="inv-retry-btn">Retry</button>
        </div>
      )}

      {/* Active filters indicator */}
      {(filterText || selectedStatus !== 'All' || selectedSupplier !== 'All' || dateFrom || dateTo) && (
        <div className="inv-active-filters">
          <FaFilter size={12} style={{ color: 'var(--primary-color)' }} />
          <span style={{ color: 'var(--text-primary)' }}>Active filters:</span>
          {filterText && (
            <span style={{ color: 'var(--text-primary)' }}>
              <strong>Search:</strong> "{filterText}"
            </span>
          )}
          {selectedStatus !== 'All' && (
            <span style={{ color: 'var(--text-primary)' }}>
              <strong>Status:</strong>{' '}
              {statusOptions.find((o) => o.value === selectedStatus)?.label || selectedStatus}
            </span>
          )}
          {selectedSupplier !== 'All' && (
            <span style={{ color: 'var(--text-primary)' }}>
              <strong>Supplier:</strong> {selectedSupplier}
            </span>
          )}
          {dateFrom && <span><strong>From:</strong> {dateFrom}</span>}
          {dateTo && <span><strong>To:</strong> {dateTo}</span>}
          <button 
            onClick={clearFilters}
            className="inv-clear-filters"
          >
            <FaTimes size={10} /> Clear All
          </button>
        </div>
      )}

      {/* Table */}
      <div className="inv-table-wrap inv-desktop-table-wrap">
        <table className="inv-table">
          <thead>
            <tr>
              <th className="inv-th">Invoice #</th>
              <th className="inv-th">Supplier</th>
              <th className="inv-th">Date</th>
              <th className="inv-th">Total</th>
              {/*<th className="inv-th">Balance</th>*/}
              <th className="inv-th">Status</th>
              <th className="inv-th inv-th-meta">
                <span className="inv-count-label">{filteredInvoices.length} of {totalRecords}</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredInvoices.length === 0 ? (
              <tr>
                <td colSpan={7} className="inv-empty-state">
                  <div className="inv-empty-content">
                    <FaReceipt size={48} />
                    <p>No purchase invoices found</p>
                    <span>Create your first purchase invoice to get started</span>
                    <button className="inv-btn-primary" onClick={handleCreate} style={{ marginTop: '12px' }}>
                      <FaPlus size={12} /> New Purchase Bill
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              filteredInvoices.map((inv) => (
                <tr
                  key={inv.id}
                  className="inv-tr"
                  onClick={() => handleRowClick(inv)}
                  style={{ cursor: 'pointer' }}
                >
                  <td className="inv-td inv-td-id">
                    <div>
                      <div style={{ fontWeight: 600 }}>{inv.invoiceNumber}</div>
                    </div>
                  </td>
                  <td className="inv-td">{inv.supplier}</td>
                  <td className="inv-td">{new Date(inv.date).toLocaleDateString()}</td>
                  {/*<td className="inv-td">{inv.currency} {inv.totalAmount.toLocaleString()}</td>*/}
                  <td className={`inv-td ${inv.balanceAmount > 0 && new Date(inv.dueDate) < new Date() ? 'inv-balance-overdue' : ''}`}>
                    {inv.currency} {inv.balanceAmount.toLocaleString()}
                  </td>
                  <td className="inv-td">
                    <span className={`po-status-badge ${getStatusColor(inv.status)}`}>
                      {getStatusIcon(inv.status)}
                      {inv.status}
                    </span>
                  </td>
                  <td className="inv-td inv-td-meta">
                    <div className="inv-action-buttons">
                      {/* ✅ View button - opens in VIEW mode with ?mode=view */}
                      <button 
                        className="inv-action-btn grn-action-view" 
                        onClick={(e) => handleView(inv, e)}
                        title="View"
                      >
                        <FaEye size={12} />
                      </button>
                      {/* ✅ Edit button - opens in EDIT mode with ?mode=edit */}
                      <button 
                        className="inv-action-btn grn-action-edit" 
                        onClick={(e) => { e.stopPropagation(); handleEdit(inv); }}
                        title="Edit"
                      >
                        <FaEdit size={12} />
                      </button>
                      <button 
                        className="inv-action-btn grn-action-delete" 
                        onClick={(e) => handleDelete(inv, e)}
                        title="Delete"
                      >
                        <FaTrash size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* ─── Mobile UI Table / List Section (max-width: 768px) ─── */}
      <div className="inv-mobile-list-wrap">
        {filteredInvoices.length === 0 ? (
          <div className="inv-empty-state">
            <div className="inv-empty-content">
              <FaReceipt size={48} />
              <p>No purchase invoices found</p>
              <span>Create your first purchase invoice to get started</span>
              <button className="inv-btn-primary" onClick={handleCreate} style={{ marginTop: '12px' }}>
                <FaPlus size={12} /> New Purchase Bill
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Mobile Header: Invoice # / Supplier and Count Label */}
            <div className="inv-mobile-list-header">
              <div className="inv-mobile-th-primary">
                <span className="inv-mobile-th-cell">Invoice # / Supplier</span>
              </div>
              <div className="inv-mobile-th-right">
                <span className="inv-count-label">
                  {totalRecords > 0
                    ? `${getStartIndex()}–${getEndIndex()} of ${totalRecords}`
                    : '0'}
                </span>
              </div>
            </div>

            {/* Mobile Cards / Rows */}
            <div className="inv-mobile-cards">
              {filteredInvoices.map((inv) => {
                const isExpanded = expandedRows.has(inv.id);
                return (
                  <div
                    key={inv.id}
                    className={`inv-mobile-card ${isExpanded ? 'inv-mobile-card-expanded' : ''}`}
                  >
                    {/* Card Header: Invoice #, Supplier and Dropdown Button */}
                    <div
                      className="inv-mobile-card-header"
                      onClick={() => toggleRowExpand(inv.id)}
                    >
                      <div className="inv-mobile-card-primary">
                        <span
                          className="inv-mobile-item-code"
                          onClick={(e) => handleView(inv, e)}
                          title="View Invoice"
                        >
                          {inv.invoiceNumber}
                        </span>
                        <span
                          className="inv-mobile-item-name"
                          onClick={(e) => handleView(inv, e)}
                          title={inv.supplier}
                        >
                          {inv.supplier || '—'}
                        </span>
                      </div>

                      {/* Dropdown Button */}
                      <button
                        type="button"
                        className={`inv-mobile-dropdown-btn ${isExpanded ? 'expanded' : ''}`}
                        onClick={(e) => toggleRowExpand(inv.id, e)}
                        aria-label={isExpanded ? 'Collapse details' : 'Expand details'}
                        title={isExpanded ? 'Collapse details' : 'Expand details'}
                      >
                        <FaChevronDown size={13} className="inv-mobile-chevron" />
                      </button>
                    </div>

                    {/* Expanded Section: Date, Total, Balance, Status, 1–10 of 16 / Actions */}
                    {isExpanded && (
                      <div className="inv-mobile-card-details">
                        <div className="inv-mobile-detail-row">
                          <span className="inv-mobile-detail-label">Date</span>
                          <div className="inv-mobile-detail-date">
                            <FaCalendarAlt size={10} style={{ marginRight: 4 }} />
                            <span>{new Date(inv.date).toLocaleDateString()}</span>
                          </div>
                        </div>

                        <div className="inv-mobile-detail-row">
                          <span className="inv-mobile-detail-label">Total</span>
                          <span className={`inv-mobile-detail-value ${inv.balanceAmount > 0 && new Date(inv.dueDate) < new Date() ? 'inv-balance-overdue' : ''}`}>
                            {inv.currency} {inv.balanceAmount.toLocaleString()}
                          </span>
                        </div>

                        <div className="inv-mobile-detail-row">
                          <span className="inv-mobile-detail-label">Status</span>
                          <span className={`inv-status-badge ${getStatusColor(inv.status)}`}>
                            {getStatusIcon(inv.status)}
                            {inv.status}
                          </span>
                        </div>

                        <div className="inv-mobile-detail-footer">
                          <span className="inv-mobile-card-meta-text">
                          </span>
                          <div className="inv-action-buttons">
                            <button
                              className="inv-action-btn inv-action-view"
                              onClick={(e) => handleView(inv, e)}
                              title="View"
                            >
                              <FaEye size={12} />
                            </button>
                            <button
                              className="inv-action-btn inv-action-edit"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEdit(inv);
                              }}
                              title="Edit"
                            >
                              <FaEdit size={12} />
                            </button>
                            <button
                              className="inv-action-btn inv-action-delete"
                              onClick={(e) => handleDelete(inv, e)}
                              title="Delete"
                            >
                              <FaTrash size={12} />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>


      {/* Pagination */}
      <div className="inv-pagination">
        <div className="inv-pagination-left">
          <span className="inv-pagination-label">Show:</span>
          <select 
            value={itemsPerPage} 
            onChange={(e) => handlePageSizeChange(Number(e.target.value))}
            className="inv-page-size-select"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <span className="inv-pagination-info">
            {totalRecords > 0 ? (
              `Showing ${getStartIndex()} to ${getEndIndex()} of ${totalRecords} entries`
            ) : (
              'No entries to show'
            )}
          </span>
        </div>
        <div className="inv-pagination-center">
          <button 
            onClick={goToFirstPage} 
            disabled={currentPage === 1 || totalRecords === 0} 
            className="inv-page-btn"
          >
            <FaAngleDoubleLeft size={12} />
          </button>
          <button 
            onClick={goToPrevPage} 
            disabled={currentPage === 1 || totalRecords === 0} 
            className="inv-page-btn"
          >
            <FaChevronLeft size={12} />
          </button>
          {totalRecords > 0 && getPageNumbers().map(page => (
            <button
              key={page}
              onClick={() => goToPage(page)}
              className={`inv-page-btn ${currentPage === page ? 'inv-page-btn-active' : ''}`}
            >
              {page}
            </button>
          ))}
          <button 
            onClick={goToNextPage} 
            disabled={currentPage === totalPages || totalRecords === 0} 
            className="inv-page-btn"
          >
            <FaChevronRight size={12} />
          </button>
          <button 
            onClick={goToLastPage} 
            disabled={currentPage === totalPages || totalRecords === 0} 
            className="inv-page-btn"
          >
            <FaAngleDoubleRight size={12} />
          </button>
        </div>
        <div className="inv-pagination-right">
          <span className="inv-pagination-info">
            Page {currentPage} of {totalPages}
          </span>
        </div>
      </div>

      {/* ====== DELETE MODAL ====== */}
      {showDeleteModal && selectedInvoice && (
        <div className="inv-modal-overlay" onClick={() => setShowDeleteModal(false)}>
          <div className="inv-modal inv-modal-delete" onClick={(e) => e.stopPropagation()}>
            <div className="inv-modal-header">
              <span className="inv-modal-title">Confirm Delete</span>
              <button className="inv-modal-close" onClick={() => setShowDeleteModal(false)}>
                <FaTimes size={16} />
              </button>
            </div>
            <div className="inv-modal-body">
              <p>Are you sure you want to delete this purchase invoice?</p>
              <p className="inv-modal-item-name"><strong>{selectedInvoice.invoiceNumber}</strong></p>
              <p className="inv-modal-warning">This action cannot be undone.</p>
            </div>
            <div className="inv-modal-footer">
              <button className="inv-btn-cancel" onClick={() => setShowDeleteModal(false)}>
                Cancel
              </button>
              <button className="inv-btn-delete" onClick={handleDeleteConfirm} disabled={loading}>
                {loading && <FaSpinner className="inv-spinning" />}
                <FaTrash size={12} /> Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}