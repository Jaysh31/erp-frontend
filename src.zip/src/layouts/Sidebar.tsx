import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './Sidebar.css';
import { useModule } from '../context/ModuleContext';
import logo from '../assets/logo.png';
//import { time } from 'framer-motion';

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
}

export default function Sidebar({ 
  isOpen = true, 
  onClose,
  isMinimized = false,
  onToggleMinimize
}: SidebarProps) {
  const location = useLocation();
  const { currentModule, setCurrentModule } = useModule();
  const [expandedCategories, setExpandedCategories] = useState<{ [key: string]: boolean }>(() => {
    const saved = localStorage.getItem('expandedCategories');
    return saved ? JSON.parse(saved) : {
      'Manufacturing': true,
      'Sales': true,
      'Items & Pricing': false,
      'Organization': false,
      'Setup': false,
      'Tools': false,
      'Reports': false,
      'System': false,
      'Buying': false,
      'Accounting': true
    };
  });

  // Update module based on current path
 useEffect(() => {
  if (location.pathname === "/home") {
    setCurrentModule("home");
  }
}, [location.pathname, setCurrentModule]);

  // Save expanded categories to localStorage
  useEffect(() => {
    localStorage.setItem('expandedCategories', JSON.stringify(expandedCategories));
  }, [expandedCategories]);

  const toggleCategory = (categoryTitle: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryTitle]: !prev[categoryTitle]
    }));
  };

  const handleNavClick = (e: React.MouseEvent) => {
    if (isMinimized && onToggleMinimize) {
      e.preventDefault();
      onToggleMinimize();
      const target = e.currentTarget as HTMLAnchorElement;
      setTimeout(() => {
        window.location.href = target.href;
      }, 350);
    }
    if (window.innerWidth < 768 && onClose) {
      onClose();
    }
  };

  // All menu categories
  const allMenuCategories = [
    {
      title: 'Home',
      module: 'home',
      icon: <HomeIcon />,
      items: [
        { title: 'Home', icon: <HomeIcon />, path: '/home' },
        { title: 'Dashboard', icon: <DashboardIcon />, path: '/dashboard' }
      ]
    },
    {
      title: 'Sales',
      module: 'sales',
      icon: <SalesIcon />,
      items: [
        { title: 'Quotation', icon: <QuotationIcon />, path: '/quotation' },
        { title: 'Sales Order', icon: <SalesOrderIcon />, path: '/sales-order' },
        { title: 'Sales Invoice', icon: <InvoiceIcon />, path: '/sales-invoice' }
      ]
    },
    {
      title: 'Items & Pricing',
      module: 'sales',
      icon: <ItemIcon />,
      items: [
        { title: 'Item', icon: <ItemIcon />, path: '/item-list' },
        { title: 'Item Group', icon: <FolderIcon />, path: '/item-group' },
        { title: 'Price List', icon: <TagIcon />, path: '/price-list' },
        { title: 'Item Price', icon: <BrandIcon />, path: '/item-price' },
        { title: 'Pricing Rule', icon: <RulerIcon />, path: '/pricing-rule' },
        { title: 'Coupon Code', icon: <CouponIcon />, path: '/coupon-code' }
      ]
    },
    {
      title: 'Manufacturing',
      module: 'manufacturing',
      icon: <ManufacturingIcon />,
      items: [
        { title: 'BOM', icon: <BomIcon />, path: '/bom' },
        { title: 'Work Order', icon: <WorkOrderIcon />, path: '/work-order' },
        { title: 'Job Card', icon: <JobCardIcon />, path: '/job-card' },
        { title: 'Stock Entry', icon: <StockIcon />, path: '/stock-entry' },
        // { title: 'Material Planning', icon: <TruckIcon />, path: '/material-planning' }
      ]
    },
    {
      title: 'Organization',
      module: 'organization',
      icon: <OrganizationIcon />,
      items: [
        { title: 'Company', icon: <CompanyIcon />, path: '/company' },
        { title: 'Letter Head', icon: <LetterHeadIcon />, path: '/letter-head' }
      ]
    },
    {
      title: 'Setup',
      module: 'setup',
      icon: <SetupIcon />,
      items: [
        { title: 'Item', icon: <ItemIcon />, path: '/item-list' },
        { title: 'Item Group', icon: <FolderIcon />, path: '/item-group' },
        { title: 'Item Attribute', icon: <TagIcon />, path: '/item-attribute' },
        { title: 'Brand', icon: <BrandIcon />, path: '/brand' },
        { title: 'Warehouse', icon: <WarehouseIcon />, path: '/warehouse' },
        { title: 'Workstation', icon: <WarehouseIcon />, path: '/Workstation' },
        { title: 'Operations', icon: <WarehouseIcon />, path: '/operations' },

        { title: 'Unit of Measure (UOM)', icon: <RulerIcon />, path: '/uom' },
        // { title: 'UOM Conversion Factor', icon: <RepeatIcon />, path: '/uom-conversion' },
        // { title: 'Serial No', icon: <HashIcon />, path: '/serial-no' },
        // { title: 'Batch No', icon: <LayersIcon />, path: '/batch-no' },
        // { title: 'Serial and Batch Bundle', icon: <PackageIcon />, path: '/serial-batch-bundle' }
      ]
    },
    {
      title: 'Tools',
      module: 'tools',
      icon: <ToolIcon />,
      items: [
        { title: 'Tools', icon: <ToolIcon />, path: '/tools' }
      ]
    },
    {
      title: 'Buying',
      module: 'purchasing',
      icon: <BuyingIcon />,
      items: [
        { title: 'Material Request', icon: <MaterialRequestIcon />, path: '/material-request' },
        { title: 'Request for Quotation', icon: <RFQIcon />, path: '/request-for-quotation' },
        { title: 'Supplier Quotation', icon: <SupplierQuotationIcon />, path: '/supplier-quotation' },
        { title: 'Purchase Order', icon: <PurchaseOrderIcon />, path: '/purchase-order' },
        { title: 'Purchase Invoice', icon: <PurchaseInvoiceIcon />, path: '/purchase-invoice' },
        { title: 'Supplier', icon: <SupplierIcon />, path: '/supplier' },
        { title: 'Supplier Group', icon: <SupplierGroupIcon />, path: '/supplier-group' },
        { title: 'Price List', icon: <PriceListIcon />, path: '/price-list' },
        { title: 'Address', icon: <AddressIcon />, path: '/address' },
        { title: 'Contacts', icon: <ContactsIcon />, path: '/contacts' },
        { title: 'Supplier Scorecard', icon: <SupplierScorecardIcon />, path: '/supplier-scorecard' },
        { title: 'Supplier Scorecard Criteria', icon: <SupplierScorecardCriteriaIcon />, path: '/supplier-scorecard-criteria' }
      ]
    },
    {
      title: 'Accounting',
      module: 'accounting',
      icon: <AccountingIcon />,
      items: [
        { title: 'Dashboard', icon: <DashboardIcon />, path: '/accounting/dashboard' },
        { title: 'Accounts', icon: <ChartOfAccountsIcon />, path: '/accounting/accounts' },
        // { title: 'Chart of Accounts', icon: <ChartOfAccountsIcon />, path: '/accounting/chart-of-accounts' },
        // { title: 'Ledger Accounts', icon: <LedgerIcon />, path: '/accounting/ledgers' },
        // { title: 'Cost Centers', icon: <CostCenterIcon />, path: '/accounting/cost-centers' },
        // { title: 'Receivables', icon: <ReceivableIcon />, path: '/accounting/receivables' },
        // { title: 'Customer Invoices', icon: <CustomerInvoiceIcon />, path: '/accounting/customer-invoices' },
        // { title: 'Customer Payments', icon: <CustomerPaymentIcon />, path: '/accounting/customer-payments' },
        // { title: 'Outstanding Receivables', icon: <OutstandingReceivableIcon />, path: '/accounting/outstanding-receivables' },
        // { title: 'Payables', icon: <PayableIcon />, path: '/accounting/payables' },
        // { title: 'Supplier Bills', icon: <SupplierBillIcon />, path: '/accounting/supplier-bills' },
        // { title: 'Supplier Payments', icon: <SupplierPaymentIcon />, path: '/accounting/supplier-payments' },
        // { title: 'Outstanding Payables', icon: <OutstandingPayableIcon />, path: '/accounting/outstanding-payables' },
        // { title: 'Banking', icon: <BankingIcon />, path: '/accounting/banking' },
        // { title: 'Bank Accounts', icon: <BankAccountIcon />, path: '/accounting/bank-accounts' },
        // { title: 'Bank Transactions', icon: <BankTransactionIcon />, path: '/accounting/bank-transactions' },
        // { title: 'Bank Reconciliation', icon: <BankReconciliationIcon />, path: '/accounting/bank-reconciliation' },
        // { title: 'Expenses', icon: <ExpenseIcon />, path: '/accounting/expenses' },
        // { title: 'Expense Categories', icon: <TagIcon />, path: '/accounting/expense-categories' },
        // { title: 'Expense Reports', icon: <ReportsIcon />, path: '/accounting/expense-reports' },
        // { title: 'Taxes', icon: <TaxIcon />, path: '/accounting/taxes' },
        // { title: 'Tax Configuration', icon: <TaxIcon />, path: '/accounting/tax-configuration' },
        // { title: 'Tax Returns', icon: <ReportsIcon />, path: '/accounting/tax-returns' },
        // { title: 'GST Reports', icon: <GSTIcon />, path: '/accounting/gst-reports' },
        // { title: 'Journal Entries', icon: <JournalIcon />, path: '/accounting/journal-entries' },
        // { title: 'Create Journal', icon: <JournalIcon />, path: '/accounting/create-journal' },
        // { title: 'View Journals', icon: <LedgerReportIcon />, path: '/accounting/view-journals' },
        // { title: 'General Ledger', icon: <LedgerReportIcon />, path: '/accounting/general-ledger' },
        // { title: 'Trial Balance', icon: <TrialBalanceIcon />, path: '/accounting/trial-balance' },
        // { title: 'Profit & Loss', icon: <PnLIcon />, path: '/accounting/profit-loss' },
        // { title: 'Balance Sheet', icon: <BalanceSheetIcon />, path: '/accounting/balance-sheet' },
        // { title: 'Cash Flow', icon: <CashFlowIcon />, path: '/accounting/cash-flow' },
        // { title: 'Fund Flow', icon: <FundsFlowIcon />, path: '/accounting/funds-flow' },
        // { title: 'Ratio Analysis', icon: <RatioIcon />, path: '/accounting/ratio-analysis' },
        // { title: 'Settings', icon: <SettingsIcon />, path: '/accounting/settings' }
      ]
    },
    {
       title: 'Accounts',
       module: 'accounting',
        icon: <AccountingIcon />,
        items: [
           { title: 'Chart of Accounts', icon: <ChartOfAccountsIcon />, path: '/chart-of-accounts' },
           { title: 'Ledger Accounts', icon: <LedgerIcon />, path: '/ledger-accounts' },
        { title: 'Cost Centers', icon: <CostCenterIcon />, path: '/accounting/cost-centers' },
        ]
    },
   {
    title: 'Receivables',
    module: 'accounting',
    icon: <ReceivablesIcon />,
    items: [
       {
            title: 'Sales Invoices',
            icon: <InvoiceIcon />,
            path: '/customer-invoices'
        },
        {
            title: 'Delivery Challans',
            icon: <ReceiptIcon />,
            path: '/delivery-challan'
        },
        {
            title: 'Customer Payments',
            icon: <PaymentIcon />,
            path: '/Customer-payments'
        },
       
        {
            title: 'Credit Notes',
            icon: <CreditNoteIcon />,
            path: '/receivables/credit-notes'
        },
        {
            title: 'Outstanding Receivables',
            icon: <CustomerIcon />,
            path: '/outstanding-receivables'
        }
    ]
},
    {
       title: 'Payables',
        module: 'accounting',
        icon: <PayablesIcon />,
        items: [
          { title: 'Supplier Bills', icon: <SupplierIcon />, path: '/payables/supplier-bills' },
          { title: 'Supplier Payments', icon: <PaymentIcon />, path: '/payables/supplier-payments' },
          { title: 'Outstanding Payables', icon: <OutstandingIcon />, path: '/payables/outstanding-payables' }
        ]
    },
    {
title: 'Banking',
      module: 'accounting',
      icon: <BankingIcon />,
      items: [
        { title: 'Bank Accounts', icon: <BankAccountIcon />, path: '/banking/bank-accounts' },
        { title: 'Bank Transactions', icon: <BankTransactionIcon />, path: '/banking/bank-transactions' },
        { title: 'Bank Reconciliation', icon: <BankReconciliationIcon />, path: '/banking/bank-reconciliation' }
      ]
    },
    {
      title: 'Expenses',
      module: 'accounting',
      icon: <ExpenseIcon />,
      items: [
        { title: 'Expense ', icon: <TagIcon />, path: '/expenses/expense' },
      ]
    },
    // {
    //   title: 'System',
    //   module: 'system',
    //   icon: <SettingsIcon />,
    //   items: [
    //     { title: 'Settings', icon: <SettingsIcon />, path: '/settings' }
    //   ]
    // }
  ];

  // Filter categories based on current module
const getFilteredCategories = () => {
  if (currentModule === 'home') {
    return allMenuCategories.filter(cat =>
      cat.module === 'home' || cat.module === 'system'
    );
  } else {
    return allMenuCategories.filter(cat =>
      cat.module === 'home' ||
      cat.module === currentModule ||
      cat.module === 'system'
    );
  }
};


  const menuCategories = getFilteredCategories();

  // Get module display name
  const getModuleName = () => {
    const names: Record<string, string> = {
      'home': 'Home',
      'manufacturing': 'Manufacturing',
      'setup': 'Setup',
      'sales': 'Sales',
      'purchasing': 'Purchasing',
      'organization': 'Organization',
      'tools': 'Tools',
      'reports': 'Reports',
      'system': 'System',
      'accounting': 'Accounting'
    };
    return names[currentModule] || 'Home';
  };

  return (
    <>
      {isOpen && (
        <div className="sidebar-overlay" onClick={onClose}></div>
      )}

      <aside className={`sidebar ${isOpen ? 'sidebar-open' : 'sidebar-closed'} ${isMinimized ? 'minimized' : ''}`}>
        {/* Logo */}
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon">
              <img src={logo} alt="SculptERP Logo" className="logo-image" />
            </div>
            <div>
              <div className="logo-text">SculptERP</div>
              {!isMinimized && currentModule !== 'home' && (
                <div className="module-indicator">
                  {getModuleName()} Module
                </div>
              )}
            </div>
          </div>
          {onClose && (
            <button className="mobile-close-btn" onClick={onClose}>
              ×
            </button>
          )}
        </div>

        {/* Search + Notification
        <div className="sidebar-top">
          <div className="search-row">
            <svg className="search-icon" width="15" height="15" viewBox="0 0 16 16" fill="none">
              <path d="M7.33333 12.6667C10.2789 12.6667 12.6667 10.2789 12.6667 7.33333C12.6667 4.38781 10.2789 2 7.33333 2C4.38781 2 2 4.38781 2 7.33333C2 10.2789 4.38781 12.6667 7.33333 12.6667Z" stroke="var(--sidebar-text-secondary, #9CA3AF)" strokeWidth="1.5" strokeLinecap="round"/>
              <path d="M14 14L11 11" stroke="var(--sidebar-text-secondary, #9CA3AF)" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
            <input type="text" placeholder="Search" className="sidebar-search" />
            <span className="search-shortcut">Ctrl+K</span>
          </div>
          <div className="notification-row">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--sidebar-text-secondary, #6B7280)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </svg>
            <span className="notification-label">Notification</span>
            <span className="notification-count">3</span>
          </div>
        </div> */}

        {/* Navigation */}
        <div className="sidebar-nav">
          {menuCategories.map((category, idx) => (
            <div key={idx} className="nav-category">
              <div 
                className="category-header"
                onClick={() => toggleCategory(category.title)}
              >
                <div className="category-header-left">
                  <span className="category-icon">{category.icon}</span>
                  <span className="category-title">{category.title}</span>
                </div>
                <span className="category-toggle">
                  {expandedCategories[category.title] ? 
                    <ChevronUpIcon /> : 
                    <ChevronDownIcon />
                  }
                </span>
              </div>
              <div className={`category-items-wrapper ${expandedCategories[category.title] ? 'expanded' : 'collapsed'}`}>
                <div className="category-items">
                  {category.items.map((item) => (
                    <NavLink
                      key={item.path}
                      to={item.path}
                      className={({ isActive }) => 
                        `nav-item ${isActive ? 'active' : ''}`
                      }
                      onClick={handleNavClick}
                    >
                      <span className="nav-icon">{item.icon}</span>
                      <span className="nav-text">{item.title}</span>
                      {isMinimized && (
                        <span className="nav-tooltip">
                          {item.title}
                          <span className="tooltip-shortcut">Click to expand</span>
                        </span>
                      )}
                    </NavLink>
                  ))}
                </div>
              </div>
            </div>
          ))}

          {/* Getting Started Card - Only show in Home module */}
          {currentModule === 'home' && (
            <div className="getting-started-section">
              <div className="getting-started-card">
                <div className="gs-icon-wrap">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--sidebar-text-secondary, #9CA3AF)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                    <path d="M2 17l10 5 10-5"/>
                    <path d="M2 12l10 5 10-5"/>
                  </svg>
                </div>
                <div className="gs-text">Complete setup to start manufacturing</div>
              </div>
            </div>
          )}
        </div>

        {/* User */}
        <div className="sidebar-user">
          <div className="user-avatar">TT</div>
          <div className="user-info">
            <div className="user-name">Tejas Tarte</div>
            <div className="user-email">tejasvitthaltarte@gm...</div>
          </div>
        </div>
      </aside>

      {/* Toggle Button */}
      <button 
        className={`sidebar-toggle-btn ${isMinimized ? 'minimized' : 'expanded'}`}
        onClick={onToggleMinimize}
        aria-label={isMinimized ? 'Expand sidebar' : 'Minimize sidebar'}
        title={isMinimized ? 'Click to expand' : 'Click to minimize'}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="15 18 9 12 15 6"/>
        </svg>
        <span className="toggle-tooltip">
          {isMinimized ? 'Expand' : 'Minimize'}
        </span>
      </button>
    </>
  );
}

// ===== ICON COMPONENTS =====

// Home Icons
const HomeIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
    <polyline points="9 22 9 12 15 12 15 22"/>
  </svg>
);

const DashboardIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7" rx="1"/>
    <rect x="14" y="3" width="7" height="7" rx="1"/>
    <rect x="3" y="14" width="7" height="7" rx="1"/>
    <rect x="14" y="14" width="7" height="7" rx="1"/>
  </svg>
);

// Sales Icons
const SalesIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2L2 7l10 5 10-5-10-5z"/>
    <path d="M2 17l10 5 10-5"/>
    <path d="M2 12l10 5 10-5"/>
  </svg>
);

const QuotationIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>
);

const SalesOrderIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="3" width="20" height="18" rx="2" ry="2"/>
    <line x1="8" y1="9" x2="16" y2="9"/>
    <line x1="8" y1="13" x2="16" y2="13"/>
    <line x1="8" y1="17" x2="12" y2="17"/>
  </svg>
);

const InvoiceIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="8" y1="13" x2="16" y2="13"/>
    <line x1="8" y1="17" x2="16" y2="17"/>
    <line x1="8" y1="9" x2="10" y2="9"/>
  </svg>
);

// Items & Pricing Icons
const ItemIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
  </svg>
);

const FolderIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
  </svg>
);

const TagIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2H2v10l9.17 9.17a2 2 0 0 0 2.83 0l7-7a2 2 0 0 0 0-2.83L12 2z"/>
    <circle cx="7" cy="7" r="2" fill="none"/>
  </svg>
);

const BrandIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 8h16M4 16h16M8 4v16M16 4v16"/>
  </svg>
);

const RulerIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 12h20M12 2v20M8 4v2M16 4v2M4 8h2M18 8h2M4 16h2M18 16h2M8 20v2M16 20v2"/>
  </svg>
);

const CouponIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 12L12 4L4 12L12 20L20 12Z"/>
    <path d="M12 8L12 16"/>
    <path d="M8 12L16 12"/>
  </svg>
);

const ReceiptIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M6 2h12v20l-2-1.5L14 22l-2-1.5L10 22l-2-1.5L6 22V2z" />
    <path d="M9 7h6" />
    <path d="M9 11h6" />
    <path d="M9 15h4" />
  </svg>
);

const CreditNoteIcon = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M6 2h12v20l-2-1.5L14 22l-2-1.5L10 22l-2-1.5L6 22V2z" />
    <path d="M9 7h6" />
    <path d="M9 11h4" />
    <path d="M15 16h-6" />
    <path d="M11 14l-2 2 2 2" />
  </svg>
);

// Manufacturing Icons
const ManufacturingIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 4h6v6M4 20L20 4M18 20h-6M4 8V4h4"/>
  </svg>
);

const BomIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <line x1="8" y1="6" x2="21" y2="6"/>
    <line x1="8" y1="12" x2="21" y2="12"/>
    <line x1="8" y1="18" x2="21" y2="18"/>
    <line x1="3" y1="6" x2="3.01" y2="6"/>
    <line x1="3" y1="12" x2="3.01" y2="12"/>
    <line x1="3" y1="18" x2="3.01" y2="18"/>
  </svg>
);

const WorkOrderIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 11l3 3L22 4"/>
    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
  </svg>
);

const JobCardIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="5" width="20" height="14" rx="2"/>
    <line x1="2" y1="10" x2="22" y2="10"/>
  </svg>
);

const StockIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
  </svg>
);

// const ToolIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <rect x="9" y="2" width="6" height="4" rx="1"/>
//     <rect x="2" y="14" width="6" height="4" rx="1"/>
//     <rect x="16" y="14" width="6" height="4" rx="1"/>
//     <path d="M12 6v4M12 10H5v4M12 10h7v4"/>
//   </svg>
// );

const CompanyIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="4" width="16" height="16" rx="2"/>
    <path d="M9 8h6"/>
    <path d="M9 12h6"/>
    <path d="M9 16h4"/>
  </svg>
);

const LetterHeadIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
    <line x1="3" y1="10" x2="21" y2="10"/>
    <line x1="3" y1="14" x2="21" y2="14"/>
    <line x1="3" y1="18" x2="21" y2="18"/>
    <line x1="8" y1="4" x2="8" y2="10"/>
    <line x1="16" y1="4" x2="16" y2="10"/>
  </svg>
);

// Setup Icons
const SetupIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/>
  </svg>
);

const WarehouseIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
    <path d="M9 22V12h6v10"/>
  </svg>
);

// const RepeatIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <path d="M17 1l4 4-4 4"/>
//     <path d="M3 11V9a4 4 0 0 1 4-4h14"/>
//     <path d="M7 23l-4-4 4-4"/>
//     <path d="M21 13v2a4 4 0 0 1-4 4H3"/>
//   </svg>
// );

// const HashIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <line x1="4" y1="9" x2="20" y2="9"/>
//     <line x1="4" y1="15" x2="20" y2="15"/>
//     <line x1="10" y1="3" x2="8" y2="21"/>
//     <line x1="16" y1="3" x2="14" y2="21"/>
//   </svg>
// );

// const LayersIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <polygon points="12 2 2 7 12 12 22 7 12 2"/>
//     <polyline points="2 17 12 22 22 17"/>
//     <polyline points="2 12 12 17 22 12"/>
//   </svg>
// );

// const PackageIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <path d="M12 2L2 7l10 5 10-5-10-5z"/>
//     <path d="M2 17l10 5 10-5"/>
//     <path d="M2 12l10 5 10-5"/>
//   </svg>
// );
// ===== RECEIVABLES ICONS =====

const ReceivablesIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2L2 7l10 5 10-5-10-5z" />
    <path d="M2 17l10 5 10-5" />
    <path d="M2 12l10 5 10-5" />
    <path d="M12 7v10" />
    <circle cx="8" cy="14" r="1.5" />
    <circle cx="16" cy="14" r="1.5" />
  </svg>
);

const CustomerIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
    <path d="M16 11l2 2 4-4" />
    <path d="M18 13v4" />
  </svg>
);

// const InvoiceIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
//     <polyline points="14 2 14 8 20 8" />
//     <line x1="8" y1="13" x2="16" y2="13" />
//     <line x1="8" y1="17" x2="16" y2="17" />
//     <line x1="8" y1="9" x2="10" y2="9" />
//     <path d="M16 9v8" />
//   </svg>
// );

const PaymentIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 6h18" />
    <rect x="2" y="6" width="20" height="14" rx="2" />
    <path d="M16 12h4" />
    <circle cx="8" cy="12" r="1" />
    <circle cx="12" cy="12" r="1" />
    <path d="M4 16h7" />
  </svg>
);

// ===== PAYABLES ICONS =====

const PayablesIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2L2 7l10 5 10-5-10-5z" />
    <path d="M2 17l10 5 10-5" />
    <path d="M2 12l10 5 10-5" />
    <path d="M12 7v10" />
    <path d="M7 9.5v5" />
    <path d="M17 9.5v5" />
    <circle cx="8" cy="14" r="1.5" />
    <circle cx="16" cy="14" r="1.5" />
  </svg>
);

// const SupplierIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
//     <circle cx="12" cy="7" r="4" />
//     <path d="M16 11l2 2 4-4" />
//     <path d="M19 13v4" />
//     <path d="M16 13h6" />
//   </svg>
// );



const OutstandingIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <polyline points="12 6 12 12 16 14" />
    <path d="M12 22v-4" />
    <path d="M6 12h2" />
    <path d="M16 12h2" />
  </svg>
);


// Tools & Reports Icons
const ToolIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
  </svg>
);


// Buying/Purchasing Icons
const BuyingIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
    <line x1="3" y1="6" x2="21" y2="6"/>
    <path d="M16 10a4 4 0 0 1-8 0"/>
    <path d="M12 14v4"/>
    <path d="M8 18h8"/>
  </svg>
);

const MaterialRequestIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>
);

const RFQIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="8" y1="16" x2="16" y2="16"/>
    <line x1="8" y1="12" x2="16" y2="12"/>
    <line x1="8" y1="20" x2="12" y2="20"/>
  </svg>
);

const SupplierQuotationIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2L2 7l10 5 10-5-10-5z"/>
    <path d="M2 17l10 5 10-5"/>
    <path d="M2 12l10 5 10-5"/>
    <path d="M12 7v10"/>
    <path d="M7 9.5v5"/>
    <path d="M17 9.5v5"/>
  </svg>
);

const PurchaseOrderIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>
);

const PurchaseInvoiceIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="8" y1="16" x2="16" y2="16"/>
    <line x1="8" y1="12" x2="16" y2="12"/>
    <line x1="8" y1="20" x2="10" y2="20"/>
    <path d="M8 8h4"/>
  </svg>
);

const SupplierIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
    <circle cx="12" cy="7" r="4"/>
    <path d="M16 11l2 2 4-4"/>
    <path d="M19 13v4"/>
    <path d="M16 13h6"/>
  </svg>
);

const SupplierGroupIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    <path d="M16 11l2 2 4-4"/>
  </svg>
);

const PriceListIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2H2v10l9.17 9.17a2 2 0 0 0 2.83 0l7-7a2 2 0 0 0 0-2.83L12 2z"/>
    <circle cx="7" cy="7" r="2" fill="none"/>
    <path d="M17 10l-2 2"/>
  </svg>
);

const AddressIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
    <circle cx="12" cy="10" r="3"/>
    <path d="M12 7v3"/>
    <path d="M9 10h6"/>
  </svg>
);

const ContactsIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
    <circle cx="12" cy="7" r="4"/>
    <path d="M16 11l2 2 4-4"/>
    <path d="M19 13v4"/>
  </svg>
);

const SupplierScorecardIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>
    <polyline points="15 3 21 3 21 9"/>
    <line x1="10" y1="14" x2="21" y2="3"/>
    <path d="M14 14h7"/>
    <path d="M14 18h4"/>
  </svg>
);

const SupplierScorecardCriteriaIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
    <line x1="3" y1="10" x2="21" y2="10"/>
    <line x1="3" y1="14" x2="21" y2="14"/>
    <line x1="3" y1="18" x2="21" y2="18"/>
    <line x1="8" y1="4" x2="8" y2="10"/>
    <line x1="16" y1="4" x2="16" y2="10"/>
    <circle cx="12" cy="12" r="2"/>
    <circle cx="12" cy="16" r="2"/>
  </svg>
);

// ===== ACCOUNTING MODULE ICONS =====

const AccountingIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="6" width="20" height="14" rx="2" ry="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
    <line x1="8" y1="14" x2="16" y2="14" />
    <line x1="12" y1="6" x2="12" y2="20" />
  </svg>
);

const ChartOfAccountsIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="2" />
    <line x1="8" y1="6" x2="16" y2="6" />
    <line x1="8" y1="10" x2="16" y2="10" />
    <line x1="8" y1="14" x2="14" y2="14" />
    <line x1="8" y1="18" x2="12" y2="18" />
  </svg>
);

const LedgerIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="3" width="20" height="18" rx="2" />
    <line x1="8" y1="8" x2="16" y2="8" />
    <line x1="8" y1="12" x2="16" y2="12" />
    <line x1="8" y1="16" x2="12" y2="16" />
    <line x1="2" y1="7" x2="22" y2="7" />
  </svg>
);

const CostCenterIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="5" width="20" height="14" rx="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
    <circle cx="12" cy="14" r="2" />
    <path d="M8 14h8" />
  </svg>
);






// const SupplierBillIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
//     <polyline points="14 2 14 8 20 8" />
//     <line x1="8" y1="16" x2="16" y2="16" />
//     <line x1="8" y1="12" x2="16" y2="12" />
//     <line x1="8" y1="20" x2="10" y2="20" />
//     <path d="M8 8h4" />
//   </svg>
// );

// const SupplierPaymentIcon = () => (
//   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
//     <path d="M3 6h18" />
//     <rect x="2" y="6" width="20" height="14" rx="2" />
//     <path d="M4 12h7" />
//     <circle cx="8" cy="12" r="1" />
//     <circle cx="12" cy="12" r="1" />
//     <path d="M16 16h4" />
//   </svg>
// );


const BankingIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="6" width="20" height="14" rx="2" />
    <path d="M2 10h20" />
    <path d="M6 14h2" />
    <path d="M10 14h4" />
    <path d="M16 14h2" />
    <path d="M2 6l4-4h12l4 4" />
  </svg>
);

const BankAccountIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="6" width="20" height="14" rx="2" />
    <path d="M2 10h20" />
    <path d="M6 14h2" />
    <path d="M10 14h4" />
    <path d="M16 14h2" />
    <path d="M2 6l4-4h12l4 4" />
  </svg>
);

const BankTransactionIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 1l4 4-4 4" />
    <path d="M3 11V9a4 4 0 0 1 4-4h14" />
    <path d="M7 23l-4-4 4-4" />
    <path d="M21 13v2a4 4 0 0 1-4 4H3" />
    <line x1="8" y1="8" x2="16" y2="16" />
  </svg>
);

const BankReconciliationIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
    <circle cx="12" cy="14" r="2" />
    <path d="M8 14h8" />
    <line x1="8" y1="18" x2="12" y2="18" />
  </svg>
);

const ExpenseIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12h-3" />
    <path d="M6 12H3" />
    <path d="M12 3v3" />
    <path d="M12 18v3" />
    <path d="M17.5 6.5l2.5 2.5" />
    <path d="M4 15l2.5 2.5" />
    <path d="M6.5 6.5L4 9" />
    <path d="M17.5 17.5l2.5-2.5" />
    <path d="M12 8v4l2 2" />
  </svg>
);











const SettingsIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3"/>
    <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
  </svg>
);



// Helper Icons
const ChevronDownIcon = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path d="M2 4l4 4 4-4" stroke="#9CA3AF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const ChevronUpIcon = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path d="M2 8l4-4 4 4" stroke="#9CA3AF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
// Organization Icons
const OrganizationIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="9" y="2" width="6" height="4" rx="1"/>
    <rect x="2" y="14" width="6" height="4" rx="1"/>
    <rect x="16" y="14" width="6" height="4" rx="1"/>
    <path d="M12 6v4M12 10H5v4M12 10h7v4"/>
  </svg>
);
